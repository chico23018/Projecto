package it.fabrick.accademy.alberi;

import lombok.Getter;
import lombok.Setter;

import static it.fabrick.accademy.alberi.Albero.Stato.IN_CRESCITA;

public abstract class Albero {

    private final Foglia type;
    private double altezza;

    @Getter
    @Setter
    private Stato stato = IN_CRESCITA;
    @Getter
    @Setter
    private int fiori = 0;

    protected Albero(Foglia type,
                     double altezza) {
        this.type = type;
        this.altezza = altezza;
    }

    abstract double getAltezzaMax();

    public void cresci() throws InvalidState {
        if (stato != IN_CRESCITA) {
            System.err.println("errore");
            throw new InvalidState("invalid stato " + stato);
        }

        altezza = Math.min(
                getAltezzaMax(),
                altezza * 1.10
        );
    }

    public void fioritura() throws InvalidState {
        if (stato != IN_CRESCITA) {
            System.err.println("errore");
            throw new InvalidState("invalid stato " + stato);
        }

        stato = Stato.IN_FIORITURA;
        fiori = (int) (100 + (Math.random() * 401));
    }

    public void reset() {
        stato = IN_CRESCITA;
        fiori = 0;
    }

    public enum Foglia {AGHI, NORMALE, LUNGA}

    public enum Stato {IN_CRESCITA, IN_FIORITURA, IN_RACCOLTA, RACCOLTO}
}
