package it.fabrick.accademy;


import it.fabrick.accademy.paymentGateway.APaymentGateway;
import it.fabrick.accademy.paymentGateway.Currency;
import it.fabrick.accademy.paymentGateway.mastercard.Mastercard;
import it.fabrick.accademy.paymentGateway.visa.Visa;

import java.awt.*;

/**
 * Hello world!
 */
public class App {


    private static final float PI = 3.15f;

    public static void main(String[] args) {
        Object v1 = new Mastercard("1");

        APaymentGateway a = (APaymentGateway) v1;
        switch (a.getType()) {
            case GOOGLE:
                break;
            case MASTERCARD:
                break;
            case VISA:
                break;
        }

        Mastercard v2 = new Mastercard("3");
        Mastercard v3 = new Mastercard("1");

        Visa eur = new Visa(1,Currency.USD);
        Visa usd = new Visa(1,Currency.EUR);


        if (v1.equals(v2)) {
            System.out.println("equals v1-v2");
        }
        if (v1.equals(v3)) {
            System.out.println("equals v1-v3");
        }

        if (v1.equals("1")) {

        }
    }




}
