package it.fabrick.accademy.alberi;

public class Pino extends
        AlberoFrutti {
    private final static double ALTEZZA_MAX = 25;

    protected Pino(double altezza) {
        super(Foglia.AGHI, altezza);
    }

    @Override
    double getAltezzaMax() {
        return ALTEZZA_MAX;
    }


    @Override
    public double conversionRate() {
        return 0.6;
    }

    @Override
    public int minRaccolta() {
        return 100;
    }

    @Override
    public int maxRaccolta() {
        return 200;
    }


}
