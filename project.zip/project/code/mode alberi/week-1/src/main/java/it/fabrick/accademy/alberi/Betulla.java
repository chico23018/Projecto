package it.fabrick.accademy.alberi;

public class Betulla extends Albero {
    private final static double ALTEZZA_MAX = 2;

    public Betulla() {
        super(Foglia.NORMALE, 1.1);
    }

    @Override
    double getAltezzaMax() {
        return Betulla.ALTEZZA_MAX;
    }



}
