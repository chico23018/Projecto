package it.fabrick.accademy.alberi;

import lombok.ToString;

import static it.fabrick.accademy.alberi.Albero.Stato.*;
@ToString(callSuper = true)
public abstract class AlberoFrutti extends Albero {

    int frutta;

    protected AlberoFrutti(Foglia type, Tipo tipo,double altezza) {
        super(type, tipo, altezza);
    }

    public abstract double conversionRate();

    public abstract int minRaccolta();

    public abstract int maxRaccolta();

    private void fruttifica() throws InvalidState {
        if (getStato() != IN_FIORITURA) {
            System.err.println("errore");
            throw new InvalidState("invalid stato " + getStato());
        }
        frutta = (int) (getFiori() * conversionRate());
        setStato(IN_RACCOLTA);
        setFiori(0);
    }

    public int raccolta() throws InvalidState {
        if (getStato() != IN_RACCOLTA) {
            System.err.println("errore");
            throw new InvalidState("invalid stato " + getStato());
        }
        int raccolto = (int)
                ((minRaccolta() + Math.random() * (maxRaccolta() + 1))
                        * frutta);
        setStato(RACCOLTO);
        frutta = 0;
        return raccolto;
    }

    public void reset() {
        super.reset();
        frutta = 0;
    }
}
