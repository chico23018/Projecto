package it.fabrick.accademy.alberi;

import lombok.ToString;

@ToString(callSuper = true)
public class Castagno extends
        AlberoFrutti {
    private final static double ALTEZZA_MAX = 10;
    private final static int MIN_RACCOLTA = 2;
    private final static int MAX_RACCOLTA = 5;

    protected Castagno(double altezza) {
        super(Foglia.LUNGA, Tipo.CASTAGNO,altezza);
    }

    @Override
    double getAltezzaMax() {
        return ALTEZZA_MAX;
    }

    @Override
    public double conversionRate() {
        return 0.7;
    }

    @Override
    public int minRaccolta() {
        return MIN_RACCOLTA;
    }

    @Override
    public int maxRaccolta() {
        return MAX_RACCOLTA;
    }
}
