package it.fabrick.accademy.alberi;

import lombok.Getter;

import java.util.*;

public class Foresta {
    @Getter
    private final Map<Albero.Tipo, List<Albero>> alberi
            = new HashMap<>();


    public void add(Albero objects) {
        List<Albero> tmp = alberi.get(objects.getTipo());
        if (tmp == null) {
            tmp = new ArrayList<>();
            alberi.put(objects.getTipo(), tmp);
        }

        tmp.add(objects);
        ;
    }

    public void clear() {
        alberi.clear();
    }

 public void populate(int n) {
        for (int i = 0; i < n; i++) {
            Albero a;
            switch ((int) (Math.random() * 3)) {
                case 0:
                    a = new Betulla(1.1);
                    break;
                case 1:
                    a = new Castagno(1.1);
                    break;
                default:
                    a = new Pino(1.1);
            }
            add(a);
        }
    }


}
