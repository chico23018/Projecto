package it.fabrick.accademy;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Main2 {

    public static void main(String args[]) throws IOException {
        String data = Files.readString(new File("file1.txt").toPath());

        //creo la stringa cifrata
        String cifra = new CifrarioCesare(-4)
                .cifra(data);

        //la ri-decifro
        String decifra = new CifrarioCesare(4)
                .cifra(cifra);

        System.out.println(cifra);
        System.out.println(decifra);

    }
}
