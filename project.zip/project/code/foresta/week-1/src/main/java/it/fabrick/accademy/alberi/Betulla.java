package it.fabrick.accademy.alberi;

import lombok.ToString;

@ToString(callSuper = true)
public class Betulla extends Albero {
    private final static double ALTEZZA_MAX = 3;

    public Betulla(double altezza) {
        super(Foglia.NORMALE, Tipo.BETTULA, altezza);
    }

    @Override
    double getAltezzaMax() {
        return Betulla.ALTEZZA_MAX;
    }



}
