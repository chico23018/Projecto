package it.fabrick.accademy.alberi;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Main {

    public static void main(String args[]) {
        Foresta f = new Foresta();
       f.populate(5);


    }
}
