package it.fabrick.accademy.ex;

public class PrimeNumber {

    public static int MX = 500000;
    //ho trovato 41539 primi in 7754
    //ho trovato 41538 primi in 3839


    public static void main(String[] args) {
        long start;
        long time;
        int primi;
/*
        primi = 0;
        start = System.currentTimeMillis();
        for (int i = 1; i < MX; i++) {
            if (isPrime(i))
                primi++;
        }
        time = System.currentTimeMillis() - start;
        System.out.println("ho trovato " + primi + " primi in " + time);
*/
        primi = 0;
        start = System.currentTimeMillis();
        for (int i = 1; i < MX; i++) {
            if (isPrimeA(i))
                primi++;
        }
        time = System.currentTimeMillis() - start;
        System.out.println("ho trovato " + primi + " primi in " + time);

    }

    private static boolean isPrime(int n) {
        for (int i = 2; i < n; i++) {
            if (n % i == 0)
                return false;
        }
        return true;
    }

    private static boolean isPrimeA(int n) {
        if (n != 2 && n % 2 == 0)
            return false;

        int l = (int) Math.ceil(Math.sqrt(n));
        for (int i = 3; i <= l; i += 2) {
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
