package it.fabrick.accademy.alberi;

public class InvalidState extends Exception{

    public InvalidState(String message) {
        super(message);
    }
}
