package it.fabrick.accademy.paymentGateway;

public enum PaymentType {
    GOOGLE,
    MASTERCARD,
    VISA
}
