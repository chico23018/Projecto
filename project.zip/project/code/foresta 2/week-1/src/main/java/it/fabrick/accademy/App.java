package it.fabrick.accademy;


import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Hello world!
 */
public class App {


    public static void main(String[] args) {

        Map<UUID, String> map = new HashMap<>();

        for (int i = 0; i < 100; i++) {
            map.put(UUID.randomUUID(),
                    "ciao" + i);
        }

        for (UUID key : map.keySet()) {

        }

        for (String val : map.values()) {

        }

        for (Map.Entry<UUID,String> entry : map.entrySet()) {
            entry.getKey();
            entry.getValue();
        }
    }


}
