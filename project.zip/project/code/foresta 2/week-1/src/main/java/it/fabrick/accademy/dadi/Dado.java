package it.fabrick.accademy.dadi;

import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.Random;

@ToString(exclude = "rnd")
@RequiredArgsConstructor
public class Dado {
    private final int facce;
    private final Random rnd = new Random();


    public int roll() {
        return 1 + rnd.nextInt(facce);
    }
}
