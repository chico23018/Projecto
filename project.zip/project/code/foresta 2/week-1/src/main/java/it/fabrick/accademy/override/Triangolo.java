package it.fabrick.accademy.override;

public class Triangolo extends Forma {

    @Override
    public void out() {
        System.out.println("un triangolo");
    }
}
