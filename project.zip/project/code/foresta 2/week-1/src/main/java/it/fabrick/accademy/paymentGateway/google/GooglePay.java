package it.fabrick.accademy.paymentGateway.google;

import it.fabrick.accademy.paymentGateway.APaymentGateway;
import it.fabrick.accademy.paymentGateway.PaymentType;

import java.math.BigDecimal;

public class GooglePay extends APaymentGateway {
    private final long userId;

    public GooglePay(long userId) {
        super(PaymentType.GOOGLE);
        this.userId = userId;
    }

    @Override
    public boolean canPay() {
        return false;
    }

    protected void doPayInternal() {
        //faccio roba
        //faccio altra roba

    }

    protected BigDecimal getBalanceInternal() {
        System.out.println("readBal");
        return BigDecimal.ONE;
    }
}
