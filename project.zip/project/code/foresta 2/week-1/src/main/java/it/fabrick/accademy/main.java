package it.fabrick.accademy;


public class main {

    public static void main(String args[]) {

        for (int a = 1; a <= 10; a++) {
            for (int b = 1; b <= 10; b++) {
                int r = a * b;
                System.out.print(
                        String.format("% 5d",r)
                );
            }

            System.out.println();
        }
    }

}
