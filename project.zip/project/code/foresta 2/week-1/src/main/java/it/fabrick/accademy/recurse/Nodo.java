package it.fabrick.accademy.recurse;

public class Nodo {

    final String dati;
    final int generation;
    private Nodo[] children;
    private Nodo parent;

    public Nodo(String dati, int generation) {
        this.dati = dati;
        this.generation = generation;
    }

    public Nodo[] getChildren() {
        return children;
    }

    public void setChildren(Nodo[] children) {
        boolean haveAnyChild = false;
        this.children = children;
        if (children != null) {
            for (int i = 0; i < children.length; i++) {
                if (children[i] != null) {
                    children[i].parent = this;
                    haveAnyChild = true;
                }
            }
        }
        if (!haveAnyChild)
            this.children = null;
    }

    public String getDati() {
        return dati;
    }


    @Override
    public String toString() {
        String buf = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t".substring(0, generation);
        return "\n" + buf +
                "dati='" + dati + '\'' +
                " gen='" + generation + '\'' +

                " ch='" + children + '\'';

    }
}
