package it.fabrick.accademy;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CifrarioCesare {

    int shift;



/*
    a = 97

    pino = 'z' //122

    pino -= 'a' //25

    pino = 25;

    pino+=3; //28

    pino = pino % 25; //

    pino = 4

    pino += 'a'
*/

    public String cifra(String data) {
        StringBuilder sb = new StringBuilder();
        int q = 'z' - 'a' + 1;
        for (char c : data.toCharArray()) {
            c = Character.toLowerCase(c);
            if (c >= 'a' && c <= 'z') {
                c = (char) (c + shift);

                if (c > 'z')
                    c -= q;
                if (c < 'a')
                    c += q;

                sb.append(c);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

}
