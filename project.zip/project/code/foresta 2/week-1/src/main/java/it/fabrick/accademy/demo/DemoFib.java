package it.fabrick.accademy.demo;

import java.io.IOException;

public class DemoFib {

    public static int fibonacci(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void fib(int qty) {
        int a = 0, b = 1, v;
        for (int i = 2; i <= qty; i++) {
            v = a + b;

            a = b;
            b = v;
        }
    }

    public static void main(String args[]) throws IOException {
        long start = System.currentTimeMillis();
        int fibN = 30;
        fib(fibN);
        System.out.println(System.currentTimeMillis() - start);

        start = System.currentTimeMillis();
        for (int i = 2; i <= fibN; i++) {
            fibonacci(i);
        }
        System.out.println(System.currentTimeMillis() - start);


    }


}
