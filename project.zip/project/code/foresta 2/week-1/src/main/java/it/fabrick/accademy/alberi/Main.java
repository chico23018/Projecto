package it.fabrick.accademy.alberi;

public class Main {

    public static void main(String args[]) throws InvalidState {

        Foresta f = new Foresta();
        f.add(new Betulla(1.2));
        
        f.populate(14);
        f.fiorisciQualcheAlbero(Albero.Specie.BETULLA);
      /*  f.fiorisciQualcheAlbero(Albero.Specie.CASTAGNO);
        f.fiorisciQualcheAlbero(Albero.Specie.PINO);*/
        System.out.println(
                f.getElencoDiSpecie(Albero.Specie.BETULLA)
        );
     /*   System.out.println(
                f.getElencoDiSpecie(Albero.Specie.CASTAGNO)
        );
        System.out.println(
                f.getElencoDiSpecie(Albero.Specie.PINO)
        );*/
    }
}
