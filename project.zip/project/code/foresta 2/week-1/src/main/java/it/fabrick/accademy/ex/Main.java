package it.fabrick.accademy.ex;


import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        String text =
                "ho un agtto " +
                        "ciao mi chiamo matteo " +
                        "ho un agtto gatto e due figli";

        String anagramma = "gatto"; //questa e' gatto

        String[] arrayDiParole = text.split(" ");

        for (String str : arrayDiParole) {
            boolean magic = str.length() == anagramma.length();
            if (magic) {
                magic = compareAnagramma(str, anagramma);
            }
            if (magic)
                System.out.println(str + " e' anagramma di " + anagramma);
        }
    }

    private static boolean compareAnagramma(String token, String anagramma) {
        return Arrays.equals(token.getBytes(), anagramma.getBytes());
    }
}
