package it.fabrick.accademy.paymentGateway.visa;

import it.fabrick.accademy.paymentGateway.Currency;

public class Wallet {
    final Visa gbp;
    final Visa usd;
    final Visa eur;

    public Wallet(int userId) {
        this.gbp = new Visa(userId, Currency.GBP);
        this.usd = new Visa(userId, Currency.USD);
        this.eur = new Visa(userId, Currency.EUR);
    }

    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (!(obj instanceof Wallet))
            return false;
        Wallet tmp = (Wallet) obj;
        return this.eur.equals(tmp.eur) &&
                this.usd.equals(tmp.usd) &&
                this.gbp.equals(tmp.gbp);
    }
}
