package it.fabrick.accademy.paymentGateway.visa;

import it.fabrick.accademy.paymentGateway.APaymentGateway;
import it.fabrick.accademy.paymentGateway.Currency;
import it.fabrick.accademy.paymentGateway.PaymentType;

import java.math.BigDecimal;
import java.util.Objects;

public class Visa extends APaymentGateway
        implements Comparable {
    final int userId;
    final Currency divisa;

    public Visa(int userId, Currency divisa) {
        super(PaymentType.VISA);
        this.userId = userId;
        this.divisa = divisa;
    }

    @Override
    public boolean canPay() {
        return false;
    }

    @Override
    protected void doPayInternal() {

    }

    protected BigDecimal getBalanceInternal() {
        System.out.println("readBal");
        return BigDecimal.ONE;
    }

    public int hashCode() {
        return Objects.hash(userId
                , divisa);
    }

    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (!(obj instanceof Visa))
            return false;
        Visa tmp = (Visa) obj;
        return tmp.userId == this.userId &&
                tmp.divisa == this.divisa;
/*
        return ((Mastercard)obj).userId
                .equals(this.userId);
                */

    }


    @Override
    public int compareTo(Object obj) {
        if (!(obj instanceof Visa))
            return -1;
        Visa tmp = (Visa) obj;
/*
METODO CREATIVO NON CONSIGLIATO
        String p1 = userId+"#"+divisa;
        String p2= tmp.userId+"#"+tmp.divisa;
        return p1.compareTo(p2);
   */
        if (userId == tmp.userId) {
            return divisa.compareTo(tmp.divisa);
        }

        return Integer.compare(userId, tmp.userId);

        /*
        CON IF INLINE
        return (userId == tmp.userId ?
                divisa.compareTo(tmp.divisa) :
                Integer.compare(userId,tmp.userId));
*/


    }
}
