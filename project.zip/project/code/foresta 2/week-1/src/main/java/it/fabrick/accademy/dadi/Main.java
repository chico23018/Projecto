package it.fabrick.accademy.dadi;

public class Main {

    private static final int LOOP = 100000;

    public static void main(String args[]) {
        Gioco gioco = new Gioco(5,
                13
        );

        int count = 0;
        for (int i = 0; i < LOOP; i++) {
            gioco.partita();
            if (gioco.getFourOfAKind() > 0)
                count++;
        }
        System.out.println(gioco.toString());
    }
}
