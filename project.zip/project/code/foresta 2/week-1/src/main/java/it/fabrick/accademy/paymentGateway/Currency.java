package it.fabrick.accademy.paymentGateway;

public enum Currency {
    EUR(1.),
    GBP(3.),
    USD(2.);

    final double cambio;

    Currency(double cambio) {
        this.cambio = cambio;
    }

    public void doSomething() {

    }
}
