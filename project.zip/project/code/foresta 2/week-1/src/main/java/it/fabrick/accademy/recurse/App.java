package it.fabrick.accademy.recurse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class App {

    public static void main(String args[]) throws JsonProcessingException {

        Nodo current =
                generate(0);
        ObjectMapper mapper = new ObjectMapper();
        System.out.println(
                mapper.writeValueAsString(current)

        );

        //analize(current);

    }


    public static Nodo generate(int gen) {

        if (gen == 5)
            return null;

        Nodo generato = new Nodo(
                "node#" + gen,
                gen
        );

        int figli = (int) (Math.random() * 10) + 1;
        Nodo[] children = new Nodo[figli];

        for (int i = 0; i < children.length; i++)
            children[i] = generate(gen + 1);

        generato.setChildren(
                children
        );


        return generato;
    }

    public static void analize(Nodo current) {
        if (current == null)
            return;

        System.out.println("analizzo " + current.dati + " gen " + current.generation);

        analize(current.getChildren()[0]);
        analize(current.getChildren()[1]);
        //...

    }
}
