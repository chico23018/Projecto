package it.fabrick.accademy.alberi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Foresta {

    private final Map<Albero.Specie, List<Albero>> mappaDiAlberi
            = new HashMap<>();

    public void add(Albero albero) {
        /*
        if (!mappaDiAlberi.containsKey(albero.getSpecie())) {
            mappaDiAlberi.put(albero.getSpecie(),new ArrayList<>());
        }
        mappaDiAlberi.get(albero.getSpecie()).add(albero);
        */

        List<Albero> tmp =
                mappaDiAlberi.computeIfAbsent(albero.getSpecie(), k -> new ArrayList<>());
      //  if (tmp == null) {
        tmp.add(albero);
    }

    public void clear() {
        mappaDiAlberi.clear();
    }

    public void populate(int n) throws InvalidState {
        for (int i = 0; i < n; i++) {
            Albero a;
            switch ((int) (Math.random() * 3)) {
                case 0:
                    a = new Betulla(Math.random() * 2);
                    break;
                case 1:
                    a = new Castagno(Math.random() * 8);
                    break;
                default:
                    a = new Pino(Math.random() * 20);

            }
            add(a);
        }
    }

    public List<Albero> getElencoDiSpecie(Albero.Specie specie) {
        return mappaDiAlberi.get(specie);
    }


    public void fiorisciQualcheAlbero(Albero.Specie specie) throws InvalidState {

        for (int i = 0; i <mappaDiAlberi.get(specie).size()/2 ; i++) {
            mappaDiAlberi.get(specie).get(i).fioritura();
        }
       /* for (Albero al:mappaDiAlberi.get(specie)){
            al.fioritura();
        }*/


    }
}
