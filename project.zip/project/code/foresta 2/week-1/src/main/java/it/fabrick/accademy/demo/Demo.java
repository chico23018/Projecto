package it.fabrick.accademy.demo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

public class Demo {

    public static void a(File dir) {
        File[] inThisFolder = dir.listFiles();
        for (int i = 0;i<inThisFolder.length;i++) {
            if (inThisFolder[i].isDirectory()) {
                a(inThisFolder[i]);
            } else if (inThisFolder[i].getName().startsWith("A")) {
                System.out.println(inThisFolder[i].getAbsoluteFile());
            }
        }

    }

    public static void main(String args[]) throws IOException {
        a(new File("."));
    }


}
