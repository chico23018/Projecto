package it.fabrick.accademy.paymentGateway;

public class Const {

    public static String pay1 = "g";
    public static String pay2 = "m";

    private Const() {

    }
}
