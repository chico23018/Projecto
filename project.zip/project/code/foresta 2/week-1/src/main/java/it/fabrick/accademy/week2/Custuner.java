package it.fabrick.accademy.week2;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public abstract class Custuner {
    private int fiscalCode;
    private String nome;
}
