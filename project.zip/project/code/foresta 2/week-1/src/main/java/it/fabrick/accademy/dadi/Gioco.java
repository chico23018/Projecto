package it.fabrick.accademy.dadi;


import lombok.Getter;
import lombok.ToString;

@ToString
public class Gioco {
    final Dado[] dadi;
    final int facce;

    @Getter
    private int pair;
    @Getter
    private int threeOfAKind;
    @Getter
    private int fourOfAKind;

    public Gioco(int n, int facce) {
        this.facce = facce;
        dadi = new Dado[n];
        for (int i = 0; i < n; i++)
            dadi[i] = new Dado(facce);

        pair = -1;
        threeOfAKind = -1;
        fourOfAKind = -1;

    }

    public void partita() {
        reset();

        int[] risultati = new int[facce];
        for (Dado dado : dadi) {
            int roll = dado.roll() - 1;
            risultati[roll] = risultati[roll] + 1;
        }

        for (int i = 0; i < facce; i++) {
            switch (risultati[i]) {
                case 0:
                case 1:
                    break;
                case 2:
                    pair++;
                    break;
                case 3:
                    threeOfAKind++;
                    break;
                default:
                    fourOfAKind++;
            }
        }


    }

    public void results() {
        if (pair == -1)
            System.err.println("errore, non hai fatto parita");
        else
            System.out.println(
                    "pair " + pair +
                            " threeOfAKind " + threeOfAKind +
                            " fourOfAKind " + fourOfAKind
            );
    }

    public void reset() {
        pair = 0;
        threeOfAKind = 0;
        fourOfAKind = 0;
    }
}
