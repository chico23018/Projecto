package it.fabrick.accademy.override;

public class Main {


    public static void main(String args[]) {
        Forma p = new Triangolo();

        p.out();
    }
}
