package it.fabrick.accademy.ex;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class FileMatch {

    public FileMatch() {
    }

    public static void main(String[] args) throws Throwable {

        ArrayList<String> lines1 = readFile("file1.txt");
        ArrayList<String> lines2 = readFile("file2.txt");

        for (String line : lines1) {
            if (line != null) {
                String[] tokens = line.split(" ");
                for (String token : tokens) {
                    analizza(token, lines2);
                }
            }
        }

    }

    public static void analizza(String token, ArrayList<String> lines2) {
        int count = 0;
        for (String str : lines2) {
            if (str == null)
                continue;
            String[] tokens2 = str.split(" ");
            for (String token2 : tokens2) {
                if (token2.equals(token))
                    count++;
            }
        }
        if (count > 0)
            System.out.println("tok " + token + " trovato " + count);

    }

    public static ArrayList<String> readFile(String file) throws Throwable {

        //List<String> s = Files.readAllLines(new File(file).toPath());

        ArrayList<String> result = new ArrayList<>();

        try (BufferedReader bis =
                     new BufferedReader(
                             new FileReader(file)
                     )
        ) {
            //leggo il file
            String line;
            while ((line = bis.readLine()) != null) {
                result.add(line);
            }
        }

        return result;
    }

}
