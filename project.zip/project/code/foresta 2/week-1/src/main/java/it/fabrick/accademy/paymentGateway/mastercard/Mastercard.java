package it.fabrick.accademy.paymentGateway.mastercard;

import it.fabrick.accademy.paymentGateway.APaymentGateway;
import it.fabrick.accademy.paymentGateway.PaymentType;

import java.math.BigDecimal;

public class Mastercard
        extends APaymentGateway implements Comparable {
    final String userId;

    public Mastercard(String userId) {
        super(PaymentType.MASTERCARD);
        this.userId = userId;
    }

    @Override
    public boolean canPay() {
        return false;
    }


    protected void doPayInternal() {

    }

    protected BigDecimal getBalanceInternal() {
        System.out.println("readBal");
        return BigDecimal.ONE;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Mastercard))
            return false;
        Mastercard tmp = (Mastercard) obj;
        return tmp.userId
                .equals(this.userId);
/*
        return ((Mastercard)obj).userId
                .equals(this.userId);
                */

    }

    @Override
    public int compareTo(Object obj) {
        if (!(obj instanceof Mastercard))
            return -1;
        Mastercard tmp = (Mastercard) obj;

        return tmp.userId.compareTo(this.userId);
    }
}
