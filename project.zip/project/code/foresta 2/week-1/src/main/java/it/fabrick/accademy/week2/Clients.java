package it.fabrick.accademy.week2;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Clients {
    private String boo;


}
