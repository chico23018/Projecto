package it.fabrick.accademy.paymentGateway;

import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

public abstract class APaymentGateway {
    private long cost;
    private BigDecimal balance;
    private long nextRead = 0;

    public PaymentType getType() {
        return type;
    }

    private final PaymentType type;

    protected APaymentGateway(PaymentType type) {
        this.type = type;
    }

    abstract public boolean canPay();

    public final void doPay() {
        long start = System.currentTimeMillis();
        doPayInternal();
        cost = System.currentTimeMillis() - start;
    }

    protected abstract void doPayInternal();

    public final BigDecimal getBalance() {
        if (nextRead <= System.currentTimeMillis()) {
            nextRead = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(1);
            balance = getBalanceInternal();
        }
        return balance;
    }

    protected abstract BigDecimal getBalanceInternal();

    public long getCost() {
        return cost;
    }

    /*
        Realizziamo un metodo nella classe APaymentGateway, lo chiamiamo «summary» e lo definiamo di tipo «void»
        Il metodo deve stampare a video
        Good (se cost < 10)
        Avg (se cost da 10 a 100)
        Bad (se piu’ di 100)
    */
    public void summary() {
        if (cost < 10)
            System.out.println("good");
        else if (cost <= 100)
            System.out.println("avg");
        else
            System.out.println("bad");
    }

    public void test() {

    }

    public boolean enoughMoney0(BigDecimal spesa) {
        return balance.compareTo(spesa) > 0;
    }

    public boolean enoughMoney(BigDecimal spesa) {
        if (balance.compareTo(spesa) > 0)
            return true;
        return false;
    }
}
