package it.fabrick.accademy.override;

public class Forma {


    public void out() {
        System.out.println("sono una forma");
    }
}
