package it.fabrick.accademy;


/**
 * Unit test for simple App.
 */
public class AppTest 
{

}
