package it.fabrick.academy.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class MovieConfiguration {

    @Bean
    public RestTemplate template() {
        return new RestTemplate();
    }
}
