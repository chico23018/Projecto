package it.fabrick.academy.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Parameter;
import it.fabrick.academy.dto.DirectorDto;
import it.fabrick.academy.dto.DirectorRequestDto;
import it.fabrick.academy.service.MovieService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1.0/directors")
public class MovieController {
    private final MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping
    public List<DirectorDto> readDirector() throws JsonProcessingException {
        return movieService.readDirector();
    }
    @GetMapping("/exchange")
    public List<DirectorDto> readDirectorWithExchange()  {
        return movieService.readDirectorWithExchange();
    }
    @PostMapping
    public DirectorDto createDirector(@RequestBody DirectorRequestDto directorRequestDto){
       return this.movieService.createDirector(directorRequestDto);
    }
    @PostMapping("/exchange")
    public DirectorDto createDirectorExchange(@RequestBody DirectorRequestDto directorRequestDto){
        return this.movieService.createDirectorDtoExchange(directorRequestDto);
    }
    @PutMapping("/{uuid}")
    public DirectorDto putDirectorExchange(@PathVariable("uuid") String uui, @RequestBody DirectorRequestDto directorRequestDto){
        return this.movieService.updateDirectorExchange(uui,directorRequestDto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteDirectorExchange(@PathVariable("uuid") String uui){
         this.movieService.deleteDirectorExchange(uui);
    }
  /*  @DeleteMapping("/{uuid}/movies/{uuidMovie}")
    public void deleteMovieExchange(@PathVariable("uuid") String uui,@PathVariable("uuidMovie") String uuidMovie){
        this.movieService.deleteMovieExchange(uui, uuidMovie);
    }*/
    @DeleteMapping("/{uuid}/movies/{uuidMovie}")
    public void deleteMovieExchangeds(@PathVariable("uuid") String uui,@PathVariable("uuidMovie") String uuidMovie) throws JsonProcessingException {
        this.movieService.deleteDirector(uui, uuidMovie);
    }
}
