package it.fabrick.academy.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.fabrick.academy.dto.DirectorDto;
import it.fabrick.academy.dto.DirectorRequestDto;
import it.fabrick.academy.dto.ErrorDto;
import it.fabrick.academy.dto.MovieDto;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilderFactory;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;


@Service
@Slf4j
public class MovieService {
    private final RestTemplate template;
    private final ObjectMapper objectMapper;
    private final Logger logger;

    public MovieService(RestTemplate template, ObjectMapper objectMapper) {
        this.template = template;
        this.objectMapper = objectMapper;
        this.logger =  LoggerFactory.getLogger(this.getClass());
    }

    public List<DirectorDto> readDirector() throws JsonProcessingException {

        try {
            String response = this.template.getForObject("http://localhost:8080/v1.0/directors", String.class);
            List<DirectorDto> dire = objectMapper.readValue(response, new TypeReference<List<DirectorDto>>() {
            });
            return dire;
        } catch (RestClientResponseException v) {

            return null;
        } catch (RestClientException e) {
            ((HttpClientErrorException) e.getMostSpecificCause()).getRawStatusCode();
            return null;
        }
    }

    public List<DirectorDto> readDirectorWithExchange() {
        HttpHeaders headers = new HttpHeaders();
        headers.addAll("x-plutp", Arrays.asList("paperono","ciao"));
        HttpEntity<Void> httpEntity = new HttpEntity<>(headers);

         UriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory("http://localhost:8080/v1.0/directors");
        URI uri= uriBuilderFactory.builder().queryParam("name","Ridley Scott").build();
      return this.template.exchange(uri, HttpMethod.GET
                , httpEntity, new ParameterizedTypeReference<List<DirectorDto>>() {
                }).getBody();
    }

    public DirectorDto createDirector(DirectorRequestDto directorRequestDto) {
        return this.template.postForObject("http://localhost:8080/v1.0/directors", directorRequestDto, DirectorDto.class);
    }

    public DirectorDto createDirectorDtoExchange(DirectorRequestDto directorRequestDto) {
        HttpEntity<DirectorRequestDto> httpEntity = new HttpEntity<>(directorRequestDto);
        return this.template.exchange("http://localhost:8080/v1.0/directors"
                        , HttpMethod.POST
                        , httpEntity
                        , DirectorDto.class)
                .getBody();
    }

    public DirectorDto updateDirector(String uuid, DirectorRequestDto directorRequestDto) {

        HttpEntity<DirectorRequestDto> httpEntity = new HttpEntity<>(directorRequestDto);
        UriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory("http://localhost:8080/v1.0/directors");
      URI uri= uriBuilderFactory.builder().queryParam("uuid",uuid).build();
        return this.template.exchange(uri
                        , HttpMethod.PUT
                        , httpEntity
                        , DirectorDto.class)
                .getBody();
    }

    public DirectorDto updateDirectorExchange(String uuid, DirectorRequestDto directorRequestDto) {
        HttpEntity<DirectorRequestDto> httpEntity = new HttpEntity<>(directorRequestDto);
        return this.template.exchange("http://localhost:8080/v1.0/directors/" + uuid
                        , HttpMethod.PUT
                        , httpEntity
                        , DirectorDto.class)
                .getBody();
    }

    public DirectorDto deleteDirectorExchange(String uuid) {
        HttpEntity<Void> httpEntity = new HttpEntity<>(null);
        return this.template.exchange("http://localhost:8080/v1.0/directors/" + uuid
                        , HttpMethod.DELETE
                        , httpEntity
                        , DirectorDto.class)
                .getBody();
    }

    public MovieDto deleteMovieExchange(String uuidDirector, String uuidMovie) {
        HttpEntity<Void> httpEntity = new HttpEntity<>(null);
        return this.template.exchange("http://localhost:8080/v1.0/directors/" + uuidDirector + "/movies/" + uuidMovie
                        , HttpMethod.DELETE
                        , httpEntity
                        , MovieDto.class)
                .getBody();
    }

    public void deleteDirector(String uuidDirector, String uuidMovie) throws JsonProcessingException {
        DirectorDto d = readDirectorWithExchange().get(0);

        UriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory("http://localhost:8080/v1.0/directors");
        URI uri= uriBuilderFactory.builder().queryParam("name","Ridley Scott").build();

        try {
            template.delete("http://localhost:8080/v1.0/directors/" + uuidDirector + "/movies/" + UUID.randomUUID());
        } catch (RestClientResponseException e) {
            String response = e.getResponseBodyAsString();
            ErrorDto errorDto = objectMapper.readValue(response, ErrorDto.class);
            logger.error(errorDto.getErrorCode());


            if ("INTERNAL_ERROR".equals(errorDto.getErrorCode()) | "DATA_NOT_VALID".equals(errorDto.getErrorCode()) | " DATA_NOT_FOUND".equals(errorDto.getErrorCode())) {

            }

        }
    }
}
