package it.fabrick.academy.serializer;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DataDeserializer extends StdDeserializer<ZonedDateTime> {
    public DataDeserializer(Class<?> vc) {
        super(vc);
    }

    public DataDeserializer() {
        this(null);
    }

    @Override
    public ZonedDateTime deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException, JacksonException {
        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        if (jsonNode == null|| jsonNode.isNull() ) {
            return null;

        }


        String  birthDate = jsonNode.asText();
        LocalDate localDate = LocalDate.parse(birthDate,DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        return ZonedDateTime.ofInstant(Instant.ofEpochMilli(localDate.toEpochDay()), ZoneId.systemDefault());

    }
}
