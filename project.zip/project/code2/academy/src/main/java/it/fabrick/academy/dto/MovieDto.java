package it.fabrick.academy.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

public class MovieDto {
   // @JsonProperty("uuid")
    private String id;
    private String title;
    private Integer durationInMinutes;
    private String year;
    private Integer score;

    public MovieDto(String id, String title, Integer durationInMinutes, String year, Integer score) {
        this.id = id;
        this.title = title;
        this.durationInMinutes = durationInMinutes;
        this.year = year;
        this.score = score;
    }

    public MovieDto() {
    }

    public String getId() {
        return id;
    }

    @JsonSetter("uuid")
    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setDurationInMinutes(Integer durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
