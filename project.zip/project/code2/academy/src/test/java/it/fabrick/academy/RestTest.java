package it.fabrick.academy;

import com.fasterxml.jackson.databind.ObjectMapper;
import it.fabrick.academy.dto.DirectorRequestDto;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;

@SpringBootTest
@AutoConfigureMockMvc
public class RestTest {
    @Autowired
    MockMvc mockMvc;
    @Autowired
    ObjectMapper objectMapper;

    @Test
    void shouldCreate() throws Exception {
        String name = "javier";
        DirectorRequestDto directorRequestDto = new DirectorRequestDto();
        directorRequestDto.setName(name);
        directorRequestDto.setBirthDate(LocalDate.parse("2023-01-01"));
        String content = objectMapper.writeValueAsString(directorRequestDto);
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/exchange")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is(name)));
    }
}

