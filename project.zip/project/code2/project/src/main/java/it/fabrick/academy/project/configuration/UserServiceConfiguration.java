package it.fabrick.academy.project.configuration;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.IRepository;
import it.fabrick.academy.project.service.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class UserServiceConfiguration {
    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IService ReadUser(@Qualifier(Constant.READ_MESSAGE)List<IRepository> iRepositories){
        return  new ReadUser(iRepositories);
    }
  @Bean
    public IService CreateUser(@Qualifier(Constant.CREATE_MESSAGE)List<IRepository> iRepositories){
        return  new CreateUser(iRepositories);
    }
    @Bean
    public IService UpdateUser(@Qualifier(Constant.UPDATE_MESSAGE)List<IRepository> iRepositories){
        return  new UpdateUser(iRepositories);
    }
    @Bean
    public IService DeleteUser(@Qualifier(Constant.DELETE_MESSAGE)List<IRepository> iRepositories){
        return  new DeleteUser(iRepositories);
    }

}
