package it.fabrick.academy.project.configuration;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.CreateRepository;
import it.fabrick.academy.project.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CreateRepositoryConfiguration {
    @Bean
    @Qualifier(Constant.CREATE_MESSAGE)
    public IRepository createRepository() {
        return new CreateRepository();
    }
    @Bean
    @Qualifier(Constant.CREATE_MESSAGE)
    public IRepository createRepository2() {
        return new CreateRepository();
    }



}
