package it.fabrick.academy.project.configuration;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.CreateRepository;
import it.fabrick.academy.project.repository.DeleteRepository;
import it.fabrick.academy.project.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DeleteRepositoryConfiguration {

    @Bean
    @Qualifier(Constant.DELETE_MESSAGE)
    public IRepository deleteRepository2() {
        return new DeleteRepository();
    }



}
