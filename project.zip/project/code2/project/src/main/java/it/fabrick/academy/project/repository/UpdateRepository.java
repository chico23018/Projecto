package it.fabrick.academy.project.repository;

import it.fabrick.academy.project.constants.Constant;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


public class UpdateRepository implements IRepository{
    @Override
    public String doStaff() {
        return Constant.UPDATE_MESSAGE;
    }
}
