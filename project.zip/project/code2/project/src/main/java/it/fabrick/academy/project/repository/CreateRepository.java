package it.fabrick.academy.project.repository;

import it.fabrick.academy.project.constants.Constant;


public class CreateRepository implements IRepository{
    @Override
    public String doStaff() {
        return Constant.CREATE_MESSAGE;
    }
}
