package it.fabrick.academy.project.repository;

public interface IRepository {
    String doStaff();
}
