package it.fabrick.academy.project.repository;

import it.fabrick.academy.project.constants.Constant;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


public class ReadRepository implements IRepository{
    @Override
    public String doStaff() {
        return Constant.READ_MESSAGE;
    }
}
