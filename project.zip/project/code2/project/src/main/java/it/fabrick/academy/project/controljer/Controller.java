package it.fabrick.academy.project.controljer;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.service.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Controller {
    private final List<IService> iServices;

    public Controller(List<IService> iServices) {
        this.iServices = iServices;
    }

    public List<String> readUser() {
        Optional<List<String>> op = iServices.stream()
                .filter(x -> x.getClass().toString().equals(ReadUser.class.toString()))
                .map(IService::readMessages).findFirst();
        return op.orElse(null);




    }


    public List<String> createUser() {
        Optional<List<String>> op = iServices.stream()
                .filter(x -> x.getClass().toString().equals(CreateUser.class.toString()))
                .map(IService::readMessages).findFirst();
        return op.orElse(null);

    }


    public List<String> updateUser() {
        Optional<List<String>> op = iServices.stream()
                .filter(x -> x.getClass().toString().equals(UpdateUser.class.toString()))
                .map(IService::readMessages).findFirst();
        return op.orElse(null);

    }


    public List<String> deleteUser() {
        Optional<List<String>> op = iServices.stream()
                .filter(x -> x.getClass().toString().equals(DeleteUser.class.toString())&& x.readMessages().contains(Constant.DELETE_MESSAGE))
                .map(IService::readMessages).findFirst();
        return op.orElse(null);

    }
}
