package it.fabrick.academy.project.service;

import java.util.List;

public interface IService {
    List<String> readMessages();
}
