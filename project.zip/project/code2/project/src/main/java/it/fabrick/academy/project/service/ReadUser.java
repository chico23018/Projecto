package it.fabrick.academy.project.service;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class ReadUser implements IService {
    private final List<IRepository> iRepositories;

    public ReadUser(List<IRepository>  iRepositories) {
        this.iRepositories = iRepositories;
    }

    @Override
    public List<String> readMessages() {
        return iRepositories.stream().map(x->x.doStaff()).collect(Collectors.toList());
    }
}
