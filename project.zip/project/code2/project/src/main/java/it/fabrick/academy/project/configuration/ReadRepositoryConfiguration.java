package it.fabrick.academy.project.configuration;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.IRepository;
import it.fabrick.academy.project.repository.ReadRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ReadRepositoryConfiguration {
    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository() {
        return new ReadRepository();
    }
    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository2() {
        return new ReadRepository();
    }
    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository3() {
        return new ReadRepository();
    }


}
