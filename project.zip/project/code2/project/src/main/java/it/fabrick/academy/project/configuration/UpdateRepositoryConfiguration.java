package it.fabrick.academy.project.configuration;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.repository.CreateRepository;
import it.fabrick.academy.project.repository.IRepository;
import it.fabrick.academy.project.repository.UpdateRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UpdateRepositoryConfiguration {
    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository() {
        return new UpdateRepository();
    }
    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository1() {
        return new UpdateRepository();
    }
    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository2() {
        return new UpdateRepository();
    }
    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository3() {
        return new UpdateRepository();
    }



}
