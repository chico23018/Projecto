package it.fabrick.academy.project;

import it.fabrick.academy.project.constants.Constant;
import it.fabrick.academy.project.controljer.Controller;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class ProjectApplicationTests {
    @Autowired
    private Controller controller;

    @Test
    void contextLoads() {
    }
    @Test
    void shouldReadUser(){

      List<String> list=  controller.readUser();
      assertEquals(3,list.size());
      this.evaluateMessages(Constant.READ_MESSAGE,list);
    }
    @Test
    void shouldCreateUser(){
        List<String> list=  controller.createUser();
        assertEquals(2,list.size());
        this.evaluateMessages(Constant.CREATE_MESSAGE,list);
    }
    @Test
    void shouldUpdateUser(){
        List<String> list=  controller.updateUser();
        assertEquals(4,list.size());
        this.evaluateMessages(Constant.UPDATE_MESSAGE,list);
    }
    @Test
    void shouldDeleteUser(){
        List<String> list=  controller.deleteUser();
        assertEquals(1,list.size());
        this.evaluateMessages(Constant.DELETE_MESSAGE,list);
    }
    private void evaluateMessages(String expected,List<String> messages){
        for(String message :messages){
            System.out.println(message);
            Assertions.assertEquals(expected,message);
        }
    }

}
