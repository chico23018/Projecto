package it.fabrick.academy.week4;

public class EasyRepository implements ISampleRepository{
}
