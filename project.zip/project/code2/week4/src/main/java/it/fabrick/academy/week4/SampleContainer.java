package it.fabrick.academy.week4;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SampleContainer {
    private final List<ISampleRepository>iSampleRepositories;
    public SampleContainer(List<ISampleRepository> iSampleRepositories){
        this.iSampleRepositories= iSampleRepositories;
    }

    public List<ISampleRepository> getISampleRepositories() {
        return iSampleRepositories;
    }
}
