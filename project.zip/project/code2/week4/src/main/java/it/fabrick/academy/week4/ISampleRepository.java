package it.fabrick.academy.week4;

public interface ISampleRepository  {
}
