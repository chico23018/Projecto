package it.fabrick.academy.week4;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Configuration
public class SampleConfiguration {


    @Bean
    @Primary
    public ISampleRepository easyRepository() {
        return new EasyRepository();
    }

    @Bean
    public ISampleRepository sampleRepository() {
        return new SampleRepository();
    }

    @Bean
    @Qualifier(value = Constant.REPOSITORY_WITH_QUALIFIER)
    public ISampleRepository qualifiedRepository() {
        return new SampleRepository();
    }

    @Bean
    @Qualifier(value = Constant.REPOSITORY_WITH_PROFILE)
    @Profile(value = Constant.ENV_STAGING)
    public ISampleRepository stagingRepository(){
        return  new EasyRepository();
    }

    @Bean
    @Qualifier(value = Constant.REPOSITORY_WITH_PROFILE)
    @Profile(value = Constant.ENV_DEV)
    public ISampleRepository devRepository(){
        return  new SampleRepository();
    }
    @Bean
    @Qualifier(value = Constant.REPOSITORY_WITH_PROFILE)
    @Profile(value = Constant.ENV_DEFAULT)
    public ISampleRepository defaultRepository(){
        return  new SampleRepository();
    }

    @Bean
    @Qualifier(value = Constant.REPOSITORY_WITH_PROFILE)
    public SampleService qualifiedSampleService(@Qualifier(value = Constant.REPOSITORY_WITH_PROFILE)
                                                ISampleRepository iSampleRepository){
        return new SampleService(iSampleRepository);
    }

    @Bean
    public SampleService sampleService(ISampleRepository iSampleRepository) {
        return new SampleService(iSampleRepository);
    }

}
