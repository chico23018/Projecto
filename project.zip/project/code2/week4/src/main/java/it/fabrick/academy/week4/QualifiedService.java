package it.fabrick.academy.week4;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class QualifiedService {
    private final ISampleRepository iSampleRepository;

    public QualifiedService( @Qualifier(value = Constant.REPOSITORY_WITH_QUALIFIER)
                               ISampleRepository iSampleRepository) {
        this.iSampleRepository = iSampleRepository;
    }

    public String getRepository() {
        return iSampleRepository.getClass().toString();
    }
}
