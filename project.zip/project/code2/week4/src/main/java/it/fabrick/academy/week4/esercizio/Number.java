package it.fabrick.academy.week4.esercizio;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Number {
    public static void main(String[] args) {
        somma();
    }

    public static void somma() {
        Integer m[] = {1, 2, 3, 4, 5};

        for (Integer n : m) {
            System.out.print(" " + Arrays.stream(m).filter(x -> !x.equals(n)).reduce(0, Integer::sum));
        }
        System.out.println();
        for (Integer n : m) {

            System.out.print(" " + Arrays.stream(m).filter(x -> !x.equals(n)).mapToInt(x -> x).sum());
        }
        //14 13 12 11 10
        //--12--
        //3+9
        //-5 10 2 40 -3 4 9 200
        for (int i = 0, j = m.length; i < m.length; ) {

        }

       /* int b = 0;
        for (int a : m) {
            b += a;
        }
        int l = 0;
        for (int q : m) {
            l = b - q;
            System.out.print(l + ",");
        }*/
    }
}
