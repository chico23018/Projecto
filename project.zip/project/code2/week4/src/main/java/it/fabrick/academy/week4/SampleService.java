package it.fabrick.academy.week4;

import org.springframework.stereotype.Service;


public class SampleService {

    private final ISampleRepository isampleRepository ;


    public SampleService( ISampleRepository sampleRepository) {
        this.isampleRepository = sampleRepository;
    }
    public String getRepositoryType(){
       // String n = ""+isampleRepository.getClass().toString();
     return isampleRepository.getClass().toString();
    }
}
