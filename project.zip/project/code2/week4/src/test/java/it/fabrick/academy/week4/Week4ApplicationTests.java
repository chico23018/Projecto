package it.fabrick.academy.week4;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class Week4ApplicationTests {
    @Autowired
    private SampleService sampleService;
    @Autowired
    private QualifiedService qualifiedService;
    @Autowired
    private SampleContainer sampleContainer;

    @Test
    void contextLoads() {
    }

    @Test
    void shouldLoadService() {

        Assert.isTrue(sampleService != null, "Should not be null");
    }


    @Test
    void shouldLoadRepository() {
        String Expected = EasyRepository.class.toString();
        System.out.println(this.sampleService.getRepositoryType());
        assertEquals(Expected, sampleService.getRepositoryType(), "name the class");
    }

    @Test
    void notShouldLoadRepository() {
        String notExpected = SampleRepository.class.toString();
        assertNotEquals(notExpected, sampleService.getRepositoryType(), "name the class");
    }

    @Test
    void shouldLoadSampleRepository() {
        String Expected = SampleRepository.class.toString();
        System.out.println(qualifiedService.getRepository());
        assertEquals(Expected, qualifiedService.getRepository(), "name the class");
    }

    @Test
    void shouldLoadMoreRepository() {
      int size=  this.sampleContainer.getISampleRepositories().size();
        System.out.println(size);
        assertTrue(size>1,"should contains more than one repository ");
    }
}
