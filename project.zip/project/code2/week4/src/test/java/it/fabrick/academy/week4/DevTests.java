package it.fabrick.academy.week4;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(Constant.ENV_DEV)
public class DevTests {
    @Autowired
    @Qualifier(Constant.REPOSITORY_WITH_PROFILE)
    private SampleService sampleService;
    @Test
     void shouldLoadEasyRepository(){
        String expected = SampleRepository.class.toString();
        Assertions.assertEquals(expected,sampleService.getRepositoryType());
    }
}
