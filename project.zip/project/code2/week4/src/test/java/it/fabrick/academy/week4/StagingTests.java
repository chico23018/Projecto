package it.fabrick.academy.week4;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(Constant.ENV_STAGING)
public class StagingTests {
    @Autowired
    @Qualifier(Constant.REPOSITORY_WITH_PROFILE)
    private SampleService sampleService;
    @Test
     void shouldLoadEasyRepository(){
        String expected = EasyRepository.class.toString();
        Assertions.assertEquals(expected,sampleService.getRepositoryType());
    }
}
