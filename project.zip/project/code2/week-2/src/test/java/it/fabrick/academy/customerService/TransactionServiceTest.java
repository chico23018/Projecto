package it.fabrick.academy.customerService;

import it.fabrick.academy.enumclass.CustomerError;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.TransactionRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static it.fabrick.academy.enumclass.TransactionType.CASH;
import static org.junit.jupiter.api.Assertions.*;

class TransactionServiceTest {
   private static TransactionService transactionService = null;
    @BeforeAll
    static void saveAll() {
        transactionService= new TransactionService(new TransactionRepository());
        transactionService.saveAll(transactionService.importTransactionList("Transactions.txt"));
        assertNotNull(transactionService.findAll());
    }

    @Test
    void save() {
        transactionService.findAll().forEach(x-> System.out.println(x));
        CustomerException throwf = assertThrows(CustomerException.class,()->
            transactionService.save(new Transaction(100001,20.5,CASH,"10/10/2023 10:30:12","001"))
        );
        assertEquals(CustomerError.TRANSACTION_EXIST,throwf.print());
    }

    @Test
    void findById() {
        assertEquals(100001,transactionService.findById(100001).getIdTrans());
    }

    @Test
    void findByIdCustomer() {

    assertNotNull(  transactionService.findByIdCustomer("001") );
    }

    @Test
    void deleteById() {

        assertTrue(transactionService.deleteById(100001));
    }



}