package it.fabrick.academy.customerService;

import it.fabrick.academy.client.Individual;
import it.fabrick.academy.enumclass.CustomerError;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.repositoryimpl.CustomerRepository;
import org.junit.jupiter.api.*;

import java.io.IOException;

import static it.fabrick.academy.enumclass.CustomerType.IND;
import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CustomerServiceTest {
    static CustomerService customerService = null;

    @BeforeAll
    static void saveAll() throws IOException {
        customerService = new CustomerService(new CustomerRepository());
        customerService.saveAll(customerService.importCustomer("C:\\Users\\GBS09334\\Documents\\save"));

        assertNotNull(customerService.findAll());
    }

    @Test
    @Order(2)
    void save() {

        CustomerException thrown =
                assertThrows(CustomerException.class, () -> {
                    customerService.save(new Individual(IND, "001", "0255", "Francisco", "Acosta", 32, "20/02/2023"));
                });
        assertEquals(CustomerError.CUSTOMER_EXIST, thrown.print());
    }

    @Test
    @Order(3)
    void findAll() {
        assertTrue(customerService.findAll().size() > 0);
    }

    @Test
    @Order(4)
    void findById() throws CustomerException, IOException {
        assertEquals("001", customerService.findById("001").getId());
    }

    @Test
    @Order(5)
    void deleteById() {
        customerService.deleteById("001");
        CustomerException tr = assertThrows(CustomerException.class, () -> {
            customerService.findById("001");
        });
        assertEquals(CustomerError.CUSTOMER_MISSING, tr.print());
    }


}