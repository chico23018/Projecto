package it.fabrick.academy;


import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Company;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.customerService.CustomerService;
import it.fabrick.academy.customerService.TransactionService;
import it.fabrick.academy.enumclass.CustomerType;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.model.CustomerData;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.CustomerRepository;
import it.fabrick.academy.repositoryimpl.TransactionRepository;
import it.fabrick.academy.utility.CustomerUtility;
import org.junit.jupiter.api.*;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import static it.fabrick.academy.enumclass.CustomerError.CODE_MISSING;
import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class AppTest {
    static Set<ACustomer> customerList = null;
    static ACustomer customer2 = null;
    static Optional<ACustomer> c = null;
    static Optional<Transaction> tr = null;
    private static CustomerService customerService = new CustomerService(new CustomerRepository());
    private static TransactionService transactionService = new TransactionService(new TransactionRepository());

    @BeforeAll
    static void testCreateArray() throws IOException, CustomerException {
        customer2 = new Individual(CustomerType.IND, "2", "2656", "francisco", "Acosta", 30, "18/02/1991");
        customerList = customerService.importCustomer(new File("C:\\Users\\GBS09334\\Documents"));
        assertNotNull(customerList);
        String m = "COM;001;ABCDEF90O10B875R;pippo@fabrick.com;3201234567;Fabrick;Banking;400;02/03/2013";
        c = customerService.createCustomerI(m);
        c.orElseThrow(() -> {
            try {
                throw new CustomerException(CODE_MISSING," ");
            } catch (CustomerException e) {
                throw new RuntimeException(e);
            }
        });
        tr = transactionService.createTransaction("001;100016;50.1;CASH;18/02/2023 11:30:12");

    }

    @Test
    @Order(1)
    void testCreate() {
        assertNotNull(c);
        assertTrue(c.isPresent());
        ACustomer customer = c.get();
        assertEquals(customer.getClass(), Company.class, "Error sul tipo della class");
        assertEquals("001", customer.getId(), "Error sul ii di ritorno");
        assertNotNull(customer.getTransactions(), "è null la getTransactions");
        //  assertNull(customer.getTransactions(), "Non è null la getTransactions");

    }

    @Test
    @Order(2)
    void testCreateArrayTr() throws IOException {
        assertNotNull(customerList);
        CustomerUtility.addTransaction(customerList,  transactionService.importTransaction("Transactions.txt"));
        for (ACustomer m : customerList) {

            assertTrue(m.getTransactions().size() >= 1, "la size è null");
        }
    }


    @Test
    @Order(3)
    void testCreateTransaction() {

        ACustomer customer = c.get();
        assertTrue(tr.isPresent());

        Transaction ti = new Transaction(25, 100.25, TransactionType.BANK_TRANSFER, "25/06/2023 11:30:12");
        // customer.setTransactions(new TreeSet<>(new TransazioneComp()));
        customer.getTransactions().add(tr.get());
        customer.getTransactions().add(ti);

        // customer2.setTransactions(new TreeSet<>(new TransazioneComp()));
        customer2.getTransactions().add(tr.get());
        customer2.getTransactions().add(ti);

        assertEquals(2, customer.getPastTransactionsByDays(2));
        customer.getTransactions().remove(ti);
        assertEquals(1, customer.getTransactions().size());
        customer.getTransactions().clear();

        assertEquals(new TreeSet<>(), customer.getTransactions());

        // assertArrayEquals(null,customer.);
       /* CustomerException thrown = Assertions.assertThrows(CustomerException.class, () -> {
            Optional<ACustomer> c = CustomerUtility.createCustomerI(m);

        });

        Assertions.assertEquals(CustomerError.CODE_MISSING , thrown.print());*/
    }


    @Test
    @Order(4)
    void testCreateData() {
        Set<CustomerData> n = CustomerData.createCustomerData(null);
        for (ACustomer m : customerList) {
            assertNotNull(m.getTransactionByInterval(LocalDateTime.parse("01/01/2023 12:15:12", CustomerUtility.dateTimeFormatter), LocalDateTime.parse("30/09/2023 12:15:12", CustomerUtility.dateTimeFormatter)));
            assertTrue(m.getPastTransactionsByDays(2) >= 1);
        }
        assertNotNull(n);
        for (CustomerData da : n) {
            assertTrue(da.getNum_transazioni_customer() > 0, "Error getNum_transaction");
            assertTrue(da.getImporto_totale_transazioni() > 0, "Error getImport_Total");
            assertTrue(da.getImporto_mediotransazioni() > 1, "Error getImport_medioTransaction");
        }

    }

    @Test
    @Order(5)
    void testCreateData2() {
        CustomerData customerData = new CustomerData(customer2.getId(), customer2.totalTransaction(), customer2.remediableTransaction(), customer2.getTotalAmount());

        assertEquals(150, customerData.getImporto_totale_transazioni(), 0.5, "Error total Transaction");
        assertEquals(2, customerData.getNum_transazioni_customer(), "Error nel number di transaction");
        assertEquals(75, customerData.getImporto_mediotransazioni(), 0.5, "Error media Transaction");
    }

}
