package it.fabrick.academy.StringCalculatore;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringCalculatorTest {

    @Test
    void add() {
        assertEquals(3, StringCalculator.add("//#\n1#2"),"Error add");
    }
    @Test
    void add1() {
        assertEquals(6, StringCalculator.add("1\n,3,2"),"Error add1");
    }
    @Test
    void add2() {
        assertEquals(6, StringCalculator.add("1,2,3"),"Error add2");
    }
    @Test
    void add3() {
        assertEquals(6, StringCalculator.add("1,2,3"),"Error add3");
    }


    @Test
    void somma() {
        assertEquals(30,StringCalculator.somma(5,6,9,10),"Error somma");
    }

    @Test
    void moltiplicazione() {
      RuntimeException tr=  assertThrows(RuntimeException.class,()->{
            assertEquals(6,StringCalculator.moltiplicazione("1,2,3,-1"),"moltipli");
        });

      assertEquals("java.lang.Exception: negatives not allowed",tr.getMessage());
      //  assertEquals(6,StringCalculator.moltiplicazione("1,2,3,-1"),"moltipli");
    }
}