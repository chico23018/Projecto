package it.fabrick.academy.app;

import lombok.*;

@AllArgsConstructor
@Getter
@Setter
@ToString
@NoArgsConstructor
public class Persons {
    private int id;
    private String nome;
    private String cognome;
}
