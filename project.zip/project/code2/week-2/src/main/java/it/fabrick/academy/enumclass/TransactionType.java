package it.fabrick.academy.enumclass;

public enum TransactionType {
    CASH, CREDIT_CARD, SATISPAY,BANK_TRANSFER
}
