package it.fabrick.academy.repositoryimpl;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.repository.InMemoryRepository;


public class CustomerRepository extends InMemoryRepository<String,ACustomer> {


}
