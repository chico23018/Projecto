package it.fabrick.academy.customerService;

import it.fabrick.academy.client.CustomerFilter;
import it.fabrick.academy.comparator.TransazioneComp;
import it.fabrick.academy.enumclass.CustomerError;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.TransactionRepository;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static it.fabrick.academy.utility.CustomerUtility.readFile;

public class TransactionService {
    private TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionService) {
        this.transactionRepository = transactionService;
    }

    private final static String delimit = ";";

    public void save(Transaction transaction) throws Throwable {
        Optional<Transaction> ne = transactionRepository.save(transaction);
/*
        try{
            ne.orElseThrow(() -> new CustomerException(CustomerError.TRANSACTION_EXIST, " TRANSACTION EXIST"));
        }catch (CustomerException e){
            e.print();
        }*/
        ne.orElseThrow(() -> new CustomerException(CustomerError.TRANSACTION_EXIST, " TRANSACTION EXIST"));
    }

    public Set<Transaction> findAll() {
        return transactionRepository.findAll();
    }

    public Transaction findById(Integer id) {

        Optional<Transaction> transaction = transactionRepository.findById(id);
        return transaction.orElse(null);

    }

    public Set<Transaction> findByIdCustomer(String id) {

        return transactionRepository.findByIdCustomer(id);
    }

    public boolean deleteById(Integer s) {
        return transactionRepository.deleteById(s);
    }


    public void saveAll(Set<Transaction> aCustomers) {
        transactionRepository.saveAll(aCustomers);
    }

    public Map<String, Set<Transaction>> importTransaction(String file) {
        return importTransaction(new File(file));
    }

    public Map<String, Set<Transaction>> importTransaction(File file) {
        Map<String, Set<Transaction>> maplis = new HashMap<>();

        try {
            for (String m : readFile(file)) {

                Set<Transaction> tmp = maplis.computeIfAbsent(m.split(";", 2)[0], k -> new TreeSet<>(new TransazioneComp()));
                Optional<Transaction> oT = createTransaction(m);

                //un metodo consigliato dal ide
                // oT.ifPresent(tmp::add);
                if (oT.isPresent())
                    tmp.add(oT.get());

            }
        } catch (IOException e) {
            throw new RuntimeException("Error importTransaction " + e);
        }


        return maplis;
    }



    public Set<Transaction> importTransactionList(String file) {
        return importTransactionList(new File(file));
    }

    public Set<Transaction> importTransactionList(File file) {
        Set<Transaction> tmp = new TreeSet<>(new TransazioneComp());

        try {
            for (String m : readFile(file)) {

                Optional<Transaction> oT = createTransaction(m);

                oT.ifPresent(tmp::add);

            }
        } catch (IOException e) {
            throw new RuntimeException("Error importTransaction " + e);
        }


        return tmp;
    }


    public Optional<Transaction> createTransaction(String str) {
        String idCustomer = str.split(delimit)[0];
        int id = Integer.parseInt(str.split(delimit)[1]);
        double total = Double.parseDouble(str.split(delimit)[2]);
        TransactionType type = TransactionType.valueOf(str.split(delimit)[3]);
        String data = str.split(delimit)[4];
        return Optional.of(new Transaction(id, total, type, data, idCustomer));

    }

}
