package it.fabrick.academy.repository;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import it.fabrick.academy.model.Transaction;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public abstract class JsonFileRepository2 implements Repository<Integer, Transaction> {
    private ObjectMapper objectMapper = new ObjectMapper();

    private File file = null;

   private Set<Transaction> list = null;


    public JsonFileRepository2() {
        file = new File("C:\\Users\\GBS09334\\Documents\\json\\Repository.json");
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        readf();
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, false);
    }


    @Override
    public Optional<Transaction> findById(Integer integer) {
        return  list.stream().filter(x->x.getId().equals(integer)).findFirst();
    }


    @Override
    public boolean deleteById(Integer integer) {
        for(Transaction t :list){
            if( t.getId().equals(integer)){
                return list.remove(t);

            }
        }

        writef(list);
        return list.remove(integer);
    }


    @Override
    public Optional<Transaction> save(Transaction transaction) {
        if (list.add(transaction))
            return Optional.ofNullable(transaction);


        writef(list);
        return Optional.empty();
    }

    @Override
    public void saveAll(Set<Transaction> t) {
        list.addAll(t);
        writef(list);

    }

    @Override
    public Set<Transaction> findAll() {
        return list;
    }
    public void readf(){

        if(file.exists()){
            try {
                list = objectMapper.readValue(file, new TypeReference<>() {
                });
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            list = new HashSet<>();
        }
    }
    public void writef(Set<Transaction> list){
        try {
            objectMapper.writeValue(new File(file.toString()), list);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
