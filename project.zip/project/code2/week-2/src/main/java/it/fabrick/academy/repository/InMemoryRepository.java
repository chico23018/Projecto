package it.fabrick.academy.repository;

import it.fabrick.academy.abstractclass.BaseModel;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public abstract class InMemoryRepository<ID, T extends BaseModel<ID>> implements Repository<ID, T> {
    private Set<T> list = new HashSet<>();


    @Override
    public Set<T> findAll() {
        return list;
    }

    @Override
    public Optional<T> findById(ID id) {
        return  list.stream().filter(x->x.getId().equals(id)).findFirst();
    }


    @Override
    public Optional<T> save(T n) {
        if (list.add(n))
            return Optional.ofNullable(n);
        return Optional.empty();
    }

    @Override
    public void saveAll(Set<T> t) {
        list.addAll(t);
    }

    @Override
    public boolean deleteById(ID id) {
        for(T t :list){
            if( t.getId().equals(id)){
                return list.remove(t);
            }
        }
        return list.remove(id);
    }


}
