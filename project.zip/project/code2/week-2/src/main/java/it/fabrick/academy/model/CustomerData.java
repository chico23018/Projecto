package it.fabrick.academy.model;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Company;
import it.fabrick.academy.client.Individual;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class CustomerData {
    private String idcustomer;
    private int num_transazioni_customer;
    private double importo_mediotransazioni;
    private double importo_totale_transazioni;
    private final static String delimit = ";";

    public CustomerData() {
    }

    public static Set<CustomerData> createCustomerData(Set<ACustomer> customerList) {
        if (customerList == null)
            customerList = new HashSet<>() ;
       /* List<CustomerData> customerData = new ArrayList<>();
        for (ACustomer data : customerList) {
            CustomerData customerData1 = new CustomerData(data.getId(), data.totalTransaction(), data.remediableTransaction(), data.totalAmount());
            customerData.add(customerData1);
        }*/
            return  customerList
                    .stream()
                    .map(data -> new CustomerData(data.getId(),
                            data.totalTransaction(),
                            data.remediableTransaction(),
                            data.getTotalAmount()))
                    .collect(Collectors.toSet());

    }

    public static CustomerData maxAmount(Set<CustomerData> data) {
        CustomerData customerData = new CustomerData();

        for (CustomerData customerData1 : data) {
            if (customerData1.getImporto_totale_transazioni() > customerData.getImporto_totale_transazioni()) {
                customerData = customerData1;
            }
        }
        return customerData;
    }

    public static void write(Set<CustomerData> data) throws IOException {
        //  String m = Files.readString(new File("customerData.txt").toPath());
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\GBS09334\\Documents\\customerData1.txt"))) {

            for (CustomerData f : data) {
                String m = f.getIdcustomer() +
                        delimit +
                        f.getNum_transazioni_customer() +
                        delimit +
                        f.getImporto_mediotransazioni() +
                        delimit
                        + f.getImporto_totale_transazioni();
                writer.write(m);
                writer.newLine();

            }
        }


    }

    public static void write1(List<CustomerData> data) {

        Path path = Paths.get("C:\\Users\\GBS09334\\Documents\\customerData1.txt");
        StringBuilder m = new StringBuilder();
        try {

            for (CustomerData f : data) {
                m.append(f.getIdcustomer())
                        .append(delimit)
                        .append(f.getNum_transazioni_customer())
                        .append(delimit).append(f.getImporto_mediotransazioni())
                        .append(delimit).append(f.getImporto_totale_transazioni())
                        .append("\n");
            }

            Files.write(path, m.toString().getBytes());


        } catch (IOException | RuntimeException e) {
            throw new RuntimeException(e);
        }

    }


}