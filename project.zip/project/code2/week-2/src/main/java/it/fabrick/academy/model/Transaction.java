package it.fabrick.academy.model;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.core.JsonToken;
import it.fabrick.academy.abstractclass.BaseModel;
import it.fabrick.academy.enumclass.TransactionType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

import static it.fabrick.academy.utility.CustomerUtility.dateTimeFormatter;




@Getter
@Setter

@JsonClassDescription
public class Transaction extends BaseModel<Integer> {

    private  Integer idTrans;

    private double totalAmount;

    private TransactionType typeProcess;
    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
    private LocalDateTime localDateTime;
    private String IdCustomer;


    public Transaction( int idTrans, double totalAmount,TransactionType typeProcess, String data, String IdCustomer) {
        super(idTrans);
        this.idTrans = idTrans;
        this.totalAmount = totalAmount;
        this.typeProcess = typeProcess;
        this.localDateTime = LocalDateTime.parse(data, dateTimeFormatter);
        this.IdCustomer = IdCustomer;
    }
    @JsonCreator
    public Transaction() {
    }
/* public Transaction(int idTrans, double totalAmount, TransactionType typeProcess,String data) {
        super(idTrans);
        this.idTrans = idTrans;
        this.totalAmount = totalAmount;
        this.typeProcess = typeProcess;
        this.localDateTime = LocalDateTime.parse(data, dateTimeFormatter);

    }*/

    //!(o instanceof Transazioni)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Transaction that = (Transaction) o;
        return idTrans.equals( that.idTrans);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTrans);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Transaction{");
        sb.append("idTrans=").append(idTrans);
        sb.append(", localDateTime=").append(localDateTime);
        sb.append(", totalAmount=").append(totalAmount);
        sb.append(", typeProcess=").append(typeProcess);
        sb.append(", IdCustomer='").append(IdCustomer).append('\'');
        sb.append('}');
        return sb.toString();
    }
/* @Override
       public int compareTo(Transazioni o) {
           if (idTrans == o.idTrans) return 0;
           else if (idTrans > o.idTrans) return 1;
           else return -1;
       }*/

}
