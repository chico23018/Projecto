package it.fabrick.academy;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.customerService.CustomerService;
import it.fabrick.academy.customerService.TransactionService;
import it.fabrick.academy.model.CustomerData;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.CustomerRepository;
import it.fabrick.academy.repositoryimpl.TransactionRepository;
import it.fabrick.academy.utility.CustomerUtility;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Set;


public class Main {
    private static CustomerService customerService = new CustomerService(new CustomerRepository());
    private static TransactionService transactionService = new TransactionService(new TransactionRepository());

    public static void main(String[] args) throws IOException {
        System.out.println("hora " + LocalDateTime.now().atZone(ZoneId.of("Europe/London")).format(CustomerUtility.dateTimeFormatter));
        System.out.println("hora " + LocalDateTime.now(ZoneId.of("Asia/Dhaka")).format(CustomerUtility.dateTimeFormatter));
        //  List<ACustomer> customerList = CustomerUtility.importCustomer(args[0]);
        Set<ACustomer> customerList = customerService.importCustomer(new File("C:\\Users\\GBS09334\\Documents"));

        CustomerUtility.addTransaction(customerList, transactionService.importTransaction("Transactions.txt"));

        CustomerUtility.printGenericList(customerList);
        customerList.forEach(x -> System.out.println(x.getTotalAmount1()));
        System.out.println("scartati " + CustomerUtility.getContactor());
        Set<CustomerData> mu = CustomerData.createCustomerData(customerList);
        CustomerUtility.printGenericList(mu);
        System.out.println();
        System.out.println("TotalAmount: " + CustomerData.maxAmount(mu));
        CustomerData.write(mu);

        for (ACustomer m : customerList) {
            List<Transaction> ni = m.getTransactionByInterval(LocalDateTime.parse("01/01/2023 12:15:12", CustomerUtility.dateTimeFormatter), LocalDateTime.parse("30/09/2023 12:15:12", CustomerUtility.dateTimeFormatter));
            ni.forEach(x -> System.out.println(" id " + m.getId() + " transaction " + x.getLocalDateTime().format(CustomerUtility.dateTimeFormatter)));
            /*for (Transaction tran :ni) {
                System.out.println(" id "+m.getId() +" transaction "+ tran.getLocalDateTime().format(CustomerUtility.dateTimeFormatter));
            }*/
        }

        for (ACustomer m : customerList) {

            System.out.println(" transaction " + m.getPastTransactionsByDays(90));
        }
        //   JOptionPane.showMessageDialog(null,"scartati "+CustomerUtility.getContactor());

       // CustomerUtility.writeTransaction(customerList, new File("C:\\Users\\GBS09334\\Documents\\transaction.txt"));
       // CustomerUtility.writeCustomer(customerList, new File("C:\\Users\\GBS09334\\Documents\\done1\\Customers2.txt"));
    }


}
