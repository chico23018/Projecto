package it.fabrick.academy.customerService;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Company;
import it.fabrick.academy.client.CustomerFilter;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.enumclass.CustomerError;
import it.fabrick.academy.enumclass.CustomerType;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.repositoryimpl.CustomerRepository;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static it.fabrick.academy.utility.CustomerUtility.isRecordIn;
import static it.fabrick.academy.utility.CustomerUtility.readFile;

public class CustomerService {
    private CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }


    private static int contactorline = 0;
    private static CustomerType cType;
    private final static String delimit = ";";
    private static int contactor;

    public void save(ACustomer aCustomer) throws CustomerException, IOException {

        Optional<ACustomer> ac = customerRepository.save(aCustomer);
       /* try {
            ac.orElseThrow(() -> new CustomerException(CustomerError.CUSTOMER_EXIST, " CUSTOMER EXIST " + aCustomer.getId()));
        } catch (CustomerException e) {
            e.print();
        }*/
      ac.orElseThrow(() -> new CustomerException(CustomerError.CUSTOMER_EXIST, " CUSTOMER EXIST " + aCustomer.getId()));
    }

    public Set<ACustomer> findAll() {
        return customerRepository.findAll();
    }

    public ACustomer findById(String id) throws CustomerException, IOException {
        Optional<ACustomer> ac = customerRepository.findById(id);
        return ac.orElseThrow(() -> new CustomerException(CustomerError.CUSTOMER_MISSING, " CUSTOMER NOT FOUND " + id));

    }

    public boolean deleteById(String s) {
        return customerRepository.deleteById(s);
    }

    public void saveAll(Set<ACustomer> aCustomers) {
        customerRepository.saveAll(aCustomers);
    }

    public Set<ACustomer> importCustomer(String url) throws IOException {

        return importCustomer(new File(url));
    }

    public Set<ACustomer> importCustomer(File file) throws IOException {
        Set<ACustomer> customerList = new HashSet<>();
        File[] fin = file.listFiles(new CustomerFilter());

        for (File fu : fin) {
            for (String St : readFile(fu)) {
                try {
                    Optional<ACustomer> customerI = createCustomerI(St);
                    if (customerI.isPresent())
                        customerList.add(customerI.get());
                    else
                        contactor++;
                } catch (CustomerException e) {

                    e.print();
                }
            }


        /*    Path path = Path.of(Files.createDirectories(Path.of(file+"\\done\\")).toString()+"\\" + fu.getName());

            Files.move(fu.toPath(),path );*/
            // new File("C:\\Users\\GBS09334\\Documents\\done\\" + fu.getName()).toPath()
        }
        System.out.println(contactor + " customer non importati ");

        return customerList;
    }

    public Set<ACustomer> importCustomerList(File file) throws IOException {
        Set<ACustomer> customerList = new HashSet<>();

        for (String St : readFile(file)) {
            try {
                Optional<ACustomer> customerI = createCustomerI(St);
                if (customerI.isPresent())
                    customerList.add(customerI.get());
                else
                    contactor++;
            } catch (CustomerException e) {

                e.print();
            }



         /*
            Path path = Path.of(Files.createDirectories(Path.of(file+"\\done\\")).toString()+"\\" + fu.getName());

            Files.move(fu.toPath(),path );*/
            // new File("C:\\Users\\GBS09334\\Documents\\done\\" + fu.getName()).toPath()
        }
        System.out.println(contactor + " customer non importati ");

        return customerList;
    }

    private Optional<ACustomer> createCustomer(String file) {
        ACustomer newCustomer = null;
        String[] files = file.split(delimit, -1);
        cType = CustomerType.valueOf(file.split(delimit, -1)[0]);
        switch (cType) {
            case COM:
                int emp = file.split(delimit, -1)[7].isEmpty() ? Integer.parseInt(file.split(delimit, -1)[7]) : 0;
               /* if (!file.split(delimit, -1)[7].equals("") && file.split(delimit, -1)[7] != null) {
                    emp = Integer.parseInt(file.split(delimit, -1)[7]);
                }*/
                newCustomer = new Company(cType, files[1], files[2], files[3], files[4], files[5], files[6], emp, files[8]);
                break;
            case IND:
                newCustomer = new Individual(CustomerType.valueOf(files[0]), files[1], files[2], files[5], files[6], 0, files[7]);

                break;
            default:
                throw new IllegalStateException("Unexpected value: " + cType);
        }

        return Optional.ofNullable(newCustomer);
    }


    public Optional<ACustomer> createCustomerI(String file) throws CustomerException {
        contactorline++;
        ACustomer newCustomer = null;
        String[] files = file.split(delimit, -1);
        if (!isRecordIn(files)) {

            if (files[1].isEmpty()) {
                System.out.println("linea " + contactorline);
                return Optional.ofNullable(null);
                // throw new CustomerException(CustomerError.CODE_MISSING);
            } else {
                System.out.println("linea " + contactorline);
                return Optional.ofNullable(null);
                //  throw new CustomerException(CustomerError.FISCAL_CODE_MISSING);
            }
        } else {

            cType = CustomerType.valueOf(file.split(delimit, -1)[0]);
            switch (cType) {
                case COM:
                    int emp = 0;

                    if (!files[7].equals("")) {
                        emp = Integer.parseInt(file.split(delimit, -1)[7]);
                    }
                    newCustomer = new Company(cType, files[1], files[2], files[3], files[4], files[5], files[6], emp, files[8]);
                    break;
                case IND:
                    newCustomer = new Individual(CustomerType.valueOf(files[0]), files[1], files[2], files[5], files[6], 0, files[7]);

                    break;
            }
            return Optional.ofNullable(newCustomer);

        }


    }


}
