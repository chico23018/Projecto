package it.fabrick.academy.client;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.enumclass.CustomerType;
import lombok.*;

import java.util.Objects;


@ToString(callSuper = true)

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Company extends ACustomer {
    private String name;
    private String businessType;
    private int numOfEmployee;
    private String email;
    private String phone;

    public Company(CustomerType customerType, String id, String fiscalCode, String email, String phone, String name, String businessType, int numOfEmployee, String date) {
        super(customerType, id, fiscalCode, date);
        this.name = name;
        this.businessType = businessType;
        this.numOfEmployee = numOfEmployee;
        this.email = email;
        this.phone = phone;
    }

    @Override
    public void computerScore(double n1, double n2) {

        double m = 0.0;
        if (n1 > n2) {
            m = n1;

        } else {
            m = n2;
        }
        System.out.println("il maggiore è :" + m);
    }


    @Override
    public void computerScore(double... values) {
        double m = 0;

        for (double l : values) {
            for (double p : values) {
                if (l != p && l > p) {
                    if (l > m)
                        m = l;
                }
            }
        }
        System.out.println("il maggiore è :" + m);
    }

}