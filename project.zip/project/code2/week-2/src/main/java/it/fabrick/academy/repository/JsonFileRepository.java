package it.fabrick.academy.repository;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.Set;

public abstract class JsonFileRepository <ID, T>implements Repository<ID, T> {
    private ObjectMapper objectMapper = new ObjectMapper();

    private File file = null;

    Set<T> t = null;


    public JsonFileRepository() {
        file = new File("C:\\Users\\GBS09334\\Documents\\json\\Repository.json");
        objectMapper.registerModule(new JavaTimeModule());


        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            t = objectMapper.readValue(file, Set.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
    }

    @Override
    public Set<T> findAll() {

        return t;
    }

    @Override
    public Optional<T> findById(ID id) {
        return Optional.empty();
    }

    @Override
    public Optional<T> save(T t) {
        try {

            //   json = objectMapper.writeValueAsString(p );
            objectMapper.writeValue( new File(file.toString()), t);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return Optional.empty();
    }

    @Override
    public void saveAll(Set<T> t) {
        try {

            //   json = objectMapper.writeValueAsString(p );
            objectMapper.writeValue(new File(file.toString()), t);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public boolean deleteById(ID id) {
        return false;
    }
}
