package it.fabrick.academy;

public class App1 {
    public static void main(String[] args) throws Throwable {
        Integer m[] = {1, 2, 3, 4, 5};
        Integer g[] = new Integer[m.length];
        int cont = 0;
      /*  for (int a : m) {
            int b = 0;
            for (int n : m) {
                b += n;
            }
            g[cont]= b-a;
         cont++;
        }*/

        int b = 0;
        for (int a : m) {
            b += a;
        }
        int l = 0;
        for (int q : m) {
            l = b - q;
            System.out.print(l + ",");
        }
    }
}
