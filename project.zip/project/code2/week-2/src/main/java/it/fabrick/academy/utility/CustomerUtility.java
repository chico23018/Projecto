package it.fabrick.academy.utility;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Company;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.customerService.CustomerService;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.CustomerRepository;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CustomerUtility {
    public static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    private final static String delimit = ";";
    private static int contactor = 0;

    public static int getContactor() {
        return contactor;
    }

    public static boolean isRecordIn(String[] tokens) {

        return !tokens[1].isEmpty() && !tokens[2].isEmpty();
    }

    public static List<String> readFile(File file) throws IOException {

        return Files.readAllLines(file.toPath());
    }

    public static void addTransaction(Set<ACustomer> customerList, Map<String, Set<Transaction>> transactionList) {

        customerList.forEach(x -> x.setTransactions(transactionList.get(x.getId())));
    }

    public static void addTransaction(Set<ACustomer> customerList, Set<Transaction> transactionList) {
        for (ACustomer m : customerList) {
            for (Transaction t : transactionList) {
                if (m.getId().equals(t.getIdCustomer())) {
                    m.getTransactions().add(t);
                }
            }
        }
    }

    public static void printGenericList(Set<?> cust) {
        cust.forEach(System.out::println);
    }

    public static void writeCustomer(Set<ACustomer> data, String file) throws IOException {
        writeCustomer(data, new File(file));
    }

    public static void writeCustomer(Set<ACustomer> data, File file) throws IOException {
        Path path = Path.of("C:\\Users\\GBS09334\\Documents\\save\\");
        Files.createDirectories(path);
      /*  if (file.exists())
            inMemoryData(data, file);*/
        for (ACustomer ne : data) {
            if (!ne.getTransactions().isEmpty())
                writeTransaction(data, new File(path.toAbsolutePath() + "\\" + "Transaction.txt"));
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path + "\\" + file))) {

            for (ACustomer f : data) {
                String m = "";
                if (f instanceof Company) {
                    Company com = ((Company) f);
                    m = com.getCustomerType() +
                            delimit +
                            com.getId() +
                            delimit +
                            com.getFiscalCode() +
                            delimit +
                            com.getEmail() +
                            delimit +
                            com.getPhone() +
                            delimit
                            + com.getName() +
                            delimit +
                            com.getBusinessType() +
                            delimit +
                            com.getNumOfEmployee() +
                            delimit +
                            com.getData().format(dateFormatter);

                } else {
                    Individual com = ((Individual) f);
                    m = com.getCustomerType() +
                            delimit +
                            com.getId() +
                            delimit +
                            com.getFiscalCode() +
                            delimit
                            + "" +
                            delimit
                            + "" +
                            delimit
                            + com.getFirstname() +
                            delimit +
                            com.getLastname() +
                            delimit +
                            com.getData().format(dateFormatter);
                }
                writer.write(m);
                writer.newLine();


            }
        }


    }


    private static void writeTransaction(Set<ACustomer> data, File file) throws IOException {


      /*  if (file.exists()) {
            TransactionService transactionService = new TransactionService(new TransactionRepository());
            if (transactionService.importTransaction(file) != null) {
                CustomerUtility.addTransaction(data, transactionService.importTransaction(file));
            }
        }*/


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (ACustomer b : data) {

                for (Transaction com : b.getTransactions()) {
                    String m = b.getId() +
                            delimit +
                            com.getIdTrans() +
                            delimit +
                            com.getTotalAmount() +
                            delimit +
                            com.getTypeProcess() +
                            delimit +
                            com.getLocalDateTime().format(dateTimeFormatter);


                    writer.write(m);
                    writer.newLine();


                }
            }
        }


    }


    public static void inMemoryData(Set<ACustomer> data, File file) throws IOException {
        CustomerService customerService = new CustomerService(new CustomerRepository());
        if (customerService.importCustomerList(file) != null)
            data.addAll(customerService.importCustomerList(file));
    }
    public static void write2(String data) {

        Path path = Paths.get("C:\\Users\\GBS09334\\Documents\\CustomerJson.json");
        StringBuilder m = new StringBuilder();
        try {

            Files.write(path, data.getBytes());
        } catch (IOException | RuntimeException e) {
            throw new RuntimeException(e);
        }

    }

}
