package it.fabrick.academy.abstractclass;

import com.fasterxml.jackson.annotation.JsonFormat;
import it.fabrick.academy.comparator.TransazioneComp;
import it.fabrick.academy.enumclass.CustomerType;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.interfaceclass.ICustomer;
import it.fabrick.academy.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static it.fabrick.academy.utility.CustomerUtility.dateFormatter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public abstract class ACustomer extends BaseModel<String> implements ICustomer {

    private CustomerType customerType;
    private  String id;
    private String fiscalCode;
    private Set<Transaction> transactions;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate data;





    public ACustomer(CustomerType customerType, String id, String fiscalCode, String data) {
        super(id);
        this.customerType = customerType;
        this.id = id;
        this.fiscalCode = fiscalCode;
        this.data = LocalDate.parse(data, dateFormatter);
    }

    public void addT(Transaction t) {

        //(o1, o2) -> {
        //                if (o1.getIdTrans()==o2.getIdTrans()) return 0;
        //                else if (o1.getIdTrans()>o2.getIdTrans()) return 1;
        //                   else return -1;
        //
        //            }
        if (transactions == null)
            transactions = new TreeSet<>(new TransazioneComp());

        if (t != null) {
            transactions.add(t);
            //  Collections.sort(transazionis,new TransazioneComp());
        }
    }

    public Set<Transaction> getTransactions() {
        if (transactions == null)
            transactions = new TreeSet<>(new TransazioneComp());

        return transactions;
    }


    public void pay() {
        System.out.println("il pagamento con successo ");
    }

    public void stamp(TransactionType type) {
        for (Transaction t : getTransactions()) {
            if (t.getTypeProcess().equals(type))
                System.out.println("name: " + "" + " Process: " + t.getTypeProcess());
        }
    }

    public int totalTransaction() {
        return transactions.size();
    }

    public double remediableTransaction() {

        return getTotalAmount() / transactions.size();
    }

    public double getTotalAmount() {
      /*  double m = 0.;
        for (Transaction t : transactions) {
            m += t.getTotalAmount();
        }
        */
        double n = 0;


        return transactions.stream().mapToDouble(Transaction::getTotalAmount).sum();
    }

    public double getTotalAmount1() {

        AtomicReference<Double> getdou = new AtomicReference<>((double) 0);
        transactions.forEach(m -> getdou.updateAndGet(v -> (v + m.getTotalAmount())));

        //return  transactions.stream().collect(Collectors.summingDouble(Transaction::getTotalAmount));
        return getdou.get();

    }

    public List<Transaction> getTransactionByInterval(LocalDateTime from, LocalDateTime to) {
        //List<Transaction> transactions1 = new ArrayList<>();

      /*  for (Transaction m : transactions) {

            if (m.getLocalDateTime().isAfter(from) && m.getLocalDateTime().isBefore(to)) {
                transactions1.add(m);
            }
        }*/

        return transactions.stream().filter(m -> m.getLocalDateTime().isAfter(from) && m.getLocalDateTime().isBefore(to)).collect(Collectors.toList());
    }

    public Integer getPastTransactionsByDays(Integer numOfDays) {


     /*   for (Transaction m : transactions) {
            if (m.getLocalDateTime().isBefore(LocalDateTime.now().minusDays(numOfDays))) {
                d++;
            }


        }
           */

        return (int) transactions.stream().filter(x -> x.getLocalDateTime().isBefore(LocalDateTime.now().minusDays(numOfDays))).count();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ACustomer{");
        sb.append("customerType=").append(customerType);
        sb.append(", id='").append(id).append('\'');
        sb.append(", fiscalCode='").append(fiscalCode).append('\'');
        sb.append(", transactions=").append(transactions);
        sb.append(", data=").append(data.format(dateFormatter));
        sb.append('}');
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ACustomer)) return false;
        ACustomer customer = (ACustomer) o;
        return id.equals(customer.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}


