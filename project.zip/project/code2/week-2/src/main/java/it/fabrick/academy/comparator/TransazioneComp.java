package it.fabrick.academy.comparator;

import it.fabrick.academy.model.Transaction;

import java.util.Comparator;

public class TransazioneComp implements Comparator<Transaction> {
    @Override
    public int compare(Transaction o1, Transaction o2) {

        if (o1.getIdTrans()==o2.getIdTrans()) return 0;
        else if (o1.getIdTrans()>o2.getIdTrans()) return 1;
        else return -1;
       /* dal maggio al minore
       if (o1.getIdTrans()==o2.getIdTrans()) return 0;
        else if (o1.getIdTrans()>o2.getIdTrans()) return -1;
        else return 1;
        metodo più corto
        return Integer.compare(o2.getIdTrans(), o1.getIdTrans());*/
      /* dal minore al maggiore
       if (o1.getIdTrans()==o2.getIdTrans()) return 0;
        else if (o1.getIdTrans()>o2.getIdTrans()) return 1;
        else return -1;
          metodo più corto
       return Integer.compare(o1.getIdTrans(), o2.getIdTrans());*/
    }
}
