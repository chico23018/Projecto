package it.fabrick.academy.abstractclass;

import com.fasterxml.jackson.annotation.*;
import it.fabrick.academy.model.Transaction;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
/*@JsonTypeInfo (use = JsonTypeInfo.Id.CLASS)
@JsonSubTypes ({@JsonSubTypes.Type(value = Transaction.class),
        @JsonSubTypes.Type(value = ACustomer.class)})*/
@Getter
@NoArgsConstructor

public abstract class BaseModel<ID> {

    private ID id;

    //  private final LocalDateTime localDateTime = LocalDateTime.now();

    public BaseModel(ID id) {
        this.id = id;

    }


}
