package it.fabrick.academy.repositoryimpl;

import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repository.InMemoryRepository;

import java.util.Set;
import java.util.stream.Collectors;

public class TransactionRepository extends InMemoryRepository<Integer, Transaction> {
    public Set<Transaction> findByIdCustomer(String id) {
        return findAll().stream().filter(x ->  x.getIdCustomer().equals(id)).collect(Collectors.toSet());
    }
}
