package it.fabrick.academy.app;

import it.fabrick.academy.customerService.TransactionServiceJson;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repositoryimpl.TransactionJsonRepository;

import java.util.Set;

public class Main2 {
    public static void main(String[] args) throws Throwable {
       TransactionServiceJson transactionJsonRepository = new TransactionServiceJson(new TransactionJsonRepository());
        Transaction i = new Transaction(3366, 52, TransactionType.SATISPAY, "04/07/2023 09:30:12", "002");

transactionJsonRepository.saveAll(transactionJsonRepository.importTransactionList("C:\\Users\\GBS09334\\Documents\\save\\Transaction.txt"));
   //  transactionJsonRepository.save(i);
        Set<Transaction> t = transactionJsonRepository.findAll();
        for(Transaction t1 :t){
            System.out.println(t1);
        }
    }
}
