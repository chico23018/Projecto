package it.fabrick.academy.app;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.model.Transaction;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        File file = new File("C:\\Users\\GBS09334\\Documents\\CustomerJson.json");
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        Persons p = new Persons(1,"Francisco","Acosta");
      //  objectMapper.setDateFormat();
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        Transaction i= new Transaction(3366, 52, TransactionType.SATISPAY ,"04/07/2023 09:30:12","002");
        String json = null;
      /*  try {

         //   json = objectMapper.writeValueAsString(p );
           objectMapper.writeValue(new File("C:\\Users\\GBS09334\\Documents\\CustomerJson.json"), i);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println(json);*/

         objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);


        List<Individual> aCustomerList = objectMapper.readValue(file, new TypeReference<>(){});

      for(ACustomer t: aCustomerList){
          System.out.println(t);
      }

    }
}
