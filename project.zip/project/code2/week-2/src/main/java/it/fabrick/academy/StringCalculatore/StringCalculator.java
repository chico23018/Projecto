package it.fabrick.academy.StringCalculatore;

public class StringCalculator {
    public static int add(String str) {
        int m = 0;
        if (str == null || str.isEmpty())
            return 0;

        String delimiter = ",";

        System.out.println( );
        if (str.startsWith("//")) {
            delimiter = str.substring(2, str.indexOf("\n"));
        }
        str = str.replace("//", "0");
        str = str.replace(delimiter, ",");
        str = str.replace("\n", "");

        for (String n : str.split(",")) {
            try {
                m += Integer.parseInt(n);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return m;
    }

    public static int somma(int... vaInts) {
        int result = 0;
        for (int m : vaInts) {
            result += m;
        }
        return result;
    }
    public static int moltiplicazione(String str) {
        int m = 1;
        if (str == null || str.isEmpty())
            return 0;
        for (String n : str.split(",")) {
            try {
                if(Integer.parseInt(n)<0)
                    throw new Exception("negatives not allowed");
                m *=  Integer.parseInt(n);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return m;
    }

    public static void main(String[] args) {
        String j = "1\n2,3";


        System.out.println(somma(5, 6, 6, 8, 4, 1, 4));
    }



}
