package it.fabrick.academy.app;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.client.Company;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.customerService.CustomerService;
import it.fabrick.academy.customerService.TransactionService;
import it.fabrick.academy.enumclass.TransactionType;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.utility.CustomerUtility;
import org.joda.time.format.DateTimeFormat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static it.fabrick.academy.enumclass.CustomerType.COM;
import static it.fabrick.academy.enumclass.CustomerType.IND;


public class RunningApp {
    private CustomerService customerService;
    private TransactionService transactionService;

    public RunningApp(CustomerService customerService, TransactionService transactionService) {

        this.customerService = customerService;
        this.transactionService = transactionService;
    }

    public void run() throws IOException, CustomerException {


        customerService.saveAll(customerService.importCustomer("C:\\Users\\GBS09334\\Documents\\save"));
        transactionService.saveAll(transactionService.importTransactionList("C:\\Users\\GBS09334\\Documents\\save\\Transaction.txt"));

        customerService.findAll().forEach(x -> x.getTransactions().addAll(transactionService.findByIdCustomer(x.getId())));

        for (ACustomer m : customerService.findAll()) {
            System.out.println(m.getTransactions());
        }

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        // objectMapper.setDateFormat();
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
  try {

         //   json = objectMapper.writeValueAsString(p );
           objectMapper.writeValue(new File("C:\\Users\\GBS09334\\Documents\\CustomerJson.json"), customerService.findAll());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
      //  String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString( new Transaction(3366, 52,TransactionType.SATISPAY ,"04/07/2023 09:30:12","002"));
     //   System.out.println(json);
      //  objectMapper.writeValue(new File("C:\\Users\\GBS09334\\Documents\\CustomerJson.json"),json);
       // CustomerUtility.write2(json);


        /*Gson gson = new GsonBuilder().create();

        List list = new ArrayList();
        list.add(new Individual(IND, "002", "0255", "Francisco", "Acosta", 32, "20/02/2023"));
        list.add(new Individual(IND, "002", "0255", "Francisco", "Acosta", 32, "20/02/2023"));
        System.out.println( gson.toJson(list));*/
        try {
            customerService.save(new Individual(IND, "002", "0255", "Francisco", "Acosta", 32, "20/02/2023"));
            customerService.save(new Company(COM, "001", "0255", "Fabrick", "", "", "Booh", 400, "20/02/2023"));
            customerService.save(new Company(COM, "001", "0255", "Fabrick", "", "", "Booh", 400, "20/02/2023"));
        } catch (CustomerException e) {
            e.print();
        }
        try {
            System.out.println(customerService.findById("030"));
        } catch (CustomerException e) {
            e.print();
        } catch (IOException e) {
            e.printStackTrace();
        }

        CustomerUtility.writeCustomer(customerService.findAll(), "Customers2.txt");
    }
}
