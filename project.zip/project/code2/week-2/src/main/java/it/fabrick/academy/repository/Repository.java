package it.fabrick.academy.repository;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.interfaceclass.ICustomer;
import it.fabrick.academy.model.Transaction;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface Repository<ID, T> {


    Set<T> findAll();

    Optional<T> findById(ID id);

    Optional<T>  save(T t);

    void saveAll(Set<T> t);

    boolean deleteById(ID id);

}

