package it.fabrick.academy.client;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.enumclass.CustomerType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString(callSuper = true)
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Individual  extends ACustomer {
    private String firstname;
    private String lastname;
    private int age;

    public Individual(CustomerType customerType, String id, String fiscalCode, String firstname, String lastname, int age,String date) {
        super(customerType, id,fiscalCode,date);
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
    }

    @Override
    public void computerScore(double n1, double n2) {

    }



    @Override
    public void computerScore(double... values) {

    }
}
