package it.fabrick.academy.enumclass;

public enum CustomerType  {
    IND,COM
}
