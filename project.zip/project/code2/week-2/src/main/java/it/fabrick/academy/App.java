package it.fabrick.academy;

import it.fabrick.academy.abstractclass.ACustomer;
import it.fabrick.academy.enumclass.CustomerType;
import it.fabrick.academy.client.Individual;
import it.fabrick.academy.model.Transaction;

import java.io.IOException;
import java.util.*;


public class App {


    public static void main(String[] args) throws IOException {


/*
        ACustomer m = new Individual(CustomerType.IND,"5865", "EM55245","Eduardo","Martinez",35);
      m.addT(new Transaction(2652, TransactionType.CASH,  100));
        m.addT(new Transaction(6695, TransactionType.CASH,  45));
        m.addT(new Transaction(78445, TransactionType.CREDIT_CARD, 35));
        m.addT(new Transaction(3366, TransactionType.SATISPAY,  52));

        ACustomer m1 = new Individual(CustomerType.IND,"272", "JS245","Francisco","Acosta",32);
        m1.addT( new Transaction(265, TransactionType.CASH,  150));
        m1.addT( new Transaction(2775, TransactionType.CREDIT_CARD,  50));
        m1.addT( new Transaction(23547, TransactionType.SATISPAY, 30));
        m1.addT( new Transaction(35534, TransactionType.CASH,  15));

        ACustomer m2 = new Individual(CustomerType.IND,"275", "EMA65245","Emilia","Mazur",37);

*/
/*

        List<ACustomer>  aCustomer = new LinkedList<>();
        aCustomer.add(m);
        aCustomer.add(m1);
        aCustomer.add(m2);
*/

/*
        Optional<Set<Transaction>> oT = getTransaction("272",createCustomerMap(aCustomer));

        if(oT.isPresent()){
            for (Transaction st:oT.get()){
           //     System.out.println("id: "+ st.getIdTrans());
            }
        }else {
          //  System.out.println("non esite ");
        }*/
     /*   oT.ifPresent(s->{
            for (Transazioni st:s){
                System.out.println("id: "+ st.getIdTrans());
            }
        }
        );*/



       /* for (Map.Entry<String,Set<Transazioni> > m6 : createCustomerMap(aCustomer).entrySet()){

            for (Transazioni m7 :m6.getValue()){

                System.out.println("Fiscal Code: "+ m6.getKey()+" idtransazione: "+m7.getIdTrans()+" Totale: "+m7.getTotale());
            }
            System.out.println();

        }*/
      /*  System.out.println();
        for (Transazioni m6 : createCustomerMap(aCustomer).get("6560")){
            System.out.println("Fi: Javier"+" idtransazione: "+m6.getIdTrans()+" Totale: "+m6);
        }*/
    }

    public static Map<String, Set<Transaction>> createCustomerMap(List<ACustomer>  aCustomer) {
        Map<String, Set<Transaction>> maplis = new HashMap<>();
        for(ACustomer a :aCustomer) {
            maplis.put(a.getId(),a.getTransactions() );
        }
        return maplis;
    }
    public static Optional<Set<Transaction>> getTransaction(String ID, Map<String, Set<Transaction>> maplis){

        return Optional.ofNullable(maplis.get(ID));
    }

}
