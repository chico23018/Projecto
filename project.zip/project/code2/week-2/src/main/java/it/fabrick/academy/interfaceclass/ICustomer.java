package it.fabrick.academy.interfaceclass;

public interface ICustomer {

    void computerScore(double n1, double n2);

    void computerScore(double ...values);
    default void somma(int...values){
        int m=0;
        for(int n :values){
            m+=n;
        }
        System.out.println("la somma è :"+m);

    }
}
