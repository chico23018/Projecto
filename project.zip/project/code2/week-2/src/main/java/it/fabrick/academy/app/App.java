package it.fabrick.academy.app;

import it.fabrick.academy.customerService.CustomerService;
import it.fabrick.academy.customerService.TransactionService;
import it.fabrick.academy.exception.CustomerException;
import it.fabrick.academy.repositoryimpl.CustomerRepository;
import it.fabrick.academy.repositoryimpl.TransactionRepository;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException, CustomerException {
        RunningApp app = new RunningApp(new CustomerService(new CustomerRepository()), new TransactionService(new TransactionRepository()));
        app.run();
    }
}
