package it.fabrick.academy.enumclass;

public enum CustomerError {
    FISCAL_CODE_MISSING,
    CODE_MISSING, CUSTOMER_MISSING,CUSTOMER_EXIST, TRANSACTION_MISSING,TRANSACTION_EXIST
}
