package it.fabrick.academy.client;

import java.io.File;
import java.io.FilenameFilter;

public class CustomerFilter implements FilenameFilter {
    @Override
    public boolean accept(File pathname, String name) {
        return name.startsWith("Customers");

    }
}
