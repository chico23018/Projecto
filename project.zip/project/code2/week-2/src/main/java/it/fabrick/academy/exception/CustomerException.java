package it.fabrick.academy.exception;

import it.fabrick.academy.enumclass.CustomerError;

public class CustomerException extends Throwable {
    private CustomerError code;
    private String messager;

    public CustomerException(CustomerError code, String message) {
        this.code = code;
        this.messager = message;
    }

    public CustomerError print() {

        System.err.println(messager+" "+code);
        return code;

    }

    @Override
    public void printStackTrace() {
        super.printStackTrace();

    }
}
