package it.fabrick.academy.repositoryimpl;

import it.fabrick.academy.model.Transaction;
import it.fabrick.academy.repository.JsonFileRepository;
import it.fabrick.academy.repository.JsonFileRepository2;

public class TransactionJsonRepository extends JsonFileRepository2 {

}
