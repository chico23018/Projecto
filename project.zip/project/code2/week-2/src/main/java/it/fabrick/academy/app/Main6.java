package it.fabrick.academy.app;

import java.util.Arrays;

public class Main6 {
    public static void main(String[] args) {
        //  System.out.println(somma(6));

        System.out.println(binario(47));

    }

    public static boolean somma(int n) {
        int[] a = {3, 4, 1, 10, 16, 9, 25, 7, 35};
        // Arrays.stream(a).filter((a1,a2)-> a1!=a2&&a1+a2==n ).;
      /*  for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] + a[j] == n) {
                    vero = true;
                }
              }
        }*/
        Arrays.sort(a);

        for (int i = 0, k = a.length - 1; i < k; ) {
            int somma = a[i] + a[k];
            if (somma == n) {
                return true;
            } else if (n > somma) {
                i++;
            } else {
                k--;
            }
        }
        return false;
    }

    public static int bina(String m) {
        int h = 0;
        int g = 0;
        for (String n : m.split("")) {
            if (Integer.parseInt(n) == 1) {
               // System.out.println(g+" g");
                int a = (int) Math.pow(2, g);
                //System.out.println(a+" a");
                h += a;
            }
            g++;
        }
        return h;
    }

    public static int binario(int m) {
        StringBuilder rs = new StringBuilder();
        for (int n = m; n != 0; ) {
            if (n % 2 == 0) {
                rs.append(n % 2);
                n = n / 2;
            } else if (n % 2 == 1) {
                rs.append(n % 2);
                n = n / 2;
            }
        }
        return bina(rs.reverse().toString());
    }
}
