package it.fabrick.academy.project1.configuration;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfiguration {
    @Bean
    public GroupedOpenApi defaultOpenApi() {
        return GroupedOpenApi.builder()
                .group("chico")
                .packagesToScan("it.fabrick.academy.project1")
                .build();
    }
    @Bean
    public GroupedOpenApi newdefaultOpenApi() {
        return GroupedOpenApi.builder()
                .group("hola")
                .packagesToScan("it.fabrick.academy.project1")
                .build();
    }
}
