package it.fabrick.academy.project1.entity;

import lombok.*;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthorEntity {
    private String uuid;
    private String name;
    private List<BookEntity> bookEntities;
}
