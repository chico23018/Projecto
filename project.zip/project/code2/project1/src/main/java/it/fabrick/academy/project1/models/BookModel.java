package it.fabrick.academy.project1.models;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;
@Getter
@Setter
public class BookModel {
    private UUID uuid;
    private String tittle;
    private Integer pageCount;
}
