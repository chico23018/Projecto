package it.fabrick.academy.project1.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import it.fabrick.academy.project1.dto.*;
import it.fabrick.academy.project1.mapper.IAuthorMapper;
import it.fabrick.academy.project1.mapper.IBookMapper;
import it.fabrick.academy.project1.models.AuthorModel;
import it.fabrick.academy.project1.models.BookModel;
import it.fabrick.academy.project1.service.IAuthorService;
import it.fabrick.academy.project1.service.IBookService;
import it.fabrick.academy.project1.service.ValidationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/*
 * è una classe per avviare una i rest per web
 * */
@RestController
@RequestMapping("/v1.0/authors")
@AllArgsConstructor
@Slf4j
public class AuthorController {
    private final IAuthorService iAuthorService;
    private final ValidationService validationService;
    private final IBookService iBookService;
    private final IBookMapper iBookMapper;
    private final IAuthorMapper iAuthorMapper;

    @GetMapping
    public ResponseEntity<List<AuthorResponseDto>> readAuthors(@RequestParam(value = "name", required = false) String name,
                                                               @RequestHeader(value = "aX-API-KEY", required = false) String apikey) {
        List<AuthorResponseDto> authorResponseDtoList = iAuthorService
                .readAuthors(Optional.ofNullable(name))
                .stream().map(iAuthorMapper::responseFromModel).collect(Collectors.toList());
        return ResponseEntity.ok(authorResponseDtoList);

    }

    @Operation(description = "Create author with the given request")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "author created", content = {
                    @Content(schema = @Schema(implementation = AuthorResponseDto.class))
            }),
            @ApiResponse(responseCode = "400", description = "data not valid", content = {
                    @Content(schema = @Schema(implementation = ErrorResponseDto.class))
            })})
    @PostMapping/* dopo la creazione ritorna una response 200 e model*/
    public ResponseEntity<AuthorResponseDto> createAuthor(@RequestBody AuthorRequestDto authorRequestDto) {
        validationService.doValidate(authorRequestDto);
        AuthorModel authorModel2 =  iAuthorMapper.modelFromRequest(authorRequestDto);


       AuthorResponseDto authorResponseDto= iAuthorMapper.responseFromModel(iAuthorService.createAuthor(authorModel2));

        return ResponseEntity.created(URI.create("/v1.0/authors/" + authorResponseDto.getUuid().toString())).body(authorResponseDto);

    }

    @PutMapping("/{authorId}")
    public ResponseEntity<AuthorResponseDto> updateAuthor(@PathVariable("authorId") String uuid
            , @RequestBody AuthorRequestDto authorRequestDto) {
        AuthorModel authorModel = iAuthorMapper.modelFromRequest(authorRequestDto);

        AuthorResponseDto authorResponseDto = iAuthorMapper.responseFromModel(iAuthorService.updateAuthor(uuid, authorModel));

        return ResponseEntity.ok(authorResponseDto);
    }

    @DeleteMapping("/{authorId}")/*non manda mai niente in body solo ritorna il response*/
    public ResponseEntity<Void> deleteAuthor(@PathVariable("authorId") String uuid) {
        iAuthorService.deleteAuthor(uuid);
        new ResponseEntity<>(HttpStatus.NO_CONTENT);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{authorId}/books")
    public ResponseEntity<List<BookResponseDto>> readAuthor(@PathVariable("authorId") String uuid) {
        AuthorModel author = iAuthorService.readAuthor(uuid);
        List<BookResponseDto> list=iBookService.readAuthorBooks(uuid).stream().map(iBookMapper::responseFromModel).collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    @PostMapping("/{authorId}/books")
    public ResponseEntity<BookResponseDto> createBook(@PathVariable("authorId") String uuid,
                                                      @RequestBody BookRequestDto bookRequestDto) {
        validationService.doValidate(bookRequestDto);
        AuthorResponseDto authorResponseDto = iAuthorMapper.responseFromModel(iAuthorService.readAuthor(uuid));
        BookModel bookModel=iBookMapper.modelFromCrateRequest(bookRequestDto);
        BookResponseDto bookResponseDto = iBookMapper.responseFromModel(iBookService.createBook(bookModel, authorResponseDto.getUuid().toString()));

        return ResponseEntity.created(URI.create("/v1.0/authors/" + authorResponseDto.getUuid().toString() + "/books/" + bookResponseDto.getUuid())).body(bookResponseDto);

    }

    @PutMapping("/{authorId}/books/{bookId}")
    public ResponseEntity<BookResponseDto> updateBook(@PathVariable("authorId") String uuid,
                                                      @PathVariable("bookId") String bookId,
                                                      @RequestBody(required = false) BookUpdateRequestDto bookRequestDto) {
        BookModel bookModel =iBookMapper.modelFromUpdateRequest(bookRequestDto);

        BookResponseDto responseDto = iBookMapper.responseFromModel(iBookService.updateBook(uuid, bookId,bookModel ));
        return ResponseEntity.ok(responseDto);
    }

    @DeleteMapping("/{authorId}/books/{bookId}")
    public ResponseEntity<Void> deleteBook(@PathVariable("authorId") String uuid,
                                           @PathVariable("bookId") String bookId) {
        iBookService.deleteDelete(uuid, bookId);
        return ResponseEntity.noContent().build();
    }
}
