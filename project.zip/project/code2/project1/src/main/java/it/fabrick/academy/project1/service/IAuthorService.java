package it.fabrick.academy.project1.service;

import it.fabrick.academy.project1.dto.AuthorRequestDto;
import it.fabrick.academy.project1.dto.AuthorResponseDto;
import it.fabrick.academy.project1.models.AuthorModel;

import java.util.List;
import java.util.Optional;

public interface IAuthorService {
    AuthorModel readAuthor(String uuid);
    List<AuthorModel> readAuthors(Optional<String> name);
    AuthorModel createAuthor(AuthorModel authorModel);

    AuthorModel updateAuthor(String uuid, AuthorModel authorModel);

    void deleteAuthor(String uuid);
}
