package it.fabrick.academy.project1.repositori;

import it.fabrick.academy.project1.entity.AuthorEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Service
public class AuthorRepository implements IAuthorRepository {
    private final String authors;
    private final String author1;
    private final String author2;

    public AuthorRepository(@Value("${demo.author.names.author1}") String author1,
                            @Value("${demo.author.names.author2}") String author2,
                            @Value("${demo.author.names.author3}") String authors) {
        this.author1 = author1;
        this.author2 = author2;
        this.authors = authors;
    }

    @Override
    public AuthorEntity findByUuid(String uuid) {
        if (isAuthorNotPresent(uuid)) {
            return null;
        } else {
            return createStub(UUID.fromString(uuid), authors);
        }
    }

    @Override
    public List<AuthorEntity> findByName(String name) {
      return Collections.singletonList(createStub(name));
    }

    @Override
    public List<AuthorEntity> findAll() {
  /*      List<AuthorResponseDto> authorResponseDtoList = new ArrayList<>();
        authorResponseDtoList.add(createResponseStub("Francisco"));
        authorResponseDtoList.add(createResponseStub("Daniel"));
        return authorResponseDtoList;*/
        return Arrays.asList(
                createStub(author1),
                createStub(author2)
        );
    }

    @Override
    public int save(AuthorEntity authorEntity) {
        AuthorEntity stu = createStub(authorEntity.getName());
        authorEntity.setUuid(stu.getUuid());
        return 1;
    }

    @Override
    public int updateNameByUuid(String uuid, String authorRequestDto) {
        if (isAuthorNotPresent(uuid))
            return 0;
        else {
            createStub(UUID.fromString(uuid), authorRequestDto);
            return 1;
        }
    }

    @Override
    public int deleteByUuid(String uuid) {
        //Do not nothing
        return 1;
    }

    private static boolean isAuthorNotPresent(String uuid) {
        return uuid.equals("-1");
    }

    private AuthorEntity createStub(String name) {
        return createStub(UUID.randomUUID(), name);
    }

    private AuthorEntity createStub(UUID uuid, String name) {


        return AuthorEntity.builder()
                .name(name)
                .uuid(uuid.toString())
                .bookEntities(Arrays.asList(
                        BookRepository.createStub(uuid.toString(),"book"),
                        BookRepository.createStub(uuid.toString(),"book2")
                ))
                .build();
    }


}
