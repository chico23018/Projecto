package it.fabrick.academy.project1.mapper;

import it.fabrick.academy.project1.dto.BookRequestDto;
import it.fabrick.academy.project1.dto.BookResponseDto;
import it.fabrick.academy.project1.dto.BookUpdateRequestDto;
import it.fabrick.academy.project1.entity.BookEntity;
import it.fabrick.academy.project1.models.BookModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface IBookMapper {
    BookEntity requestToEntity(BookRequestDto bookRequestDto);

    BookResponseDto entityToResponseDtp(BookEntity entity);

    BookModel modelFromCrateRequest(BookRequestDto bookRequestDto);

    BookModel modelFromUpdateRequest(BookUpdateRequestDto bookUpdateRequestDto);

    BookResponseDto responseFromModel(BookModel bookModel);

    BookEntity entityFromModel(BookModel bookModel);

    BookModel modelFromEntity(BookEntity bookEntity);


}
