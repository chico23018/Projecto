package it.fabrick.academy.project1.service;

import it.fabrick.academy.project1.dto.BookRequestDto;
import it.fabrick.academy.project1.dto.BookResponseDto;
import it.fabrick.academy.project1.dto.BookUpdateRequestDto;
import it.fabrick.academy.project1.models.BookModel;

import java.util.List;

public interface IBookService {
    List<BookModel> readAuthorBooks(String authorId);
    BookModel createBook(BookModel bookModel, String authorResponseDto);

    BookModel readBook(String authorId, String uuid);

    BookModel updateBook(String uuid, String uuidBook, BookModel BookModel);

    void deleteDelete(String uuid, String uuidBook);
}
