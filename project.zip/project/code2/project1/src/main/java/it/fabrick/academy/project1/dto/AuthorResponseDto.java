package it.fabrick.academy.project1.dto;

import lombok.*;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuthorResponseDto {
    private UUID uuid;
    private String name;
    private List<BookResponseDto> books;
}
