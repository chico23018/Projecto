package it.fabrick.academy.project1.dto;

import it.fabrick.academy.project1.entity.BookEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class BookResponseDto {
    private UUID uuid;
    private String tittle;
    private int pageCount;
    private String authorId;
}
