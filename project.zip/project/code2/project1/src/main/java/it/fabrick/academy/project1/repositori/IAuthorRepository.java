package it.fabrick.academy.project1.repositori;

import it.fabrick.academy.project1.entity.AuthorEntity;

import java.util.List;

public interface IAuthorRepository  {
    AuthorEntity findByUuid(String uuid);
    List<AuthorEntity> findByName(String name);

    List<AuthorEntity> findAll();

    int save(AuthorEntity author);

    int updateNameByUuid(String uuid, String author);

    int deleteByUuid(String uuid);
}
