package it.fabrick.academy.project1.dto;

import io.swagger.v3.oas.annotations.Parameter;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthorRequestDto {

    @NotBlank(message = "should not be blank")
    @Pattern(regexp = "[\\w\\s]+",message = "Only letters and spaces are accepted " )
    private String name;
}
