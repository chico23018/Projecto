package it.fabrick.academy.project1.service;

import it.fabrick.academy.project1.exception.ValidationExceptionCreate;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.Set;

@Service
public class ValidationService {
    private final ValidatorFactory validatorFactory;

    public ValidationService() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
    }

    /*   public <T> void doValidate(T input) {
           Set<ConstraintViolation<T>> constraintViolations = validatorFactory.getValidator().validate(input);
           List<String> messages = new LinkedList<>();
        if (!constraintViolations.isEmpty()) {
            for (ConstraintViolation constraintViolation : constraintViolations) {
                String message = constraintViolation.getMessage();
                String variablePath = constraintViolation.getPropertyPath().toString();
                String msg = variablePath + ": " + message;
                messages.add(msg);
            }
           }

       }*/
    public void doValidate(Object input) {
        Set<ConstraintViolation<Object>> constraintViolations = validatorFactory.getValidator().validate(input);
        if (!constraintViolations.isEmpty()) {
            throw new ValidationExceptionCreate(constraintViolations);
        }

      /*  List<String> messages = new LinkedList<>();
        if (!constraintViolations.isEmpty()) {
            for (ConstraintViolation constraintViolation : constraintViolations) {
                String message = constraintViolation.getMessage();
                String variablePath = constraintViolation.getPropertyPath().toString();
                String msg = variablePath + ": " + message;
                messages.add(msg);
            }
        }
        if (!messages.isEmpty()) {
            //TODO: THROW exception
            // -- create custom exception
            // -- add message to exception with all the previous constraint issues
            for (String str : messages) {
                throw new ValidationException(str );
            }
        }*/
    }
}
