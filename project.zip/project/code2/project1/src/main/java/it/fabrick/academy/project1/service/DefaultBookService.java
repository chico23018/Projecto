package it.fabrick.academy.project1.service;

import it.fabrick.academy.project1.dto.BookRequestDto;
import it.fabrick.academy.project1.dto.BookResponseDto;
import it.fabrick.academy.project1.dto.BookUpdateRequestDto;
import it.fabrick.academy.project1.entity.BookEntity;
import it.fabrick.academy.project1.exception.BadRequestException;
import it.fabrick.academy.project1.exception.EntityNotFoundException;
import it.fabrick.academy.project1.mapper.IBookMapper;
import it.fabrick.academy.project1.models.BookModel;
import it.fabrick.academy.project1.repositori.IBookRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class DefaultBookService implements IBookService {
    private final IBookRepository iBookRepository;
    private final IBookMapper iBookMapper;

    @Override
    public List<BookModel> readAuthorBooks(String authorId) {
        return iBookRepository
                .findByAuthorId(authorId).stream()
                .map(iBookMapper::modelFromEntity)
                .collect(Collectors.toList());
    }
    @Override
    public BookModel readBook(String authorId, String uuid) {
        BookEntity author = iBookRepository.findByUuid(authorId, uuid);
        if (author == null) {
            throwEntityNotFoundException(uuid);
        }
        return iBookMapper.modelFromEntity(author);

    }

    @Override
    public BookModel createBook(BookModel bookModel, String authorResponseDto) {

        BookEntity bookEntity = iBookMapper.entityFromModel(bookModel);
        bookEntity.setUuid(UUID.randomUUID().toString());
        bookEntity.setAuthorId(authorResponseDto);
        iBookRepository.save(bookEntity);

        return iBookMapper.modelFromEntity(bookEntity);
    }



    @Override
    public BookModel updateBook(String uuid, String uuidBook, BookModel bookModel) {
        String tittle = bookModel.getTittle();
        Integer pageCount =bookModel.getPageCount();

        int howMany=-1;
        if(tittle!=null&pageCount!=null){
            howMany= iBookRepository.updateTittlePageByAuthorIdAndBookId(tittle,pageCount,uuidBook,uuid);
        } else if (tittle!=null) {
            howMany= iBookRepository.updateTittleByAuthorIdAndBookId(tittle,uuidBook,uuid);
        }else if (pageCount!=null) {
            howMany= iBookRepository.updatePageByAuthorIdAndBookId(pageCount,uuidBook,uuid);
        }else {
            log.info("entrato");
          //  howMany=0;
            throw  new BadRequestException("No data to update");
        }

        if (howMany == 0) {

            throwEntityNotFoundException(uuid);
        }

        return readBook(uuid, uuidBook);
    }

    @Override
    public void deleteDelete(String uuid, String uuidBook) {
        iBookRepository.deleteByUuid(uuid, uuidBook);
    }

    private void throwEntityNotFoundException(String uuid) {
        throw new EntityNotFoundException(String.format("Book with uui %s not found", uuid));

    }

}
