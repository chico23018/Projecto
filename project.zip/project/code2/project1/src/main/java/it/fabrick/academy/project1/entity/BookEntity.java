package it.fabrick.academy.project1.entity;

import lombok.*;

import java.util.UUID;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookEntity {
    private String uuid;
    private String tittle;
    private int pageCount;
    private String authorId;
    private  AuthorEntity author;

}
