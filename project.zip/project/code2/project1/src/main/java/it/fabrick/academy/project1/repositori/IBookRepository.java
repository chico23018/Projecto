package it.fabrick.academy.project1.repositori;

import it.fabrick.academy.project1.entity.BookEntity;

import java.util.List;

public interface IBookRepository {
    List<BookEntity> findByAuthorId(String authorId);
    int save(BookEntity bookEntity);


    int deleteByUuid(String uuid, String uuidBook);
    BookEntity findByUuid(String authorId, String uuid);
    int updateTittleByAuthorIdAndBookId(String tittle, String uuid, String author);
    int updatePageByAuthorIdAndBookId(int pageCount, String uuid, String author);
    int updateTittlePageByAuthorIdAndBookId(String tittle,int pageCount,String uuid, String author);
}
