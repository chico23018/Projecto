package it.fabrick.academy.project1.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@Builder
public class ErrorResponseDto {
    private String message;

}
