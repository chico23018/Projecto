package it.fabrick.academy.project1.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
@Getter
@Setter
public class BookUpdateRequestDto {
    @Pattern(regexp = "[\\w\\s]+",message = "Should contains only letters and spaces are accepted " )
    private String tittle;
    @Min(value = 1L,message = "should contains 1")
    private Integer pageCount;
}
