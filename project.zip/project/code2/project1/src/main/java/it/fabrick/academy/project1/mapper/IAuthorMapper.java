package it.fabrick.academy.project1.mapper;

import it.fabrick.academy.project1.dto.AuthorRequestDto;
import it.fabrick.academy.project1.dto.AuthorResponseDto;
import it.fabrick.academy.project1.entity.AuthorEntity;
import it.fabrick.academy.project1.models.AuthorModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface IAuthorMapper {

    AuthorEntity entityFromRequestDto(AuthorRequestDto authorRequestDto);

    @Mapping(source = "bookEntities", target = "books")
    AuthorResponseDto responseDtoFromEntity(AuthorEntity author);
    @Mapping(source = "books", target = "bookEntities")
    AuthorEntity entityFromModel(AuthorModel authorModel);
    @Mapping(source = "bookEntities", target = "books")
    AuthorModel modelFromEntity(AuthorEntity entity);

    AuthorModel modelFromRequest(AuthorRequestDto authorRequestDto);
    AuthorModel modelFromResponse(AuthorResponseDto authorResponseDto);

    AuthorResponseDto responseFromModel(AuthorModel authorModel);


}
