package it.fabrick.academy.project1.repositori;

import it.fabrick.academy.project1.entity.BookEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class BookRepository implements IBookRepository {
    private static final String BOOK_TITLE = "book";
    private static final Random PAGE_COUNT_GENERATOR = new Random();

    @Override
    public List<BookEntity> findByAuthorId(String authorId) {
     /*   return Arrays.asList(
                createStub(BOOK_TITLE),
                createStub(BOOK_TITLE)
        );*/
        log.info("finding books for author");
        return Collections.singletonList(createStub(authorId, BOOK_TITLE));
    }

    @Override
    public int save(BookEntity bookEntity) {

        log.info("Salving book for author " + bookEntity.getAuthorId());
        bookEntity.setUuid(UUID.randomUUID().toString());
        return 1;
    }

    @Override
    public int updateTittleByAuthorIdAndBookId(String tittle, String uuid, String author) {
        log.info("Salving book for author " +uuid+ " for author with id "+ author);
        if (isNotPresent(uuid)) {
            return 0;
        } else {
            createStub(author, UUID.fromString(uuid), BOOK_TITLE);
            return 1;
        }

    }

    @Override
    public int updatePageByAuthorIdAndBookId(int pageCount, String uuid, String author) {
        log.info("Salving book for author " +uuid+ " for author with id "+ author);
        return 1;
    }

    @Override
    public int updateTittlePageByAuthorIdAndBookId(String tittle, int pageCount, String uuid, String author) {
        log.info("Salving book for author " +uuid+ " for author with id "+ author);
        return 1;
    }

    @Override
    public int deleteByUuid(String uuid, String uuidBook) {
        return 1;
    }

    @Override
    public BookEntity findByUuid(String authorId, String uuid) {
        if (isNotPresent(uuid)) {
            return null;
        } else {
            return createStub(authorId, UUID.fromString(uuid), BOOK_TITLE);
        }

    }
    public static BookEntity createStub() {
        return createStub(UUID.randomUUID().toString(),"author");
    }
    public static BookEntity createStub(String authorId, String tittle) {
        return createStub(authorId, UUID.randomUUID(), tittle);
    }

    public static BookEntity createStub(String authorId, UUID uuid, String tittle) {
        return BookEntity.builder().authorId(authorId).tittle(tittle).uuid(uuid.toString()).pageCount(PAGE_COUNT_GENERATOR.nextInt()).build();
    }

    private static boolean isNotPresent(String uuid) {
        return uuid.equals("-1");
    }

}
