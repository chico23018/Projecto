package it.fabrick.academy.project1.models;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
public class AuthorModel {
    private UUID uuid;
    private String name;
    private List<BookModel> books;
}
