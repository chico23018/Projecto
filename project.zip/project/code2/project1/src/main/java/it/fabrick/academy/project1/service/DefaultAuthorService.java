package it.fabrick.academy.project1.service;

import it.fabrick.academy.project1.dto.AuthorRequestDto;
import it.fabrick.academy.project1.dto.AuthorResponseDto;
import it.fabrick.academy.project1.entity.AuthorEntity;
import it.fabrick.academy.project1.exception.EntityNotFoundException;
import it.fabrick.academy.project1.mapper.IAuthorMapper;
import it.fabrick.academy.project1.models.AuthorModel;
import it.fabrick.academy.project1.repositori.IAuthorRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DefaultAuthorService implements IAuthorService {
    private final IAuthorRepository iAuthorRepository;
    private final IAuthorMapper iAuthorMapper;


    @Override
    public AuthorModel readAuthor(String uuid) {
        AuthorEntity author = iAuthorRepository.findByUuid(uuid);
        if (author == null) {
            throwEntityNotFoundException(uuid);
        }
        return iAuthorMapper.modelFromEntity(author);
    }

    @Override
    public List<AuthorModel> readAuthors(Optional<String> name) {
    /*    if (name.isPresent()) {
            return iAuthorRepository.findByName(name.get())
                    .stream()
                    .map(iAuthorMapper::responseDtoFromEntity)
                    .collect(Collectors.toList());
        } else {
            return iAuthorRepository
                    .findAll()
                    .stream()
                    .map(iAuthorMapper::responseDtoFromEntity)
                    .collect(Collectors.toList());
        }*/
        return name.map(iAuthorRepository::findByName)
                .orElse(iAuthorRepository.findAll())
                .stream()
                .map(iAuthorMapper::modelFromEntity)
                .collect(Collectors.toList());

    }

    @Override
    public AuthorModel createAuthor(AuthorModel authorModel) {
        AuthorEntity author = iAuthorMapper.entityFromModel(authorModel);
        author.setUuid(UUID.randomUUID().toString());
        iAuthorRepository.save(author);
        return iAuthorMapper.modelFromEntity(author);

    }

    @Override
    public AuthorModel updateAuthor(String uuid, AuthorModel authorModel) {
        int howMany = iAuthorRepository.updateNameByUuid(uuid, authorModel.getName());
        if (howMany == 0) {
            throwEntityNotFoundException(uuid);
        }

        return readAuthor(uuid);
    }
    //questo metodo lancia un exception
    private void throwEntityNotFoundException(String uuid) {
        throw new EntityNotFoundException(String.format("Author with uui %s not found", uuid));

    }

    @Override
    public void deleteAuthor(String uuid) {
        int howMany = iAuthorRepository.deleteByUuid(uuid);
        if (howMany == 0) {
            throwEntityNotFoundException(uuid);
        }
    }


}
