package it.fabrick.academy.project1.controller;

import it.fabrick.academy.project1.dto.AuthorRequestDto;
import it.fabrick.academy.project1.dto.AuthorResponseDto;
import it.fabrick.academy.project1.mapper.IAuthorMapper;
import it.fabrick.academy.project1.models.AuthorModel;
import it.fabrick.academy.project1.service.IAuthorService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AuthorControllerTest {
    @MockBean
    private IAuthorService iAuthorService;
    @Autowired
    private AuthorController authorController;
    @Autowired
    private IAuthorMapper iAuthorMapper;

    @Test
    void shouldLoads() {
        AuthorModel authorModel = iAuthorMapper.modelFromResponse(createMockAuthor());

        Mockito.when(iAuthorService.readAuthors(Optional.ofNullable(null)))
                .thenReturn(Collections.singletonList(authorModel));

        ResponseEntity<List<AuthorResponseDto>> response = authorController.readAuthors(null, null);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

  /*  @Test
    void shouldCreateAuthor() {
        AuthorRequestDto authorRequestDto = createMockRequest();
        AuthorModel  authorModel1=  iAuthorMapper.modelFromRequest(authorRequestDto);
        AuthorModel authorModel =  iAuthorMapper.modelFromResponse(createMockAuthor());
        Mockito.when(iAuthorService.createAuthor(authorModel1))
                .thenReturn(authorModel);


        String uri = "/v1.0/authors/" + authorModel.getUuid();

        ResponseEntity<AuthorResponseDto> response = authorController.
                createAuthor(authorRequestDto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(authorModel.getUuid(), response.getBody().getUuid());
        assertEquals(uri, response.getHeaders().getLocation().toString());
        System.out.println(response.getHeaders().getLocation().toString());
    }

    @Test
    void shouldUpdateAuthor() {
        AuthorRequestDto authorRequestDto = createMockRequest();
        AuthorModel  authorModel1=  iAuthorMapper.modelFromRequest(authorRequestDto);
        AuthorModel  authorModel = iAuthorMapper.modelFromResponse(createMockAuthor());

        Mockito.when(iAuthorService.updateAuthor(authorModel.getUuid().toString(),authorModel1))
                .thenReturn(authorModel);

        String uuid = authorModel.getUuid().toString();
        String name = authorModel.getName();

        ResponseEntity<AuthorResponseDto> response = authorController.updateAuthor(uuid, authorRequestDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(name, response.getBody().getName());
    }*/
    @Test
    void shouldDeleteAuthor() {
        AuthorResponseDto authorResponseDto = createMockAuthor();
        Mockito.doNothing()
                .when(iAuthorService)
                .deleteAuthor(authorResponseDto.getUuid().toString());

        ResponseEntity<Void> author = authorController.deleteAuthor(authorResponseDto.getUuid().toString());
        assertEquals(HttpStatus.NO_CONTENT, author.getStatusCode());
    }

    private AuthorResponseDto createMockAuthor() {

        return AuthorResponseDto.builder()
                .name("authors")
                .uuid(UUID.randomUUID())
                .build();
    }

    private AuthorRequestDto createMockRequest() {

        return AuthorRequestDto.builder().name("Author").build();
    }

}