package it.fabrick.academy.project1.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.UUID;

@SpringBootTest
@AutoConfigureMockMvc
class RestCrudTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    void shouldRead() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/authors")).
                andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(2)));

    }

    @Test
    void shouldCreateAuthor() throws Exception {

        String json = new ObjectMapper().writeValueAsString(AuthorRequestDto.builder().name("Author").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/authors")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json)).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is("Author")));
    }

    @Test
    void shouldPutAuthor() throws Exception {


        String json = new ObjectMapper().writeValueAsString(AuthorRequestDto.builder().name("Author").build());
        String uui = UUID.randomUUID().toString();

        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/authors/" + uui)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is("Author")))
                .andExpect(MockMvcResultMatchers.jsonPath("$.uuid", Matchers.is(uui+1)));
    }

    @Test
    void shouldDeleteAuthor() throws Exception {


        String uui = UUID.randomUUID().toString();
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/authors/" + uui))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }
    @Test
    void shouldNotFoundAuthor() throws Exception {
        String uuid="-1";

        String cont = new ObjectMapper().writeValueAsString( AuthorRequestDto.builder().name("chico").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/authors/" + uuid)
                .contentType(MediaType.APPLICATION_JSON)
                .content(cont)).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
    @Test
    void shouldNot() throws Exception {
        String json = new ObjectMapper().writeValueAsString(AuthorRequestDto.builder().name("/").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/authors")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json)).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest());
    }
}