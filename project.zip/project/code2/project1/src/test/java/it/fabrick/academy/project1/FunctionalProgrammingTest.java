package it.fabrick.academy.project1;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

public class FunctionalProgrammingTest {
    @Test
    public void shouldAddOneToEachELem(){
        List<Integer> odd = Arrays.asList(1,3,5,7,9);

        List<Integer> evens= odd.stream()
                .map(integer -> integer+1)
                .collect(Collectors.toList());

        Set<Integer> expected= Set.of(2,4,6,8,10);
      //  assertEquals(expected,evens);
        Optional<Integer> optionalInteger = evens
                .stream()
                .filter(integer -> !expected.contains(integer))
                .findAny();
        boolean everythingIsOk = optionalInteger.isEmpty();
        boolean everythingIsWrong =evens
                .stream()
                .anyMatch(integer -> !expected.contains(integer));
        assertTrue(everythingIsOk);
        assertFalse(everythingIsWrong);
    }
}
