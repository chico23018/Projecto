package com.example.demo.mapper;

public interface ActorMapper {
}
