package com.example.demo.generator;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.UUIDGenerator;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.util.Properties;
import java.util.UUID;

public class CustomUUID extends SequenceStyleGenerator {
    public static  final String UUID_PREFIX ="uuid_prefix";
private String prefix ;
    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
      //  return prefix+ UUID.randomUUID().toString();
        return  UUID.randomUUID().toString();
        // UUIDGenerator.UUID_GEN_STRATEGY
    }

    @Override
    public void configure(Type type, Properties params, ServiceRegistry serviceRegistry) throws MappingException {
        super.configure(type, params, serviceRegistry);
        prefix=params.getProperty(UUID_PREFIX);
    }
}
