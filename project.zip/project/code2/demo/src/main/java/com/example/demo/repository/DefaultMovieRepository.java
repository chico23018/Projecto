package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;
import com.example.demo.entity.MovieEntity;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@AllArgsConstructor
public class DefaultMovieRepository implements MovieRepository {

    private final FakeRepoGeneratorService fakeRepoGeneratorService;

    @Override
    public List<MovieEntity> findByDirectorUuid(String directorUuid) {
        return fakeRepoGeneratorService.getDirectorEntity(directorUuid)
                .map(DirectorEntity::getMovies)
                .orElse(Collections.emptyList());
    }

    @Override
    public int save(MovieEntity movieEntity) {
        movieEntity.setUuid(UUID.randomUUID().toString());
        return 1;
    }

    @Override
    public MovieEntity findByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid) {
        return directorHasDirectedMovie(movieUuid, directorUuid).orElse(null);
    }

    @Override
    public int updateTitleAndDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid,
                                                                         String title, int durationInMinutes) {
        return directorHasDirectedMovie(movieUuid, directorUuid).isPresent() ? 1 : 0;
    }

    @Override
    public int updateTitleByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title) {
        return directorHasDirectedMovie(movieUuid, directorUuid).isPresent() ? 1 : 0;
    }

    @Override
    public int updateDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, int durationInMinutes) {
        return directorHasDirectedMovie(movieUuid, directorUuid).isPresent() ? 1 : 0;
    }

    @Override
    public int deleteByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid) {
        return directorHasDirectedMovie(movieUuid, directorUuid).isPresent() ? 1 : 0;
    }

    private Optional<MovieEntity> directorHasDirectedMovie(String movieUuid, String directorUuid) {
        return fakeRepoGeneratorService.getDirectorEntity(directorUuid)
                .map(DirectorEntity::getMovies)
                .flatMap(movieEntities -> movieEntities.stream()
                        .filter(movieEntity -> movieEntity.getUuid().equals(movieUuid))
                        .findAny());
    }
}
