package com.example.demo.mapper;

import com.example.demo.dto.CreateMovieRequestDto;
import com.example.demo.dto.MovieResponseDto;
import com.example.demo.dto.UpdateMovieRequestDto;
import com.example.demo.entity.MovieEntity;
import com.example.demo.model.MovieModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface MovieMapper {

    MovieModel modelFromEntity(MovieEntity movieEntity);

    MovieResponseDto responseFromModel(MovieModel movieModel);

    MovieModel modelFromCreateRequest(CreateMovieRequestDto createMovieRequestDto);

    MovieEntity entityFromModel(MovieModel movieModel);

    MovieModel modelFromUpdateRequest(UpdateMovieRequestDto updateMovieRequestDto);
}
