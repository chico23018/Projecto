package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DefaultDirectorRepository implements DirectorRepository {

    private final FakeRepoGeneratorService fakeRepoGeneratorService;

    @Override
    public List<DirectorEntity> findAll() {
        return fakeRepoGeneratorService.getDirectorEntities();
    }

    @Override
    public List<DirectorEntity> findByName(String name) {
        return this.fakeRepoGeneratorService.getDirectorEntities().stream()
                .filter(directorEntity -> directorEntity.getName().equals(name))
                .collect(Collectors.toList());
    }

    @Override
    public int save(DirectorEntity directorEntity) {
        directorEntity.setUuid(UUID.randomUUID().toString());
        return 1;
    }

    @Override
    public DirectorEntity findByUuid(String uuid) {
        return fakeRepoGeneratorService.getDirectorEntity(uuid).orElse(null);
    }

    @Override
    public int updateNameByUuid(String name, String uuid) {
        return fakeRepoGeneratorService.getDirectorEntity(uuid).map(directorEntity -> 1).orElse(0);
    }

    @Override
    public int deleteByUuid(String uuid) {
        return fakeRepoGeneratorService.getDirectorEntity(uuid).map(directorEntity -> 1).orElse(0);
    }
}
