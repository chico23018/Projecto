package com.example.demo.repository;

import com.example.demo.entity.MovieEntity;

import java.util.List;

public interface MovieRepository {

    MovieEntity findByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);

    List<MovieEntity> findByDirectorUuid(String directorUuid);

    int save(MovieEntity movieEntity);

    int updateTitleAndDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title, int durationInMinutes);

    int updateTitleByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title);

    int updateDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, int durationInMinutes);

    int deleteByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);
}
