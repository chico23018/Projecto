package com.example.demo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Schema(description = "The response model of a single movie")
@Getter
@Setter
public class MovieResponseDto {

    @Schema(description = "The unique identifier of the director")
    private UUID uuid;
    @Schema(description = "The movie title")
    private String title;
    @Schema(description = "The movie total duration expressed in minutes")
    private int durationInMinutes;
}
