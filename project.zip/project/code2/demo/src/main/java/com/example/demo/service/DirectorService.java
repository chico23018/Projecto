package com.example.demo.service;

import com.example.demo.entity.DirectorEntity;
import com.example.demo.enumeration.ErrorCode;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.mapper.DirectorMapper;
import com.example.demo.model.DirectorModel;
import com.example.demo.repository.DirectorRepository;
import lombok.AllArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DirectorService {

    private final DirectorRepository directorRepository;

    private final DirectorMapper directorMapper;

    public DirectorModel readDirector(String uuid) {
        ValidationService.doValidateUuid(uuid);

        return Optional.ofNullable(directorRepository.findByUuid(uuid))
                .map(directorMapper::modelFromEntity)
                .orElseThrow(() -> generateDataNotFoundException(uuid));
    }

    public List<DirectorModel> readDirectors(@Nullable String name) {
        return Optional.ofNullable(name) // Name may be null, so we are wrapping it into an optional
                // Optional<String>
                .map(directorRepository::findByName) // If I have a name filter, I'll look for directors with the given name
                // Optional<List<DirectorEntity>> / Optional EMPTY
                .orElseGet(directorRepository::findAll) // If I don't have a name filter, I'll get all the directors
                // List<DirectorEntity>
                .stream() // Stream the list of results
                .map(directorMapper::modelFromEntity) // Map each entity into a model
                .collect(Collectors.toList()); // Collect the list
    }

    public DirectorModel createDirector(DirectorModel directorModel) {
        boolean isNameAlreadyPresent = !readDirectors(directorModel.getName()).isEmpty();
        if (isNameAlreadyPresent) {
            throw new BadRequestException(String.format("Director with name '%s' already present", directorModel.getName()),
                    ErrorCode.DATA_NOT_VALID);
        }
        DirectorEntity directorEntity = directorMapper.entityFromModel(directorModel);
        directorRepository.save(directorEntity);
        DirectorModel created = directorMapper.modelFromEntity(directorEntity);
        created.setUuid(UUID.fromString(directorEntity.getUuid()));
        return created;
    }

    public DirectorModel updateDirector(String uuid, DirectorModel directorModel) {
        ValidationService.doValidateUuid(uuid);
        int howMany = directorRepository.updateNameByUuid(directorModel.getName(), uuid);
        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
        DirectorModel updated = directorMapper.modelFromEntity(directorRepository.findByUuid(uuid));
        // TODO: this is just for mock purpose, remove when DB will be connected
        updated.setName(directorModel.getName());
        return updated;
    }

    public void deleteDirector(String uuid) {
        ValidationService.doValidateUuid(uuid);
        int howMany = directorRepository.deleteByUuid(uuid);
        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
    }

    private DataNotFoundException generateDataNotFoundException(String uuid) {
        return new DataNotFoundException(String.format("No director found for uuid '%s'", uuid));
    }
}
