package com.example.demo.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AwardResponseDto {
    private UUID movieUui;
    private String description;
    private UUID uuid;
}
