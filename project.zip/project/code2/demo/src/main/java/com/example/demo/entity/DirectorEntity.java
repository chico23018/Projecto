package com.example.demo.entity;

import com.example.demo.generator.CustomUUID;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "director")
public class DirectorEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "com.example.demo.generator.CustomUUID",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = CustomUUID.UUID_PREFIX, value = "ciao")
            })
    @Column(name = "uuid")
    private String uuid;
    @Column(name = "name")
    private String name;

    @Column(name = "birthday")
    private LocalDate birthDate;
/*
    @OneToMany(mappedBy = "uuid")
    private List<MovieEntity> movies;*/
}
