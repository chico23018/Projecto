package com.example.demo.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.id.UUIDGenerator;

import javax.persistence.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "award")
public class AwardEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "uuid")
    @GenericGenerator(name = "uuid",strategy = "com.example.demo.generator.CustomUUID")
    @Column(name = "uuid")
    private String uuid;

    private String movieUui;

    @Column(name = "description")
    private String description;

}
