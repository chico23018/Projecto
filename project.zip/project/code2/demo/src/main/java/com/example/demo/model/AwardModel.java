package com.example.demo.model;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AwardModel {
    private UUID movieUui;
    private String description;
    private UUID uuid;
}
