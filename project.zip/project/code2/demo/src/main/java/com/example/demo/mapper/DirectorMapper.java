package com.example.demo.mapper;

import com.example.demo.dto.DirectorRequestDto;
import com.example.demo.dto.DirectorResponseDto;
import com.example.demo.entity.DirectorEntity;
import com.example.demo.model.DirectorModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface DirectorMapper {

    DirectorResponseDto responseFromModel(DirectorModel directorModel);

    DirectorModel modelFromEntity(DirectorEntity directorEntity);

    DirectorEntity entityFromModel(DirectorModel directorModel);

    DirectorModel modelFromRequest(DirectorRequestDto directorRequestDto);
}
