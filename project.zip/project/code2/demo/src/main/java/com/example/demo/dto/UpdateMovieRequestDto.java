package com.example.demo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@Schema(description = "The request model to update a single movie")
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateMovieRequestDto {

    @Schema(description = "The movie title")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String title;

    @Schema(description = "The movie total duration expressed in minutes")
    @Min(value = 1, message = "Should be at least 1")
    private Integer durationInMinutes;
}
