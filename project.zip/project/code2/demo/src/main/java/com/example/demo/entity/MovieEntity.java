package com.example.demo.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.id.UUIDGenerator;

import javax.persistence.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "movie")
public class MovieEntity {
    @Id
    @Column(name = "uuid")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "uuid")
    @GenericGenerator(name = "uuid",strategy = "com.example.demo.generator.CustomUUID")
    private String uuid;
    @Column(name = "tittle")
    private String title;
    @Column(name = "duration")
    private int durationInMinutes;
/*
    @ManyToOne
    @JoinColumn(name = "directorUuid", referencedColumnName = "uuid")
    private DirectorEntity director;*/
}
