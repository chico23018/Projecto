package com.example.demo.mapper;

public interface AwardMapper {
}
