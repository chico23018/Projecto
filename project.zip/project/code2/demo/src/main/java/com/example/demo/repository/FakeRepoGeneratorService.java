package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;
import com.example.demo.entity.MovieEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class FakeRepoGeneratorService {

    private final List<DirectorEntity> directorEntities;

    public FakeRepoGeneratorService(@Value("#{'${directors}'.split(',')}") List<String> directors,
                                    @Value("#{'${movies}'.split(',')}") List<String> movies) {
        directorEntities = directors.stream()
                .map(s -> DirectorEntity.builder()
                        .uuid(UUID.randomUUID().toString())
                        .name(s)
                        .movies(new LinkedList<>())
                        .build())
                .collect(Collectors.toList());
        for (String movie: movies) {
            String[] parts = movie.split(":");
            String directorIndex = parts[0];
            String movieTitle = parts[1];
            String durationInMinutes = parts[2];
            DirectorEntity directorEntity = directorEntities.get(Integer.parseInt(directorIndex));
            MovieEntity movieEntity = MovieEntity.builder()
                    .uuid(UUID.randomUUID().toString())
                    .title(movieTitle)
                    .durationInMinutes(Integer.parseInt(durationInMinutes))
                    .director(directorEntity)
                    .build();
            directorEntity.getMovies().add(movieEntity);
        }
    }

    public List<DirectorEntity> getDirectorEntities() {
        return directorEntities;
    }

    public Optional<DirectorEntity> getDirectorEntity(String uuid) {
        return directorEntities.stream()
                .filter(directorEntity -> directorEntity.getUuid().equals(uuid))
                .findAny();
    }
}
