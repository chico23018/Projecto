package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;

import java.util.List;

public interface DirectorRepository {

    List<DirectorEntity> findAll();

    List<DirectorEntity> findByName(String name);

    DirectorEntity findByUuid(String uuid);

    int save(DirectorEntity directorEntity);

    int updateNameByUuid(String name, String uuid);

    int deleteByUuid(String uuid);
}
