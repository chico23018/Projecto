package it.fabrick.movie.restTest;

import com.fasterxml.jackson.databind.ObjectMapper;
import it.fabrick.movie.dto.DirectorRequest;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
public class RestControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @Test
    void shouldRead() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/director"))
                .andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)));
    }
    @Test
    void shouldReadUuid() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/director?uuid=339cd9e1-1c0c-4ab9-a3a9-119a71ef0a6b"))
                .andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)));
    }
    @Test
    void shouldReadUuidNotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/director?uuid=339cd9e1-1c0c-4ab9-a3a9-119a71ef0a65"))
                .andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(0)));
    }@Test
    void shouldName() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/director?name=Francisco"))
                .andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)));
    }
    @Test
    void shouldNameNotFound() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/director?name=Nothing"))
                .andDo(MockMvcResultHandlers.print()).
                andExpect(MockMvcResultMatchers.status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(0)));
    }
   /* @Test
    void shouldCreate() throws Exception {
        String json = new ObjectMapper().writeValueAsString(DirectorRequest.builder().name("Javier").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/director")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)).andDo(MockMvcResultHandlers.print())
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is("Javier")));;
    }*/

}
