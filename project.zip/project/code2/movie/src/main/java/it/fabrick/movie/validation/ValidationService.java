package it.fabrick.movie.validation;

import it.fabrick.movie.exception.ValidationExceptionCreate;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.Set;

@Service
public class ValidationService {
    private final ValidatorFactory validatorFactory;

    public ValidationService() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
    }


    public void doValidate(Object input) {
        Set<ConstraintViolation<Object>> constraintViolations = validatorFactory.getValidator().validate(input);
        if (!constraintViolations.isEmpty()) {
            throw new ValidationExceptionCreate(constraintViolations);
        }

    }
}
