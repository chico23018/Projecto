package it.fabrick.movie.repository;

import it.fabrick.movie.entity.MovieEntity;

import java.util.List;


public class RepositoryMovie implements IRepositoryMovie {

    @Override
    public List<MovieEntity> findALl(String uuidDirector) {
        return null;
    }

    @Override
    public List<MovieEntity> findByName(String uuidDirector, String name) {
        return null;
    }

    @Override
    public List<MovieEntity> findByUuid(String uuidDirector, String uuid) {
        return null;
    }


    @Override
    public int save(MovieEntity movieEntity) {
        return 0;
    }

    @Override
    public int update(String uuid, MovieEntity movieEntity) {
        return 0;
    }

    @Override
    public int delete(String uuidMovie, String uuidDirector) {
        return 0;
    }


}
