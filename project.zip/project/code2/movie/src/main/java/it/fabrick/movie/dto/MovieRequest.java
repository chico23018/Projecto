package it.fabrick.movie.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MovieRequest {

    private String name;

}
