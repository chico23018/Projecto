package it.fabrick.movie.service;

import it.fabrick.movie.exception.BadRequestException;
import it.fabrick.movie.exception.EntityNotFoundException;
import it.fabrick.movie.mapper.MapperDirector;
import it.fabrick.movie.models.DirectorModel;
import it.fabrick.movie.repository.IRepositoryDirector;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor

public class ServiceDirector implements IServiceDirector {
    private final IRepositoryDirector iRepositoryDirector;
    private final MapperDirector mapperDirectory;


    @Override
    public List<DirectorModel> readDirectory(String uuid) {
        return iRepositoryDirector.findByUuid(uuid)
                .stream()
                .map(mapperDirectory::modelToEntity).collect(Collectors.toList());
    }

    @Override
    public List<DirectorModel> readDirectories(String name) {
        return Optional.ofNullable(name).map(iRepositoryDirector::findByName)
                .orElseGet(iRepositoryDirector::findALl)
                .stream().map(mapperDirectory::modelToEntity).collect(Collectors.toList());
    }

    @Override
    public DirectorModel createDirectory(DirectorModel directorModel) {
        directorModel.setUuid(UUID.randomUUID());
        if (iRepositoryDirector.save(mapperDirectory.entityToModel(directorModel)) == 0)
            throw new BadRequestException("IS present this Director");

        return createDirectory(directorModel.getUuid(), directorModel.getName());
    }

    @Override
    public DirectorModel updateDirectory(String uuid, DirectorModel directorModel) {
        if (iRepositoryDirector.update(uuid,mapperDirectory.entityToModel(directorModel)) == 0)
            throwEntityNotFoundException(uuid);

        return createDirectory(directorModel.getUuid(), directorModel.getName());


    }

    @Override
    public void deleteDirectory(String uuid) {
        if (iRepositoryDirector.delete(uuid) == 0) {
            throwEntityNotFoundException(uuid);
        }

    }

    private DirectorModel createDirectory(UUID uuid, String name) {
        return DirectorModel.builder()
                .uuid(uuid)
                .name(name).build();
    }

    private void throwEntityNotFoundException(String uuid) {
        throw new EntityNotFoundException(String.format("Directory with uuid %s not found", uuid));

    }
}
