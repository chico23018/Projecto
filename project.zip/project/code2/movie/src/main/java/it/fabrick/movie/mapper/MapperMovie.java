package it.fabrick.movie.mapper;

import it.fabrick.movie.dto.DirectorRequest;
import it.fabrick.movie.dto.DirectorResponse;
import it.fabrick.movie.dto.MovieRequest;
import it.fabrick.movie.dto.MovieResponse;
import it.fabrick.movie.entity.DirectoryEntity;
import it.fabrick.movie.entity.MovieEntity;
import it.fabrick.movie.models.DirectorModel;
import it.fabrick.movie.models.MovieModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface MapperMovie {
    MovieModel modelToEntity(MovieEntity movieEntity);
    MovieEntity entityToModel(MovieModel model);

    MovieModel modelToResponse(MovieResponse response);
    MovieResponse responseToModel(MovieModel model);

    MovieModel modelToRequest(MovieRequest movieRequest);
    MovieRequest requestToModel(MovieModel model);

}
