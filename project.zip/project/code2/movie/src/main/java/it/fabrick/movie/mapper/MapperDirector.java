package it.fabrick.movie.mapper;

import it.fabrick.movie.dto.DirectorRequest;
import it.fabrick.movie.dto.DirectorResponse;
import it.fabrick.movie.entity.DirectoryEntity;
import it.fabrick.movie.models.DirectorModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface MapperDirector {
    DirectorModel modelToEntity(DirectoryEntity directoryEntity);
    DirectoryEntity entityToModel(DirectorModel directorModel);

    DirectorModel modelToResponse(DirectorResponse directorResponse);
    DirectorResponse responseToModel(DirectorModel directorModel);

    DirectorModel modelToRequest(DirectorRequest directorRequest);
    DirectorRequest requestToModel(DirectorModel directorModel);

}
