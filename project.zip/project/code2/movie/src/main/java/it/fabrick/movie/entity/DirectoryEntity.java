package it.fabrick.movie.entity;

import lombok.*;

import java.util.List;
import java.util.UUID;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DirectoryEntity {
    private String uuid;
    private String name;
    private List<MovieEntity> list;
}
