package it.fabrick.movie.repository;

import it.fabrick.movie.entity.DirectoryEntity;
import it.fabrick.movie.exception.BadRequestException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;


public class RepositoryDirector implements IRepositoryDirector {
    @Override
    public List<DirectoryEntity> findALl() {
        return Arrays.asList(
                createDirectory(UUID.randomUUID(), "Francisco"),
                createDirectory(UUID.randomUUID(), "Eduardo")
        );
    }

    @Override
    public List<DirectoryEntity> findByName(String name) {
        return Collections.singletonList(createDirectory(UUID.randomUUID(), name));
    }

    @Override
    public List<DirectoryEntity> findByUuid(String uuid) {
        UUID uuid1 = null;

        if (uuid.length() != 36) {
            throw new BadRequestException("Error uuid not valid " + uuid);
        } else {
            uuid1 = UUID.fromString(uuid);
        }
        System.out.println(uuid1.toString().length());
        return Collections.singletonList(createDirectory(uuid1, "ResgistaFindUuid"));
    }

    @Override
    public int save(DirectoryEntity directoryEntity) {
        if (validate(directoryEntity.getUuid()))
            return 0;
        return 1;
    }

    @Override
    public int update(String uuid, DirectoryEntity directoryEntity) {
        if (validate(directoryEntity.getUuid()))
            return 0;
        return 1;
    }

    @Override
    public int delete(String uuid) {
        if (validate(uuid))
            return 0;
        return 1;
    }

    private boolean validate(String uuid) {
        return uuid.equals("-1");
    }

    private DirectoryEntity createDirectory(UUID uuid, String name) {
        return DirectoryEntity.builder()
                .uuid(uuid.toString())
                .name(name).build();
    }


}
