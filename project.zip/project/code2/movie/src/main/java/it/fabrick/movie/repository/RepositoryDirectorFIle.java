package it.fabrick.movie.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import it.fabrick.movie.entity.DirectoryEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class RepositoryDirectorFIle implements IRepositoryDirector {
    private static ObjectMapper objectMapper = new ObjectMapper();
    private static List<DirectoryEntity> directoryEntities = null;
    private static File file = new File("C:\\Users\\GBS09334\\Documents\\json\\DirectorEntity.json");

    public RepositoryDirectorFIle() throws IOException {
        directoryEntities = readFile();
    }

    @Override
    public List<DirectoryEntity> findALl() {
        return directoryEntities;
    }

    @Override
    public List<DirectoryEntity> findByName(String name) {
        return directoryEntities.stream().filter(x -> x.getName().equals(name)).collect(Collectors.toList());
    }

    @Override
    public List<DirectoryEntity> findByUuid(String uuid) {

        return directoryEntities.stream().filter(x -> x.getUuid().equals(uuid)).collect(Collectors.toList());
    }

    @Override
    public int save(DirectoryEntity directoryEntity) {
        int in = 0;
        for (DirectoryEntity directory : directoryEntities) {
            if (!directory.getName().equals(directoryEntity.getName())) {

                directoryEntities.add(directoryEntity);
                in = 1;
            }
        }
        return in;
    }

    @Override
    public int update(String uuid, DirectoryEntity directoryEntity) {
        int in = 0;

        if (directoryEntity == null)
            return 0;

        for (DirectoryEntity directory : directoryEntities) {
            log.info(uuid);
            log.info(uuid + " here");
            if (directory.getUuid().equals(uuid)) {

                if (directoryEntity.getName() != null) {
                    directory.setName(directoryEntity.getName());
                    in = 1;
                }
            }
        }
        saveAllDirectorEntity(directoryEntities);
        return in;
    }

    @Override
    public int delete(String uuid) {
        int in = 0;
        DirectoryEntity directory1 = null;
        for (DirectoryEntity directory : directoryEntities) {
            if (directory.getUuid().equals(uuid)) {
                directory1 = directory;
                in = 1;
            }
        }
        directoryEntities.remove(directory1);
        saveAllDirectorEntity(directoryEntities);
        return in;
    }


    public static List<DirectoryEntity> readFile() throws IOException {

        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        if (file.exists()) {
            try {
                return directoryEntities = objectMapper.readValue(file, new TypeReference<>() {
                });
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        } else {
            return directoryEntities = new ArrayList<>();
        }
    }

    public static void saveAllDirectorEntity(List<DirectoryEntity> list) {
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, false);
        try {
            objectMapper.writeValue(new File(file.toString()), list);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
