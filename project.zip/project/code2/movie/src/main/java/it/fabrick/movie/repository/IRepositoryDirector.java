package it.fabrick.movie.repository;

import it.fabrick.movie.entity.DirectoryEntity;

import java.util.List;

public interface IRepositoryDirector {
    List<DirectoryEntity> findALl();
    List<DirectoryEntity> findByName(String name);
    List<DirectoryEntity> findByUuid(String uuid);
    int save(DirectoryEntity directoryEntity);
    int update(String uuid, DirectoryEntity directoryEntity);
    int delete(String uuid);
}
