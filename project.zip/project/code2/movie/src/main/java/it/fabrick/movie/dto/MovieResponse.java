package it.fabrick.movie.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;
@Getter
@Setter
public class MovieResponse {
    private UUID uuid;
    private String name;
    private UUID uuiDirector;

}
