package it.fabrick.movie.dto;

import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DirectorRequest {
    @NotBlank(message = "should not be blank")
    @Pattern(regexp = "[\\w\\s]+",message = "Only letters and spaces are accepted " )
    private String name;
}
