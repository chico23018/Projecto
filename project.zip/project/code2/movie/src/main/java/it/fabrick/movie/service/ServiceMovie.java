package it.fabrick.movie.service;

import it.fabrick.movie.exception.BadRequestException;
import it.fabrick.movie.exception.EntityNotFoundException;
import it.fabrick.movie.mapper.MapperMovie;
import it.fabrick.movie.models.DirectorModel;
import it.fabrick.movie.models.MovieModel;
import it.fabrick.movie.repository.IRepositoryMovie;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class ServiceMovie {
    private final IRepositoryMovie iRepositoryMovie;
    private final MapperMovie mapperMovie;

    public List<MovieModel> readMovie(String uuidDirector,String uuid) {

        return iRepositoryMovie.findByUuid(uuidDirector,uuid).stream().map(mapperMovie::modelToEntity).collect(Collectors.toList());
    }

    public List<MovieModel> readMovies(String uuidDirector ,String name) {
        return Optional.ofNullable(name)
                .map(x-> iRepositoryMovie.findByName(uuidDirector,x))
                .orElse(iRepositoryMovie.findALl(uuidDirector))
                .stream().map(mapperMovie::modelToEntity)
                .collect(Collectors.toList());
    }

    public MovieModel createMovie(MovieModel movieModel) {
        if (iRepositoryMovie.save(mapperMovie.entityToModel(movieModel)) == 0) {
            throw new BadRequestException("IS present this movie");
        }
        return movieModel;
    }

    public MovieModel updateMovie(String uuid, MovieModel movieModel) {
        if(iRepositoryMovie.update(uuid, mapperMovie.entityToModel(movieModel))==0){
            throwEntityNotFoundException(movieModel.getUuid().toString());
        }
        return movieModel;
    }

    public void deleteDirectory(String uuid,String uuidDirector) {
        if (iRepositoryMovie.delete(uuid,uuidDirector) == 0) {
            throwEntityNotFoundException(uuid);
        }
    }
    private void throwEntityNotFoundException(String uuid) {
        throw new EntityNotFoundException(String.format("Movie with uuid %s not found", uuid));

    }
}
