package it.fabrick.movie.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class MovieEntity {
    private String uuid;
    private String name;
    private String uuiDirector;
}
