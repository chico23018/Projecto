package it.fabrick.movie.service;

import it.fabrick.movie.models.DirectorModel;

import java.util.List;
import java.util.Optional;

public interface IServiceDirector {

    List<DirectorModel>  readDirectory(String uuid);
    List<DirectorModel> readDirectories(String name);
    DirectorModel createDirectory(DirectorModel directorModel);

    DirectorModel updateDirectory(String uuid, DirectorModel directorModel);

    void deleteDirectory(String uuid);
}
