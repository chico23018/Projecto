package it.fabrick.movie.repository;

import it.fabrick.movie.entity.DirectoryEntity;
import it.fabrick.movie.entity.MovieEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class RepositoryMovieFile implements IRepositoryMovie {
    List<DirectoryEntity> list;

    public RepositoryMovieFile() throws IOException {
        list = RepositoryDirectorFIle.readFile();
    }

    @Override
    public List<MovieEntity> findALl(String uuidDirector) {
        return list.stream().filter(x -> x.getUuid().equals(uuidDirector))
                .map(DirectoryEntity::getList).findAny().get();
    }

    @Override
    public List<MovieEntity> findByName(String uuidDirector, String name) {
        return list.stream()
                .map(DirectoryEntity::getList).findAny().get()
                .stream().filter(x -> x.getName().equals(name))
                .collect(Collectors.toList());
    }

    @Override
    public List<MovieEntity> findByUuid(String uuidDirector, String uuid) {
        return list.stream().filter(x -> x.getUuid().equals(uuidDirector))
                .map(DirectoryEntity::getList).findAny().get()
                .stream().filter(x -> x.getUuid().equals(uuid))
                .collect(Collectors.toList());
    }

    @Override
    public int save(MovieEntity movieEntity) {
        movieEntity.setUuid(UUID.randomUUID().toString());
        int in = 0;
        for (DirectoryEntity directory : list) {
            if (directory.getUuid().equals(movieEntity.getUuiDirector())) {

                if (directory.getList() == null)
                    directory.setList(new ArrayList<>());

                if (directory.getList().isEmpty()) {
                    directory.getList().add(movieEntity);
                    in = 1;
                    RepositoryDirectorFIle.saveAllDirectorEntity(list);
                } else {
                    for (MovieEntity movie : directory.getList()) {
                        if (!movie.getName().equals(movieEntity.getName())) {
                            directory.getList().add(movieEntity);
                            in = 1;
                            RepositoryDirectorFIle.saveAllDirectorEntity(list);

                        }
                    }
                }
            }
        }

        return in;
    }

    @Override
    public int update(String uuid, MovieEntity movieEntity) {
        int in = 0;
        for (DirectoryEntity directory : list) {
            if (directory.getUuid().equals(movieEntity.getUuiDirector())) {
                for (MovieEntity movie : directory.getList()) {
                    movie.setName(movie.getName());
                    in = 1;
                    RepositoryDirectorFIle.saveAllDirectorEntity(list);
                }
            }
        }

        return in;
    }

    @Override
    public int delete(String uuidMovie, String uuidDirector) {
        int in = 0;
        MovieEntity movieEntity = null;

        for (DirectoryEntity directory : list) {
            if (directory.getUuid().equals(uuidDirector)) {
                for (MovieEntity movie : directory.getList()) {
                    movieEntity = movie;
                    in = 1;

                }
                directory.getList().remove(movieEntity);
                RepositoryDirectorFIle.saveAllDirectorEntity(list);
            }
        }

        return in;
    }
}
