package it.fabrick.movie.repository;

import it.fabrick.movie.entity.DirectoryEntity;
import it.fabrick.movie.entity.MovieEntity;

import java.util.List;

public interface IRepositoryMovie {
    List<MovieEntity> findALl(String uuidDirector);
    List<MovieEntity> findByName(String uuidDirector, String name);
    List<MovieEntity> findByUuid(String uuidDirector, String uuid);
    int save(MovieEntity movieEntity);
    int update(String uuid, MovieEntity movieEntity);
    int delete(String uuidMovie,String uuidDirector);
}
