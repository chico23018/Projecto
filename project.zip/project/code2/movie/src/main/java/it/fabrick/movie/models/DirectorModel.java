package it.fabrick.movie.models;

import it.fabrick.movie.entity.MovieEntity;
import lombok.*;

import java.util.List;
import java.util.UUID;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DirectorModel {
    private UUID uuid;
    private String name;
    private List<MovieEntity> list;

}
