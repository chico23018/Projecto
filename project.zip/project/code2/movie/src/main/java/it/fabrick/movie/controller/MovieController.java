package it.fabrick.movie.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import it.fabrick.movie.dto.DirectorRequest;
import it.fabrick.movie.dto.DirectorResponse;
import it.fabrick.movie.dto.MovieRequest;
import it.fabrick.movie.dto.MovieResponse;
import it.fabrick.movie.exception.ErrorResponseDto;
import it.fabrick.movie.mapper.MapperDirector;
import it.fabrick.movie.mapper.MapperMovie;
import it.fabrick.movie.models.DirectorModel;
import it.fabrick.movie.models.MovieModel;
import it.fabrick.movie.service.IServiceDirector;
import it.fabrick.movie.service.ServiceMovie;
import it.fabrick.movie.validation.ValidationService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@AllArgsConstructor
@RequestMapping("/v1.0/director")
public class MovieController {
    private final IServiceDirector iServiceDirector;
    private final MapperDirector mapperDirectory;
    private final ValidationService validationService;
    private final ServiceMovie serviceMovie;
    private final MapperMovie mapperMovie;

    @Operation(description = "GET List Director with the name or uuid")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Director created", content = {
                    @Content(schema = @Schema(implementation = DirectorResponse.class))
            }),
            @ApiResponse(responseCode = "500", description = "data not valid", content = {
                    @Content(schema = @Schema(implementation = ErrorResponseDto.class))
            })})
    @GetMapping
    public ResponseEntity<List<DirectorResponse>> readDirector(@RequestParam(value = "name", required = false)
                                                               @Schema(description = "cerca tramite nome") String name,
                                                               @RequestParam(value = "uuid", required = false)
                                                               @Schema(description = "cerca tramite uuid")
                                                               String uuid) {
        List<DirectorResponse> responseList = null;
        if (uuid != null) {
            responseList = iServiceDirector.readDirectory(uuid)
                    .stream()
                    .map(mapperDirectory::responseToModel)
                    .collect(Collectors.toList());
        } else {
            responseList = iServiceDirector.readDirectories(name)
                    .stream()
                    .map(mapperDirectory::responseToModel)
                    .collect(Collectors.toList());
        }
        return ResponseEntity.ok(responseList);
    }


    @PostMapping
    public ResponseEntity<DirectorResponse> createDirector(@RequestBody DirectorRequest directorRequest) {
        DirectorModel directorModel = iServiceDirector.createDirectory(mapperDirectory.modelToRequest(directorRequest));
        DirectorResponse directorResponse = mapperDirectory.responseToModel(directorModel);
        return ResponseEntity.created(URI.create("/v1.0/director/" + directorResponse.getUuid())).body(directorResponse);
    }


    @PutMapping("/{directorUuid}")
    public ResponseEntity<DirectorResponse> updateDirector(@RequestParam(value = "directorUuid") String uuid,
                                                           @RequestBody DirectorRequest directorRequest) {
        DirectorModel directorModel = iServiceDirector
                .updateDirectory(uuid
                        , mapperDirectory
                                .modelToRequest(directorRequest));
        DirectorResponse directorResponse = mapperDirectory.responseToModel(directorModel);
        return ResponseEntity.ok(directorResponse);
    }

    @DeleteMapping("/{directorUuid}")
    public ResponseEntity<Void> deleteDirector(@RequestParam(value = "directorUuid") String uuid) {
        iServiceDirector.deleteDirectory(uuid);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{directorUuid}/movies")
    public ResponseEntity<List<MovieResponse>> readMovie(@RequestParam(value = "directorUuid") String uuidDirector,
                                                         @RequestParam(value = "name", required = false)
                                                         @Schema(description = "cerca tramite nome") String name,
                                                         @RequestParam(value = "uuid", required = false)
                                                         @Schema(description = "cerca tramite uuid")
                                                         String uuiMovie) {
        List<MovieResponse> movieResponses = null;
        if (uuiMovie != null) {
            movieResponses = movieResponses = serviceMovie.readMovie(uuidDirector, uuiMovie)
                    .stream()
                    .map(mapperMovie::responseToModel).collect(Collectors.toList());
        } else {
            movieResponses = movieResponses = serviceMovie.readMovies(uuidDirector, name)
                    .stream()
                    .map(mapperMovie::responseToModel).collect(Collectors.toList());
        }
        return ResponseEntity.ok(movieResponses);
    }


    @PostMapping("/{directorUuid}/movies")
    public ResponseEntity<MovieResponse> createMovie(@RequestParam(value = "directorUuid") String uuidDirector,
                                                     @RequestBody MovieRequest movieRequest) {
      MovieModel model= mapperMovie.modelToRequest(movieRequest);
      model.setUuiDirector(UUID.fromString(uuidDirector));
        MovieResponse movieResponse = mapperMovie
                .responseToModel(serviceMovie.createMovie(model));
        return ResponseEntity.created(URI.create("/v1.0/director/" + uuidDirector + "/movies/" + movieResponse.getUuid())).body(movieResponse);
    }

}
