package it.fabrick.movie.handler;

import it.fabrick.movie.exception.BadRequestException;
import it.fabrick.movie.exception.EntityNotFoundException;
import it.fabrick.movie.exception.ErrorResponseDto;
import it.fabrick.movie.exception.ValidationExceptionCreate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class GenericException extends ResponseEntityExceptionHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(GenericException.class);

    @ExceptionHandler({EntityNotFoundException.class})
    public ResponseEntity<ErrorResponseDto> handleEntityNotFoundException(EntityNotFoundException e) {
        log.error("Entity not found", e);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ErrorResponseDto.builder().message(e.getMessage()).build());
    }
    @ExceptionHandler(ValidationExceptionCreate.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResponseDto> handleValidationException(ValidationExceptionCreate e) {
        List<String> messages = e.getConstraintViolations()
                .stream()
                .map(cv -> cv.getPropertyPath().toString() + " : " + cv.getMessage()).collect(Collectors.toList());
        log.error(" Request not validation ", e);

        String mess = String.join(", ", messages);

        return ResponseEntity.badRequest().body(ErrorResponseDto.builder().message(mess).build());
    }

    @ExceptionHandler(BadRequestException.class)

    public ResponseEntity<ErrorResponseDto> handleBadRequestException(BadRequestException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ErrorResponseDto.builder().message(e.getMessage()).build());
    }
}
