package com.example.pronotazione.testMvc;

import com.example.pronotazione.enumClass.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.util.StreamUtils;

import java.nio.charset.Charset;

@SpringBootTest
@AutoConfigureMockMvc
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class testMvc {


    @Autowired
    MockMvc mockMvc;
    @Value("classpath:booking.json")
    Resource reservationCreateRequest;
    @Value("classpath:bookingUpdate.json")
    Resource reservationUpdateRequest;

    private String createdResourceLocation;

    private String path1 = "/v1.0/booking";

    @BeforeAll
    void createResource() throws Exception {
        String content = StreamUtils.copyToString(reservationCreateRequest.getInputStream(), Charset.defaultCharset());
        System.out.println(content);
        log.error(content);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(path1)
                        .content(content)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.header().exists(HttpHeaders.LOCATION))
                .andReturn();

        createdResourceLocation = mvcResult.getResponse().getHeader(HttpHeaders.LOCATION);

log.error(createdResourceLocation);
    }

    @Test
    @Order(1)
    void shouldCreateAReservation() throws Exception {
        System.out.println(createdResourceLocation.split("/")[3]);
        mockMvc.perform(MockMvcRequestBuilders.get(path1+"?uuidBooking=" +createdResourceLocation.split("/")[3]  ))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

    @Test
    @Order(2)
    void shouldReadAllReservations() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.get(path1))

                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.greaterThan(0)));
    }

    @Test
    @Order(3)
    void shouldUpdateReservation() throws Exception {
        String content = StreamUtils.copyToString(reservationUpdateRequest.getInputStream(), Charset.defaultCharset());
        mockMvc.perform(MockMvcRequestBuilders.put(createdResourceLocation)
                        .content(content)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @Order(4)
    void shouldDeleteAReservation() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete(createdResourceLocation))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent());
        createResource();
    }

/*    @Test
    void shouldReturnDayAlreadyBooked() throws Exception {
        String content = StreamUtils.copyToString(reservationCreateRequest.getInputStream(), Charset.defaultCharset());
        mockMvc.perform(MockMvcRequestBuilders.post(path1)
                        .content(content)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID)));

    }*/
}