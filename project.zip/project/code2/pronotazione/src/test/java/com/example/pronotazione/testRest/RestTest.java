package com.example.pronotazione.testRest;

import com.example.pronotazione.controller.BookingController;
import com.example.pronotazione.dto.BookingRequestCreateDto;
import com.example.pronotazione.dto.BookingResponseDto;
import com.example.pronotazione.entity.BookingEntity;
import com.example.pronotazione.enumClass.TypeUser;
import com.example.pronotazione.mapper.IBookingMapper;
import com.example.pronotazione.model.BookingModel;
import com.example.pronotazione.repository.IBookingRepository;
import com.example.pronotazione.service.BookingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RestTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private BookingController bookingController;
    @MockBean
    private BookingService service;
    @MockBean
    private IBookingRepository iBookingRepository;
    @Autowired
    private IBookingMapper iBookingMapper1;

    @Autowired
    ObjectMapper objectMapper;
    String pat = "/v1.0/booking";

    @Test
    void testCreate() throws Exception {
        BookingEntity bookingEntity = new BookingEntity();
        BookingModel bookingModel = new BookingModel();
        bookingModel.setContact("56666");
        bookingModel.setUuid(UUID.randomUUID());
        bookingModel.setTypeContact(TypeUser.EMAIL);
        bookingModel.setDay(LocalDate.parse("1991-02-18"));
        bookingModel.setUserIdentity(UUID.randomUUID().toString());
        bookingModel.setDescription("ciao");


        Mockito.when(service.createBooking(Mockito.any())).thenReturn(bookingModel);

        ResponseEntity<BookingResponseDto> response = bookingController.create(crea());

        Assertions.assertNotNull(response, "es null");

    }

    @Test
    void shouldCreateMvc() throws Exception {
        BookingRequestCreateDto bookingRequestCreateDto = crea();
        String content = objectMapper.writeValueAsString(bookingRequestCreateDto);
        BookingModel model = mock();
        mockMvc.perform(MockMvcRequestBuilders.post(pat)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content)
                )

                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.uuid", Matchers.is(model.getUuid())))
               ;
    }

    @Test
    void shouldReadAll() {
        mock();

        ResponseEntity<List<BookingResponseDto>> response = bookingController.readBooking(null);
        Assertions.assertNotNull(response, "es null");

    }

    @Test
    void shouldReadAllMvc() throws Exception {
        mock();

        mockMvc.perform(MockMvcRequestBuilders.get(pat))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)));
    }

    @Test
    void shouldReadByUuid() {
        BookingModel bookingModel = mock();

        List<BookingResponseDto> bookingResponseDtos = bookingController.readBooking(pat + "?uuidBooking=" + bookingModel.getUuid()).getBody();
        Assertions.assertEquals(bookingModel.getUuid(), bookingResponseDtos.get(0).getUuid());
    }


    @Test
    void shouldReadByUuidMvc() throws Exception {
        BookingModel bookingModel = mock();
        mockMvc.perform(MockMvcRequestBuilders.get(pat + "?uuidBooking=" + bookingModel))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)))
        ;

    }

    public BookingModel mock() {
        BookingModel bookingModel = new BookingModel();
        bookingModel.setContact("56666");
        bookingModel.setUuid(UUID.randomUUID());
        bookingModel.setTypeContact(TypeUser.EMAIL);
        bookingModel.setDay(LocalDate.parse("1991-02-18"));
        bookingModel.setUserIdentity(UUID.randomUUID().toString());
        bookingModel.setDescription("ciao");


        Mockito.when(service.createBooking(Mockito.any())).thenReturn(bookingModel);
        Mockito.when(service.update(Mockito.any(), Mockito.any())).thenReturn(bookingModel);
        Mockito.when(service.readBooking(Mockito.any()))
                .thenReturn(Arrays.asList(bookingModel));

        return bookingModel;
    }

    public BookingRequestCreateDto crea() {
        BookingRequestCreateDto bookingRequestCreateDto = new BookingRequestCreateDto();
        bookingRequestCreateDto.setContact("56666");
        bookingRequestCreateDto.setDay(LocalDate.parse("1991-02-18"));
        bookingRequestCreateDto.setTypeContact(TypeUser.PHONE);
        bookingRequestCreateDto.setUserIdentity(UUID.randomUUID().toString());
        bookingRequestCreateDto.setDescription("ciao");
        return bookingRequestCreateDto;
    }

    public BookingModel createModel() {
        BookingModel bookingModel = new BookingModel();
        bookingModel.setContact("56666");
        bookingModel.setUuid(UUID.randomUUID());
        bookingModel.setTypeContact(TypeUser.EMAIL);
        bookingModel.setDay(LocalDate.parse("1991-02-18"));
        bookingModel.setUserIdentity(UUID.randomUUID().toString());
        bookingModel.setDescription("ciao");
        return bookingModel;
    }
}
