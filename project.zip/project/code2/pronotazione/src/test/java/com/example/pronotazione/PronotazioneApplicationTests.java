package com.example.pronotazione;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PronotazioneApplicationTests {

	@Test
	void contextLoads() {
	}

}
