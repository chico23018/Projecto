package com.example.pronotazione.dto;

import com.example.pronotazione.enumClass.TypeUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookingResponseDto {
    private UUID uuid;

    private LocalDate day;


    private String description;


    private TypeUser typeContact;

    private String contact;


}
