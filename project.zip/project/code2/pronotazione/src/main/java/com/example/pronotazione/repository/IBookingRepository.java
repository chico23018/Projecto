package com.example.pronotazione.repository;

import com.example.pronotazione.entity.BookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IBookingRepository extends JpaRepository<BookingEntity, String> {
    @Modifying
    @Query("update booking b set  b.description = :description , b.contact = :reference , b.typeContact = :typeUser where b.uuid = :uuid ")
    int updateByUui(String uuid, String typeUser, String reference, String description);

    @Modifying
    @Query("update booking b set  b.typeContact = :typeUser where b.uuid = :uuid ")
    int updateByUuiTypeContact(String uuid, String typeUser);

    @Modifying
    @Query("update booking b set   b.contact = :reference  where b.uuid = :uuid ")
    int updateByUuiContact(String uuid, String reference);

    @Modifying
    @Query("update booking b set  b.description = :description  where b.uuid = :uuid ")
    int updateByUuiDescription(String uuid, String description);

    int deleteByUuid(String uuid);
    int deleteByUserIdentity(String uuid);

    List<BookingEntity> findByUserIdentity(String userIdentity);

    List<BookingEntity> findByContactAndTypeContactAndDay(String s, String type, LocalDate day);
}
