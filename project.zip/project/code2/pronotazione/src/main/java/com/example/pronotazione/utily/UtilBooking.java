package com.example.pronotazione.utily;

import com.example.pronotazione.entity.BookingEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class UtilBooking {
    private  ObjectMapper objectMapper = new ObjectMapper();
    private  File file;
    private  List<BookingEntity> list;

    public UtilBooking() {
        objectMapper.registerModule(new JavaTimeModule());
        file = new File("booking.json");
        if (file.exists()) {
            try {
                list = objectMapper.readValue(file, new TypeReference<List<BookingEntity>>() {
                });
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            list = new LinkedList<>();
        }


    }

    public  List<BookingEntity> getList() {
        if (list == null)
            list = new LinkedList<>();

        return list;
    }

    public  void write(List<BookingEntity> bookingEntity) {


        try {
            objectMapper.writeValue(new File("booking.json"), bookingEntity);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
