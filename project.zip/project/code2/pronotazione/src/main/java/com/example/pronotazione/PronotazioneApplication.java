package com.example.pronotazione;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PronotazioneApplication {

	public static void main(String[] args) {
		SpringApplication.run(PronotazioneApplication.class, args);
	}

}
