package com.example.pronotazione.service;

import com.example.pronotazione.enumClass.ErrorCode;
import com.example.pronotazione.errorClass.BadRequestException;
import com.example.pronotazione.errorClass.ValidationException;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.Set;
import java.util.UUID;

@Service
public class ValidationService {

    // ValidatorFactory is thread safe, so it is safe to build it as an instance field
    private final ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();

    public void doValidate(Object input) {
        Set<ConstraintViolation<Object>> constraintViolations = validatorFactory.getValidator().validate(input);
        if (!constraintViolations.isEmpty()) {
            // If at least one element is present, some constrain has failed, so throw exception
            throw new ValidationException(constraintViolations);
        }
    }

    public static void doValidateUuid(String uuid) {
        try {
            UUID.fromString(uuid);
        } catch (Exception e) {
            throw new BadRequestException(String.format("Unique identifier '%s' not valid", uuid),
                    e, ErrorCode.DATA_NOT_VALID);
        }
    }
}
