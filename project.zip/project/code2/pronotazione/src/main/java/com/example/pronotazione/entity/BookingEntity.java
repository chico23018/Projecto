package com.example.pronotazione.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "booking")
public class BookingEntity {
    @Id
 /*   @GeneratedValue(generator = "uuid-hibernate-generator")
    @GenericGenerator(name = "uuid-hibernate-generator", strategy = "org.hibernate.id.UUIDGenerator")*/
    @Column(name = "uuid")

    private String uuid;

    @Column(name = "booking_day")
    private LocalDate day;

    @Column(name = "description")
    private String description;

    @Column(name = "type_Contact")
    private String typeContact;

    @Column(name = "contact")
    private String contact;

    @Column(name = "User_Identity")
    private String userIdentity;

    @PrePersist
    public void generatorUuid() {
        if(getUuid()==null){
            setUuid(UUID.randomUUID().toString());
        }
    }

}
