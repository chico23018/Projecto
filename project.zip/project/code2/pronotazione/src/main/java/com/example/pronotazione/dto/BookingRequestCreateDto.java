package com.example.pronotazione.dto;

import com.example.pronotazione.enumClass.TypeUser;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookingRequestCreateDto {
    private LocalDate day;
    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String description;


    private TypeUser typeContact;

    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String contact;

    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String userIdentity;
}
