package com.example.pronotazione.mapper;

import com.example.pronotazione.dto.BookingRequestCreateDto;
import com.example.pronotazione.dto.BookingRequestDto;
import com.example.pronotazione.dto.BookingResponseDto;
import com.example.pronotazione.entity.BookingEntity;
import com.example.pronotazione.model.BookingModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface IBookingMapper {

    BookingEntity entityFromModel(BookingModel bookingModel);

    BookingModel modelFromEntity(BookingEntity bookingEntity);

    BookingModel modelFromResponse(BookingResponseDto bookingResponseDto);

    BookingResponseDto responseFromModel(BookingModel bookingModel);

    BookingModel modelFromRequest(BookingRequestDto bookingRequestDto);

    BookingRequestDto requestFromModel(BookingModel bookingModel);

    BookingModel modelFromRequestCreate(BookingRequestCreateDto bookingRequestCreateDto);

    BookingRequestCreateDto requestFromModelCreate(BookingModel bookingModel);


}
