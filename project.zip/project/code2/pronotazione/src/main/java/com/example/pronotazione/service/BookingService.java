package com.example.pronotazione.service;

import com.example.pronotazione.dto.BookingRequestDto;
import com.example.pronotazione.entity.BookingEntity;
import com.example.pronotazione.enumClass.ErrorCode;
import com.example.pronotazione.errorClass.BadRequestException;
import com.example.pronotazione.errorClass.DataNotFoundException;
import com.example.pronotazione.mapper.IBookingMapper;
import com.example.pronotazione.model.BookingModel;
import com.example.pronotazione.repository.IBookingRepository;
import com.example.pronotazione.utily.UtilBooking;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service

public class BookingService {
    private UtilBooking utilBooking = new UtilBooking();
    private final IBookingRepository bookingRepository;
    private final IBookingMapper iBookingMapper;


    public BookingService(IBookingRepository bookingRepository, IBookingMapper iBookingMapper) {
        this.bookingRepository = bookingRepository;
        this.iBookingMapper = iBookingMapper;
        List<BookingEntity> list = utilBooking.getList();
        if (list != null && !list.isEmpty())
            this.bookingRepository.saveAll(list);


    }

    public List<BookingModel> readBooking(String uuid) {

        if (uuid != null && !uuid.isEmpty()) {
            BookingModel bookingModel = bookingRepository.findById(uuid)
                    .map(iBookingMapper::modelFromEntity)
                    .orElseThrow(() -> generateDataNotFoundException(uuid));
            return Arrays.asList(bookingModel);
        } else {
            return bookingRepository.findAll()
                    .stream()
                    .map(iBookingMapper::modelFromEntity)
                    .collect(Collectors.toList());
        }


    }

    public List<BookingModel> readBookingUuidIdentity(String uuidIdentity) {
        List<BookingModel> list1 = null;
        if (uuidIdentity != null && !uuidIdentity.isEmpty()) {
            list1 = bookingRepository.findByUserIdentity(uuidIdentity)
                    .stream()
                    .map(iBookingMapper::modelFromEntity)
                    .collect(Collectors.toList());

            if (list1.isEmpty()) {
                throw generateDataNotFoundException(uuidIdentity);
            }

        }

        return list1;
    }


    public BookingModel createBooking(BookingModel bookingModel) {

        boolean isNameAlreadyPresent;
        try {
            isNameAlreadyPresent = !bookingRepository.findByContactAndTypeContactAndDay(bookingModel.getContact(), bookingModel.getTypeContact().toString(), bookingModel.getDay()).isEmpty();

        } catch (Throwable e) {
            throw generateException(e);
        }
        if (isNameAlreadyPresent) {
            throw new BadRequestException(String.format("Booking with day  '%s' and reference '%s' already present", bookingModel.getDay(), bookingModel.getContact()),
                    ErrorCode.DATA_NOT_VALID);
        }
        BookingEntity bookingEntity = this.bookingRepository.save(iBookingMapper.entityFromModel(bookingModel));
        utilBooking.write(bookingRepository.findAll());
        return iBookingMapper.modelFromEntity(bookingEntity);

    }

    @Transactional
    public BookingModel update(String uuid, BookingRequestDto bookingRequestDto) {
        ValidationService.doValidateUuid(uuid);
        int howMany;
        try {
            howMany = bookingRepository.updateByUui(uuid, bookingRequestDto.getTypeContact().toString(),
                    bookingRequestDto.getContact(), bookingRequestDto.getDescription());
        } catch (Throwable e) {
            throw generateException(e);
        }
        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }

        BookingEntity bookingEntity = bookingRepository.findById(uuid).get();

        utilBooking.write(bookingRepository.findAll());
        return iBookingMapper.modelFromEntity(bookingEntity);
    }

    @Transactional
    public void delete(String uuid) {
        ValidationService.doValidateUuid(uuid);
        int howMany;
        try {
            howMany = bookingRepository.deleteByUuid(uuid);
        } catch (Throwable e) {
            throw generateException(e);
        }

        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
        utilBooking.write(bookingRepository.findAll());
    }

    @Transactional
    public void deleteAll(String uuid) {
        ValidationService.doValidateUuid(uuid);
        int howMany;
        try {
            howMany = bookingRepository.deleteByUserIdentity(uuid);
        } catch (Throwable e) {
            throw generateException(e);
        }

        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
        utilBooking.write(bookingRepository.findAll());
    }

    private DataNotFoundException generateDataNotFoundException(String uuid) {
        return new DataNotFoundException(String.format("No Booking found for uuid '%s'", uuid));
    }

    private BadRequestException generateException(Throwable e) {
        return new BadRequestException("Error internal ", e.getCause(), ErrorCode.INTERNAL_ERROR);
    }
}
