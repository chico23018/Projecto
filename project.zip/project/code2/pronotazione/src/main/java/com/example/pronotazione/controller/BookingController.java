package com.example.pronotazione.controller;

import com.example.pronotazione.dto.BookingRequestCreateDto;
import com.example.pronotazione.dto.BookingRequestDto;
import com.example.pronotazione.dto.BookingResponseDto;
import com.example.pronotazione.errorClass.ErrorResponseDto;
import com.example.pronotazione.mapper.IBookingMapper;
import com.example.pronotazione.model.BookingModel;
import com.example.pronotazione.service.BookingService;
import com.example.pronotazione.service.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1.0/booking")
@AllArgsConstructor
public class BookingController {
    private final ValidationService validationService;
    private final BookingService service;
    private final IBookingMapper iBookingMapper;

    @Operation(description = "Read all the Booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @GetMapping
    public ResponseEntity<List<BookingResponseDto>> readBooking(@RequestParam(value = "uuidBooking", required = false) String uuid) {
        List<BookingResponseDto> responseDtos = service.readBooking(uuid)
                .stream()
                .map(iBookingMapper::responseFromModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responseDtos);
    }

    @Operation(description = "Create a new booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "CREATED"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST"),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })

    @PostMapping
    public ResponseEntity<BookingResponseDto> create(@RequestBody BookingRequestCreateDto bookingRequestDto) {


        BookingModel bookingModel = service.createBooking(iBookingMapper.modelFromRequestCreate(bookingRequestDto));
        return ResponseEntity.created(URI.create("/v1.0/booking/" + bookingModel.getUuid())).body(iBookingMapper.responseFromModel(bookingModel));
    }

    @Operation(description = "search a given booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PostMapping("/search")
    public ResponseEntity<List<BookingResponseDto>> search(
            @RequestParam(value = "uuidIdentity") String uuidIdentity) {

        List<BookingResponseDto> list = service.readBookingUuidIdentity(uuidIdentity)
                .stream().map(iBookingMapper::responseFromModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    @Operation(description = "Update a given booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PutMapping("/{uuidBooking}")
    public ResponseEntity<BookingResponseDto> update(@PathVariable("uuidBooking") String uuid,
                                                     @RequestBody BookingRequestDto bookingRequestDto) {
        BookingModel bookingModel = service.update(uuid, bookingRequestDto);
        return ResponseEntity.ok(iBookingMapper.responseFromModel(bookingModel));
    }

    @Operation(description = "delete a given booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @DeleteMapping("/{uuidBooking}")
    public ResponseEntity<Void> delete(@PathVariable("uuidBooking") String uuid) {
        service.delete(uuid);
        return ResponseEntity.noContent().build();
    }
    @Operation(description = "delete all")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @DeleteMapping("/deleteAll/{uuidIdentity}")
    public ResponseEntity<Void> deleteALl(@PathVariable("uuidIdentity") String uuid) {
        service.deleteAll(uuid);
        return ResponseEntity.noContent().build();
    }
}
