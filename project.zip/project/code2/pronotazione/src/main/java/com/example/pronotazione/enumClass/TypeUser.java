package com.example.pronotazione.enumClass;

public enum TypeUser {
PHONE, CELL,EMAIL

}
