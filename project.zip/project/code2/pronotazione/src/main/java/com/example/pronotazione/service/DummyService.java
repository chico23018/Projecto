package com.example.pronotazione.service;

import com.example.pronotazione.entity.BookingEntity;
import com.example.pronotazione.repository.IBookingRepository;
import com.example.pronotazione.utily.UtilBooking;
import org.springframework.stereotype.Service;

import java.util.List;


public class DummyService {
    private UtilBooking utilBooking = new UtilBooking();
    private final IBookingRepository bookingRepository;
    public DummyService(IBookingRepository bookingRepository){
        this.bookingRepository = bookingRepository;

    }

}
