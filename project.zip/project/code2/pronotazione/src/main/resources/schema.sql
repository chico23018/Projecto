DROP TABLE IF EXISTS booking;
CREATE TABLE booking(
UUID VARCHAR(70) PRIMARY KEY,
BOOKING_DAY DATE not null ,
DESCRIPTION   VARCHAR(70) not null,
type_Contact VARCHAR(70) not null,
contact VARCHAR(70) not null,
User_Identity VARCHAR(70)  not null
);
