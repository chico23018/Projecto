package it.fabrick.academy.week4;

import it.fabrick.academy.week4.constant.Constants;
import it.fabrick.academy.week4.service.IService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class TestVoid {
    @Autowired
    private IService iService;
    @Autowired
    @Qualifier(Constants.ANOTHER_SERVICE)
    private IService someSpecificService;

    @Autowired
    private List<IService> serviceList;
    @Test
    void contextLoads() {
    }
    @Test
    void shouldBeEquals() {
        Assertions.assertNotEquals(someSpecificService, iService);
    }
    @Test
    void shouldMoreThanOne(){
        Assertions.assertTrue(serviceList.size()>1,"Should be more than one");
        for (IService i :serviceList){
            System.out.println(i.getSize());
            System.out.println(i.getClass());
        }
    }
}
