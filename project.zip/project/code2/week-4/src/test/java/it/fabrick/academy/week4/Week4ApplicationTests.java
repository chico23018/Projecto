package it.fabrick.academy.week4;

import it.fabrick.academy.week4.service.IService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4ApplicationTests {
    @Autowired
    private IService iService;
    @Autowired
    private IService someSpecificService;

    @Test
    void contextLoads() {
    }


}
