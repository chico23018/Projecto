package it.fabrick.academy.week4.repository;

import org.springframework.stereotype.Service;

@Service
public class AnotherRepository implements IRepository{
}
