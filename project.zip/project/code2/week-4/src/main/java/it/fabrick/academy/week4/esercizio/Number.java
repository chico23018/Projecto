package it.fabrick.academy.week4.esercizio;

public class Number {


    public static void main(String[] args) {
        Number n = new Number();
        // somma();
        int m[] = {1, 2, 3, 4, 5};

        for (int p : n.recurse(m)) {
            System.out.print(" "+p);
        }
    }

    /*  public static int[] somma(int[] input) {
          int n = input.length;
          int[] result = {0, 0, 0, 0, 0};
  *//*
        int inisum = 0;
        int finesum = 0;*//*
        int con = 0;
    *//*    for (int i = 0, j = n - 1; i < n; j--, i++) {
           result[i] += inisum;
           result[j] += finesum;

           inisum += input[i];
           finesum += input[j];
            con++;
        }*//*
        result[0] = input[0];
        for (int i = 1; i < n - 1; i++) {
            result[i] = result[i - 1] + input[i];
        }


        result[result.length - 1] = result[result.length - 2];
        inisum = input[n - 1];


        for (int i = n - 2; i > 0; i--) {
            // input[i]+inisum;
            result[i] = result[i - 1] + inisum;
            inisum = input[i] + inisum;

        }
        result[0] = inisum;
        System.out.println();
        for (int i = 0; i < n; i++) {
            System.out.println(result[i]);
        }
        return result;
    }*/
    private int pos = 0;
    private int[] result = null;
    private int posfin;
    private int inisum = 0;
    private int finesum = 0;

    public int[] recurse(int[] input) {

        if (result == null) {
            result = new int[input.length];
            posfin = input.length - 1;
        }
        result[pos] += inisum;
        result[posfin] += finesum;
        inisum += input[pos];
        finesum += input[posfin];
        pos++;
        posfin--;
        if (pos >= input.length) {
            return result;
        } else {
            return recurse(input);
        }
    }

    public static void somma() {
        Integer m[] = {1, 2, 3, 4, 5};


        int somma = 0;
        for (int i = 0, j = m.length - 1, pos = 0; pos < m.length; ) {
            if (i == pos && j == pos) {
                System.out.print(" " + somma);
                pos++;
                somma = 0;
                j = m.length - 1;
                i = 0;
            }
            if (i < pos) {
                somma += m[i];
                i++;
            }
            if (j > pos) {
                somma += m[j];
                j--;
            }
        }


    }
}
