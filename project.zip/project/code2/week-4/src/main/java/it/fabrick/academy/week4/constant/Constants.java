package it.fabrick.academy.week4.constant;

public final class Constants {

    public final static String DEFAULT_SERVICE= "DEFAULT_SERVICE";
    public final static String ANOTHER_SERVICE= "ANOTHER_SERVICE";
    public final static String ANOTHER_REPOSITORY= "ANOTHER_REPOSITORY";

    private Constants(){

    }
}
