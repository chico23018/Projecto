package it.fabrick.academy.week4.service;

import it.fabrick.academy.week4.constant.Constants;
import it.fabrick.academy.week4.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfiguration {
    @Bean
    @Qualifier(Constants.ANOTHER_SERVICE)
    public IService anotherService(IRepository iRepository) {
        return new AnotherService(iRepository);
    }
}
