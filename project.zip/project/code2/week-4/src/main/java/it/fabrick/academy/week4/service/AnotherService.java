package it.fabrick.academy.week4.service;

import it.fabrick.academy.week4.constant.Constants;
import it.fabrick.academy.week4.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/*@Service
@Qualifier(Constants.ANOTHER_SERVICE)*/
public class AnotherService implements IService {
    private final IRepository iRepository;


    public  AnotherService(IRepository iRepository) {
        this.iRepository = iRepository;
    }

    public AnotherService(IRepository iRepository, String str) {
        this.iRepository = iRepository;
    }

    @Override
    public int getSize() {
        return 0;
    }
}
