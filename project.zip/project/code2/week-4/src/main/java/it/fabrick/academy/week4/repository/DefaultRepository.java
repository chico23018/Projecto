package it.fabrick.academy.week4.repository;

import it.fabrick.academy.week4.service.IService;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class DefaultRepository implements IRepository {
}
