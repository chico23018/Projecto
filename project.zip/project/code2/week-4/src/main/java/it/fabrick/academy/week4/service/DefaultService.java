package it.fabrick.academy.week4.service;

import it.fabrick.academy.week4.repository.IRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
//@Component
@Primary
public class DefaultService implements IService {
    private final List<IRepository> iRepositoryLis;

    public DefaultService(List<IRepository> iRepositoryLis) {
        this.iRepositoryLis = iRepositoryLis;
    }

    @Override
    public int getSize() {
        return iRepositoryLis.size();
    }
}
