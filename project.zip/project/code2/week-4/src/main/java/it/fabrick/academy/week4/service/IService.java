package it.fabrick.academy.week4.service;

public interface IService {
    int getSize();
}
