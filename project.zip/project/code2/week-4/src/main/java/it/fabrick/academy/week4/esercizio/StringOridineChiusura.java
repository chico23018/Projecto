package it.fabrick.academy.week4.esercizio;

public class StringOridineChiusura {
    public String[] veri(){
        String[] i = {"[","}","(","{",")","[","}"};
        return null;
    }
}
