package it.fabrick.academy.week4.repository;

public interface IRepository {
}
