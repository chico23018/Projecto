package com.example.utente.dto;

import com.example.utente.enumClass.TypeUser;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
public class BookingResponseDto {
    private String Uuid;
    private LocalDate day;
    private String description;
    private TypeUser typeContact;
    private String Contact;
}
