package com.example.utente.service;

import com.example.utente.dto.BookingDto;
import com.example.utente.dto.BookingRequestDto;
import com.example.utente.dto.ErrorDto;
import com.example.utente.enumClass.ErrorCode;
import com.example.utente.errorClass.BadRequestException;
import com.example.utente.errorClass.DataNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilderFactory;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@Service
@AllArgsConstructor
@Slf4j
public class BookingService {
    private final RestTemplate template;
    private final ObjectMapper objectMapper;


    public List<BookingDto> readBooking(String uuidIdentity) {

        HttpEntity<Void> httpEntity = new HttpEntity<>(null);

        UriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory("http://localhost:8080/v1.0/booking/search");
        URI uri = uriBuilderFactory.builder().queryParam("uuidIdentity", uuidIdentity).build();

        try {
            return this.template.exchange(uri, HttpMethod.POST
                    , httpEntity, new ParameterizedTypeReference<List<BookingDto>>() {
                    }).getBody();
        } catch (RestClientResponseException e) {
            try {
                ErrorDto errorDto = objectMapper.readValue(e.getResponseBodyAsString(), ErrorDto.class);
                if ("DATA_NOT_VALID".equals(errorDto.getErrorCode())) {
                    log.error(errorDto.getErrorCode()+" 55");
                    throw new BadRequestException(errorDto.getErrorCode(),ErrorCode.DATA_NOT_VALID);
                } else if (" DATA_NOT_FOUND".equals(errorDto.getErrorCode())) {
                    log.error(errorDto.getErrorCode()+" 58");
                    throw new DataNotFoundException(errorDto.getErrorCode());
                } else {
                    log.error(errorDto.getErrorCode()+" 61");
                    throw new BadRequestException(errorDto.getErrorMessage(), Enum.valueOf(ErrorCode.class, errorDto.getErrorCode()));
                }
            } catch (JsonProcessingException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    public BookingDto createBooking(BookingDto bookingDto) {
        HttpEntity<BookingDto> httpEntity = new HttpEntity<>(bookingDto);
        return this.template.exchange("http://localhost:8080/v1.0/booking/"
                        , HttpMethod.POST
                        , httpEntity
                        , BookingDto.class)
                .getBody();
    }

    public BookingDto updateBooking(String userID, BookingDto bookingDto) {
        HttpEntity<BookingDto> httpEntity = new HttpEntity<>(bookingDto);

        return this.template.exchange("http://localhost:8080/v1.0/booking/" + userID
                        , HttpMethod.PUT
                        , httpEntity
                        , BookingDto.class)
                .getBody();
    }

    public void deleteBooking(String uuidBooking) {
        HttpEntity<Void> httpEntity = new HttpEntity<>(null);
        try {
            this.template.exchange("http://localhost:8080/v1.0/booking/" + uuidBooking
                            , HttpMethod.DELETE
                            , httpEntity
                            , BookingDto.class)
                    .getBody();
        } catch (RestClientResponseException e) {
            try {
                ErrorDto errorDto = objectMapper.readValue(e.getResponseBodyAsString(), ErrorDto.class);
                if ("DATA_NOT_VALID".equals(errorDto.getErrorCode())) {
                    throw new DataNotFoundException(errorDto.getErrorCode());
                } else if (" DATA_NOT_FOUND".equals(errorDto.getErrorCode())) {
                    throw new DataNotFoundException(errorDto.getErrorCode());
                } else {
                    throw new BadRequestException(errorDto.getErrorMessage(), Enum.valueOf(ErrorCode.class, errorDto.getErrorCode()));
                }
            } catch (JsonProcessingException ex) {
                throw new RuntimeException(ex);
            }
        }

    }

    public void deleteBookingAll(String uuidIdentity) {
        HttpEntity<Void> httpEntity = new HttpEntity<>(null);
        try {
            this.template.exchange("http://localhost:8080/v1.0/booking/deleteAll/" + uuidIdentity
                            , HttpMethod.DELETE
                            , httpEntity
                            , BookingDto.class)
                    .getBody();
        } catch (RestClientResponseException e) {
            try {
                ErrorDto errorDto = objectMapper.readValue(e.getResponseBodyAsString(), ErrorDto.class);
                if ("DATA_NOT_VALID".equals(errorDto.getErrorCode())) {
                    throw new DataNotFoundException(errorDto.getErrorCode());
                } else if (" DATA_NOT_FOUND".equals(errorDto.getErrorCode())) {
                    throw new DataNotFoundException(errorDto.getErrorCode());
                } else {
                    throw new BadRequestException(errorDto.getErrorMessage(), Enum.valueOf(ErrorCode.class, errorDto.getErrorCode()));
                }
            } catch (JsonProcessingException ex) {
                throw new RuntimeException(ex);
            }
        }

    }
}

