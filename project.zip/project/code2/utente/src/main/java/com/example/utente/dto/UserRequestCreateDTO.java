package com.example.utente.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class UserRequestCreateDTO {
    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String name;
    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String surname;
}
