package com.example.utente.enumClass;

public enum TypeUser {
PHONE, CELL,EMAIL

}
