package com.example.utente.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Entity(name = "USER_UTENTE")
public class UserEntity {
    @Id
   /* @GeneratedValue(generator = "uuid-hibernate-generator")
    @GenericGenerator(name = "uuid-hibernate-generator", strategy = "org.hibernate.id.UUIDGenerator")*/
    @Column(name = "uuid")
    private String userId;
    @Column(name = "name")
    private String name;
    @Column(name = "surname")
    private String surname;
    @Column(name = "userIdentity")
    private String userIdentity;

    @PrePersist
    public void generatorUuid() {
        if(getUserId()==null){
           setUserId(UUID.randomUUID().toString());
        }
    }
}
