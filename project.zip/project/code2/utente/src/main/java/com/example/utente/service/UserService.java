package com.example.utente.service;

import com.example.utente.dto.BookingDto;
import com.example.utente.entity.UserEntity;
import com.example.utente.enumClass.ErrorCode;
import com.example.utente.errorClass.BadRequestException;
import com.example.utente.errorClass.DataNotFoundException;
import com.example.utente.mapper.IBookingMapper;
import com.example.utente.mapper.IUserMapper;
import com.example.utente.model.BookingModel;
import com.example.utente.model.UserModel;
import com.example.utente.repository.IUserRepository;
import com.example.utente.utily.UtilUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserService {
    private final IUserRepository userRepository;
    private final IUserMapper iUserMapper;
    private final UtilUser utilUser = new UtilUser();
    private final BookingService bookingService;
    private final IBookingMapper bookingMapper;

    public UserService(IUserRepository userRepository, IUserMapper iUserMapper, BookingService bookingService, IBookingMapper bookingMapper) {
        this.userRepository = userRepository;
        this.iUserMapper = iUserMapper;
        this.bookingService = bookingService;
        this.bookingMapper = bookingMapper;

        List<UserEntity> userEntities = utilUser.getList();
        if (userEntities != null && !userEntities.isEmpty()) {
            this.userRepository.saveAll(userEntities);
        }

    }

    public List<UserModel> readUser(String uuid) {
        List<UserModel> userModel = null;
        try {
            if (uuid != null) {
                UserEntity userEntity = userRepository.findByUserId(uuid);
                UserModel model = iUserMapper.ModelFromEntity(userEntity);
                model.setList(bookingService.readBooking(userEntity.getUserIdentity())
                        .stream().map(bookingMapper::modelFromDto)
                        .collect(Collectors.toList()));

                userModel = List.of(model);
            } else {
                userModel = userRepository.findAll().stream()
                        .map(iUserMapper::ModelFromEntity)
                        .collect(Collectors.toList());
            }
        } catch (Throwable e) {

            throw new DataNotFoundException(String.format("UserId '%s' not found ",uuid));
        }

        return userModel;
    }

    public UserModel createUser(UserModel userModel) {
        UserEntity userEntity = iUserMapper.entityFromModel(userModel);
        userEntity.setUserIdentity(UUID.randomUUID().toString());
        UserModel userModel1 = iUserMapper.ModelFromEntity(userRepository.save(userEntity));
        saveJSon();
        return userModel1;

    }

    @Transactional
    public UserModel updateUser(String uuid, UserModel userModel) {
        ValidationService.doValidateUuid(uuid);
        UserEntity userEntity = iUserMapper.entityFromModel(userModel);
        int howMany = 0;
        try {
            if (userEntity.getName() != null && !userEntity.getName().isEmpty() &&
                    userEntity.getSurname() != null && !userEntity.getSurname().isEmpty()) {
                howMany = userRepository.updateByUserId(uuid, userEntity.getName(), userEntity.getSurname());

            } else if (userEntity.getName() != null && !userEntity.getName().isEmpty()) {
                howMany = userRepository.updateByUserIdName(uuid, userEntity.getName());
            } else if (userEntity.getSurname() != null && !userEntity.getSurname().isEmpty()) {
                howMany = userRepository.updateByUserIdSurname(uuid, userEntity.getSurname());
            }
        } catch (Throwable e) {
            throw generateException(e);
        }
        if (howMany == 0)
            throw generateDataNotFoundException(uuid);
        UserModel userModel2 = iUserMapper.ModelFromEntity(userRepository.findById(uuid).get());
        saveJSon();
        return userModel2;

    }

    @Transactional
    public void deleteUser(String uuid) {
        ValidationService.doValidateUuid(uuid);
        UserEntity userEntity = userRepository.findByUserId(uuid);

        int howMany = 0;
        try {
            howMany = userRepository.deleteByUserId(uuid);
        } catch (Throwable e) {
            throw generateException(e);
        }
        if (howMany == 0)
            throw generateDataNotFoundException(uuid);

        bookingService.deleteBookingAll(userEntity.getUserIdentity());
        saveJSon();
    }

    public BookingModel createBooking(String uuidUser, BookingModel bookingModel) {
        //ValidationService.doValidateUuid(uuidUser);
        BookingDto dto = bookingMapper.dtoFromModel(bookingModel);

        UserEntity userEntity = userRepository.findByUserId(uuidUser);

        dto.setUserIdentity(userEntity.getUserIdentity());

        return bookingMapper.modelFromDto(bookingService.createBooking(dto));
    }

    public BookingModel updateBooking(String uuid, BookingModel bookingModel) {

        BookingDto bookingDto = bookingService.updateBooking(uuid, bookingMapper.dtoFromModel(bookingModel));
        return bookingMapper.modelFromDto(bookingDto);
    }

    public void deleteBooking(String uuidBooking) {
        bookingService.deleteBooking(uuidBooking);
    }

    public void saveJSon() {
        utilUser.write(userRepository.findAll());
    }

    private DataNotFoundException generateDataNotFoundException(String uuid) {
        return new DataNotFoundException(String.format("No User found for uuid '%s'", uuid));
    }

    private BadRequestException generateException(Throwable e) {
        return new BadRequestException("Error internal ", e.getCause(), ErrorCode.INTERNAL_ERROR);
    }

}
