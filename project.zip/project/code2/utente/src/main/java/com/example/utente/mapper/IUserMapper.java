package com.example.utente.mapper;

import com.example.utente.dto.UserRequestCreateDTO;
import com.example.utente.dto.UserRequestDTO;
import com.example.utente.dto.UserResponseDto;
import com.example.utente.entity.UserEntity;
import com.example.utente.model.UserModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface IUserMapper {
    UserEntity entityFromModel(UserModel userModel);
    UserModel ModelFromEntity(UserEntity userEntityModel);

    UserModel modelFromResponse(UserResponseDto userResponseDto);
    UserResponseDto responseFromModel(UserModel userModel);


    UserModel modelFromRequest(UserRequestDTO userRequestDTO);
    UserRequestDTO RequestFromModel(UserModel userModel);

    UserModel modelFromRequestCreate(UserRequestCreateDTO userRequestDTO);
    UserRequestCreateDTO RequestFromModelCreate(UserModel userModel);
}
