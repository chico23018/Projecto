package com.example.utente.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
public class BookingDto {
    private String Uuid;
    private LocalDate day;
    private String description;
    private String typeContact;
    private String Contact;
    private String userIdentity;
}
