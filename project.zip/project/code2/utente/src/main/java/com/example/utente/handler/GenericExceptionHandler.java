package com.example.utente.handler;

import com.example.utente.enumClass.ErrorCode;
import com.example.utente.errorClass.BadRequestException;
import com.example.utente.errorClass.DataNotFoundException;
import com.example.utente.errorClass.ErrorResponseDto;
import com.example.utente.errorClass.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
public class GenericExceptionHandler {

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponseDto> handleBadRequestException(BadRequestException badRequestException) {
        log.error("Bad request exception", badRequestException);
        return ResponseEntity.badRequest().body(ErrorResponseDto.builder()
                .errorCode(badRequestException.getErrorCode())
                .errorMessage(badRequestException.getMessage())
                .build());
    }
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponseDto> handleValidationException(ValidationException validationException) {
        log.error("Validation exception", validationException);
        List<String> messages = validationException.getConstraintViolations().stream()
                .map(cv -> cv.getPropertyPath().toString() + ": " + cv.getMessage())
                .collect(Collectors.toList());
        return ResponseEntity.badRequest().body(ErrorResponseDto.builder()
                .errorCode(ErrorCode.DATA_NOT_VALID)
                .errorMessage(String.join(", ", messages))
                .build());
    }

    @ExceptionHandler(DataNotFoundException.class)
    public ResponseEntity<ErrorResponseDto> handleDataNotFoundException(DataNotFoundException dataNotFoundException) {
        log.error("Data not found exception", dataNotFoundException);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ErrorResponseDto.builder()
                .errorCode(ErrorCode.DATA_NOT_FOUND)
                .errorMessage(dataNotFoundException.getMessage())
                .build());
    }
}
