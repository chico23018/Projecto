package com.example.utente.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
public class BookingModel {
    private String Uuid;
    private LocalDate day;
    private String description;
    private String typeContact;
    private String Contact;
}
