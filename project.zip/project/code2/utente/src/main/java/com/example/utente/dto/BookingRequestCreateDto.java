package com.example.utente.dto;

import com.example.utente.enumClass.TypeUser;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@Getter
@Setter
public class BookingRequestCreateDto {


    private LocalDate day;
    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String description;

    private TypeUser typeContact;

    @NotBlank(message = "Should not be blank")
    private String Contact;
}
