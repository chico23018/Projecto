package com.example.utente.repository;

import com.example.utente.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUserRepository extends JpaRepository<UserEntity, String> {
    UserEntity findByUserId(String userId);

    int deleteByUserId(String userId);

    @Modifying
    @Query("update USER_UTENTE u set u.name = :name , u.surname = :surname where u.userId = :userId")
    int updateByUserId(String userId,String name,String surname);
    @Modifying
    @Query("update USER_UTENTE u set u.name = :name  where u.userId = :userId")
    int updateByUserIdName(String userId,String name);
    @Modifying
    @Query("update USER_UTENTE u set  u.surname = :surname where u.userId = :userId")
    int updateByUserIdSurname(String userId,String surname);
}
