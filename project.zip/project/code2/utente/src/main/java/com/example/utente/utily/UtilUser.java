package com.example.utente.utily;

import com.example.utente.entity.UserEntity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class UtilUser {
    private  ObjectMapper objectMapper = new ObjectMapper();
    private  File file;
    private  List<UserEntity> list;

    public UtilUser() {
        objectMapper.registerModule(new JavaTimeModule());
        file = new File("User.json");
        if (file.exists()) {
            try {
                list = objectMapper.readValue(file, new TypeReference<List<UserEntity>>() {
                });
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            list = new LinkedList<>();
        }


    }

    public  List<UserEntity> getList() {
        if (list == null)
            list = new LinkedList<>();

        return list;
    }

    public  void write(List<UserEntity> UserEntity) {


        try {
            objectMapper.writeValue(file, UserEntity);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
