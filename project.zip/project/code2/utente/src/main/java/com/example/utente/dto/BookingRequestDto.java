package com.example.utente.dto;

import com.example.utente.enumClass.TypeUser;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@Getter
@Setter
public class BookingRequestDto{
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private LocalDate day;
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String description;
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private TypeUser typeContact;
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String Contact;
}
