package com.example.utente.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import java.util.List;

@Getter
@Setter
public class UserModel {
    private String userId;

    private String name;

    private String surname;
    private List<BookingModel> list;

}
