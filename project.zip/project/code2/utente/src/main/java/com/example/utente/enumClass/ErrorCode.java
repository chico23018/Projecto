package com.example.utente.enumClass;

public enum ErrorCode {

    INTERNAL_ERROR, DATA_NOT_VALID, DATA_NOT_FOUND
}
