package com.example.utente.mapper;

import com.example.utente.dto.BookingDto;
import com.example.utente.dto.BookingRequestCreateDto;
import com.example.utente.dto.BookingRequestDto;
import com.example.utente.dto.BookingResponseDto;
import com.example.utente.model.BookingModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface IBookingMapper {
    BookingDto dtoFromModel(BookingModel bookingModel);

    BookingModel modelFromDto(BookingDto bookingDto);

    BookingModel modelFromResponse(BookingResponseDto bookingResponseDto);

    BookingResponseDto responseFromModel(BookingModel bookingDto);

    BookingModel modelFromRequest(BookingRequestDto bookingRequestDto);
    BookingRequestDto requestFromModel(BookingModel bookingDto);

    BookingModel modelFromRequestCrate(BookingRequestCreateDto bookingRequestDto);

    BookingRequestCreateDto requestFromModelCrate(BookingModel bookingDto);
}
