package com.example.utente.controller;

import com.example.utente.dto.*;
import com.example.utente.errorClass.DataNotFoundException;
import com.example.utente.mapper.IBookingMapper;
import com.example.utente.mapper.IUserMapper;
import com.example.utente.model.BookingModel;
import com.example.utente.model.UserModel;
import com.example.utente.service.UserService;
import com.example.utente.service.ValidationService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("v1.0/users")
@AllArgsConstructor
public class UserController {
    private final ValidationService validationService;

    private final UserService userService;
    private final IUserMapper iUserMapper;
    private final IBookingMapper iBookingMapperMapper;

    @GetMapping
    public ResponseEntity<List<UserResponseDto>> readUser(@RequestParam(value = "uuidUser", required = false) String uuid) {
        List<UserModel> userModel = userService.readUser(uuid);
        return ResponseEntity.ok(userModel.stream()
                .map(iUserMapper::responseFromModel)
                .collect(Collectors.toList()));
    }

    @PostMapping
    public ResponseEntity<UserResponseDto> CreateUser(@RequestBody UserRequestCreateDTO userRequestCreateDTOtDTO) {
        validationService.doValidate(userRequestCreateDTOtDTO);
        UserModel userModel = userService.createUser(iUserMapper.modelFromRequestCreate(userRequestCreateDTOtDTO));
        return ResponseEntity.created(URI.create("v1.0/users/" + userModel.getUserId())).body(iUserMapper.responseFromModel(userModel));
    }

    @PutMapping("/{userId}")
    public ResponseEntity<UserResponseDto> updateUser(@PathVariable("userId") String userid,
                                                      @RequestBody UserRequestDTO
                                                              userRequestDTO) {
        validationService.doValidate(userRequestDTO);
        UserModel userModel = userService.updateUser(userid, iUserMapper.modelFromRequest(userRequestDTO));

        return ResponseEntity.ok(iUserMapper.responseFromModel(userModel));

    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable("userId") String userid) {

        userService.deleteUser(userid);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{userId}/booking")
    public ResponseEntity<BookingResponseDto> createBooking(@PathVariable("userId") String uuid,
                                                            @RequestBody BookingRequestCreateDto bookingRequestCreateDto) {
        validationService.doValidate(bookingRequestCreateDto);
        BookingModel model = iBookingMapperMapper.modelFromRequestCrate(bookingRequestCreateDto);
        BookingModel model1 = userService.createBooking(uuid, model);

        BookingResponseDto responseDto = iBookingMapperMapper.responseFromModel(model1);
        return ResponseEntity.created(URI.create("v1.0/users/" + uuid + "booking" + model.getUuid()))
                .body(responseDto);
    }

    @PutMapping("/{userId}/booking/{uuidBooking}")
    public ResponseEntity<BookingResponseDto> updateBooking(@PathVariable("userId") String uuid,
                                                            @PathVariable("uuidBooking") String uuidBooking,
                                                            @RequestBody BookingRequestDto bookingRequestDto) {
        validationService.doValidate(uuid);
        validationService.doValidate(uuidBooking);
        if (userService.readUser(uuid).isEmpty())
            throw new DataNotFoundException(String.format("No User found for uuid '%s'", uuid));

        BookingModel model = userService.updateBooking(uuidBooking, iBookingMapperMapper.modelFromRequest(bookingRequestDto));
        return ResponseEntity.ok(iBookingMapperMapper.responseFromModel(model));
    }

    @DeleteMapping("/{userId}/booking/{uuidBooking}")
    public ResponseEntity<Void> deleteBooking(@PathVariable("userId") String uuid,
                                              @PathVariable("uuidBooking") String uuidBooking) {
        validationService.doValidate(uuid);
        validationService.doValidate(uuidBooking);
        if (userService.readUser(uuid).isEmpty())
            throw new DataNotFoundException(String.format("No User found for uuid '%s'", uuid));
        userService.deleteBooking(uuidBooking);
        return ResponseEntity.noContent().build();
    }


}
