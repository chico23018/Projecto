package com.example.utente.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Pattern;

@Getter
@Setter
public class UserRequestDTO {
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String name;
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String surname;
}
