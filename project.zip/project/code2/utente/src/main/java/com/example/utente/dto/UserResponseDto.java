package com.example.utente.dto;

import com.example.utente.model.BookingModel;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class UserResponseDto {
    private String userId;

    private String name;

    private String surname;
    private List<BookingResponseDto> list;
}
