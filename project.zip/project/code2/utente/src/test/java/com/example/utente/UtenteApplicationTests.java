package com.example.utente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
