package com.example.demo.constant;

public final class Constant {

    public static final String ANOTHER = "another";

    private Constant() {

    }
}
