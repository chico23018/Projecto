package com.example.demo;

public class EasyRepository implements ISampleRepository {
}
