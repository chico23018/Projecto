package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SampleContainer {

    private final List<ISampleRepository> iSampleRepositories;

    public SampleContainer(List<ISampleRepository> sampleRepositories) {
        this.iSampleRepositories = sampleRepositories;
    }

    public List<ISampleRepository> getiSampleRepositories() {
        return iSampleRepositories;
    }
}
