package com.example.demo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class QualifiedService {

    private final ISampleRepository iSampleRepository;

    public QualifiedService(@Qualifier(value = Constant.REPOSITORY_WITH_QUALIFIER)
                            ISampleRepository iSampleRepository) {
        this.iSampleRepository = iSampleRepository;
    }

    public String getRepositoryType() {
        return this.iSampleRepository.getClass().toString();
    }
}
