package com.example.demo;

public class SampleRepository implements ISampleRepository {
}
