package com.example.demo;

public final class Constant {

    private Constant() {

    }

    public static final String REPOSITORY_WITH_QUALIFIER = "REPOSITORY_WITH_QUALIFIER";
    public static final String REPOSITORY_WITH_PROFILE = "REPOSITORY_WITH_PROFILE";

    public static final String ENV_STAGING = "staging";
    public static final String ENV_DEV = "dev";
    public static final String ENV_DEFAULT = "default";
}
