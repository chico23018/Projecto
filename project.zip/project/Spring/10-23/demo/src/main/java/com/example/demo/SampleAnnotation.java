package com.example.demo;

public @interface SampleAnnotation {

    String name() default "";
}
