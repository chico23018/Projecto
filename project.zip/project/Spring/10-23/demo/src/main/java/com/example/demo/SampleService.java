package com.example.demo;

public class SampleService {

    private final ISampleRepository iSampleRepository;

    public SampleService(ISampleRepository iSampleRepository) {
        this.iSampleRepository = iSampleRepository;
    }

    public String getRepositoryType() {
        return this.iSampleRepository.getClass().toString();
    }
}
