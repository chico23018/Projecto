package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private SampleService sampleService;
	@Autowired
	private QualifiedService qualifiedService;
	@Autowired
	private SampleContainer sampleContainer;

	@Test
	void contextLoads() {
	}

	@Test
	void shouldLoadService() {
		Assertions.assertNotNull(this.sampleService);
	}

	@Test
	void shouldLoadEasyRepository() {
		String expected = EasyRepository.class.toString();
		Assertions.assertEquals(expected, this.sampleService.getRepositoryType());
	}

	@Test
	void shouldNotLoadSampleRepository() {
		String notExpected = SampleRepository.class.toString();
		Assertions.assertNotEquals(notExpected, this.sampleService.getRepositoryType());
	}

	@Test
	void shouldLoadSampleRepository() {
		String expected = SampleRepository.class.toString();
		Assertions.assertEquals(expected, this.qualifiedService.getRepositoryType());
	}

	@Test
	void shouldLoadMoreThanOneRepository() {
		int size = this.sampleContainer.getiSampleRepositories().size();
		Assertions.assertTrue(size > 1, "Should contains more than one repository");
	}
}
