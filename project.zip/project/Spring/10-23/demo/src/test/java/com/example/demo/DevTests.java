package com.example.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(Constant.ENV_DEV)
class DevTests {

    @Autowired
    @Qualifier(Constant.REPOSITORY_WITH_PROFILE)
    private SampleService sampleService;

    @Test
    void shouldLoadSampleRepository() {
        String expected = SampleRepository.class.toString();
        Assertions.assertEquals(expected, this.sampleService.getRepositoryType());
    }
}
