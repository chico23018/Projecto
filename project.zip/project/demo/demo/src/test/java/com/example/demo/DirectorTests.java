package com.example.demo;

import com.example.demo.dto.*;
import com.example.demo.enumeration.ErrorCode;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;
import java.util.UUID;

@SpringBootTest
@AutoConfigureMockMvc
class DirectorTests {

  /*  @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @Test
    void shouldReadAllDirectors() throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(2)))
                .andReturn();
        String content = mvcResult.getResponse().getContentAsString();
        List<DirectorResponseDto> directorResponseDtos = objectMapper.readValue(content, new TypeReference<>() {});
        directorResponseDtos.forEach(directorResponseDto ->
                Assertions.assertTrue(directorResponseDto.getMovies().size() > 1));
    }

    @Test
    void shouldReadDirectorWithName() throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors?name=pippolippo"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(1)))
                .andReturn();
        String content = mvcResult.getResponse().getContentAsString();
        List<DirectorResponseDto> directorResponseDtos = objectMapper.readValue(content, new TypeReference<>() {});
        directorResponseDtos.forEach(directorResponseDto ->
                Assertions.assertTrue(directorResponseDto.getMovies().size() > 1));
    }

    @Test
    void shouldReturnNoDirector() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors?name=NOTHING"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.is(0)));
    }

    @Test
    void shouldCreateDirector() throws Exception {
        String name = "New";
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name(name).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is(name)))
                .andExpect(MockMvcResultMatchers.header().exists("location"));
    }

    @Test
    void shouldGenerateBadRequestForInvalidDataWhenCreate() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("--").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForNameAlreadyPresent() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("pippolippo").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldUpdateDirector() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String name = "New";
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name(name).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid().toString())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name", Matchers.is(name)));
    }

    @Test
    void shouldGenerateBadRequestForInvalidDataWhenUpdate() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("--").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid().toString())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidUuidWhenUpdate() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("New").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundWhenUpdate() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("New").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+ UUID.randomUUID())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldDeleteDirector() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+directorResponseDto.getUuid().toString()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }

    @Test
    void shouldGenerateBadRequestForInvalidUuidWhenDelete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/1"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundWhenDelete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+UUID.randomUUID()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldReadAllMovies() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()", Matchers.greaterThan(1)));
    }

    @Test
    void shouldGenerateBadRequestForInvalidUuidWhenReadMovies() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors/1/movies"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundWhenReadMovies() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors/"+UUID.randomUUID()+"/movies"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldCreateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String title = "Title";
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(CreateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title", Matchers.is(title)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.durationInMinutes", Matchers.is(durationInMinutes)))
                .andExpect(MockMvcResultMatchers.header().exists("location"));
    }

    @Test
    void shouldGenerateBadRequestForMissingTitleWhenCreateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(CreateMovieRequestDto.builder().durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForMissingDurationInMinutesWhenCreateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String title = "Title";
        String content = objectMapper.writeValueAsString(CreateMovieRequestDto.builder().title(title).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidTitleWhenCreateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String title = "--";
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(CreateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidDurationInMinutesWhenCreateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String title = "Title";
        int durationInMinutes = -1;
        String content = objectMapper.writeValueAsString(CreateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundWhenCreateMovie() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("pippolippo").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/"+UUID.randomUUID()+"/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidUuidWhenCreateMovie() throws Exception {
        String content = objectMapper.writeValueAsString(DirectorRequestDto.builder().name("pippolippo").build());
        mockMvc.perform(MockMvcRequestBuilders.post("/v1.0/directors/1/movies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }



    @Test
    void shouldUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        String title = "Title";
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title", Matchers.is(movieResponseDto.getTitle())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.durationInMinutes", Matchers.is(movieResponseDto.getDurationInMinutes())));
    }

    @Test
    void shouldUpdateMovieOnlyWithTitle() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        String title = "Title";
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title(title).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title", Matchers.is(movieResponseDto.getTitle())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.durationInMinutes", Matchers.is(movieResponseDto.getDurationInMinutes())));
    }

    @Test
    void shouldUpdateMovieOnlyWithDurationInMinutes() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title", Matchers.is(movieResponseDto.getTitle())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.durationInMinutes", Matchers.is(movieResponseDto.getDurationInMinutes())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidTitleWhenUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        String title = "--";
        int durationInMinutes = 120;
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidDurationInMinutesWhenUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        String title = "Title";
        int durationInMinutes = -1;
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title(title)
                .durationInMinutes(durationInMinutes).build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForNoDataWhenUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        String content = objectMapper.writeValueAsString(new UpdateMovieRequestDto());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidDirectorUuidWhenUpdateMovie() throws Exception {
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title("Title").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/1/movies/"+UUID.randomUUID())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidMovieUuidWhenUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title("Title").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundForDirectorWhenUpdateMovie() throws Exception {
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title("Title").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+ UUID.randomUUID()+"/movies/"+UUID.randomUUID())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldGenerateNotFoundForMovieWhenUpdateMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        String content = objectMapper.writeValueAsString(UpdateMovieRequestDto.builder().title("Title").build());
        mockMvc.perform(MockMvcRequestBuilders.put("/v1.0/directors/"+ directorResponseDto.getUuid()+"/movies/"+UUID.randomUUID())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(content))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldDeleteMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        MovieResponseDto movieResponseDto = directorResponseDto.getMovies().get(0);
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+directorResponseDto.getUuid()
                                +"/movies/"+movieResponseDto.getUuid()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }

    @Test
    void shouldGenerateBadRequestForInvalidDirectorUuidWhenDeleteMovie() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/1/movies/"+UUID.randomUUID()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateBadRequestForInvalidMovieUuidWhenDeleteMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+directorResponseDto.getUuid()+"/movies/1"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_VALID.toString())));
    }

    @Test
    void shouldGenerateNotFoundForDirectorWhenDeleteMovie() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+ UUID.randomUUID()+"/movies/"+UUID.randomUUID()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    @Test
    void shouldGenerateNotFoundForMovieWhenDeleteMovie() throws Exception {
        DirectorResponseDto directorResponseDto = getDirectorAtRandom();
        mockMvc.perform(MockMvcRequestBuilders.delete("/v1.0/directors/"+ directorResponseDto.getUuid()+"/movies/"+UUID.randomUUID()))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode", Matchers.is(ErrorCode.DATA_NOT_FOUND.toString())));
    }

    private DirectorResponseDto getDirectorAtRandom() throws Exception {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1.0/directors?name=pippolippo")).andReturn();
        String directors = mvcResult.getResponse().getContentAsString();
        List<DirectorResponseDto> directorResponseDtos = objectMapper.readValue(directors, new TypeReference<>() {});
        return directorResponseDtos.get(0);
    }*/
}
