package com.example.demo.mapper;

import com.example.demo.dto.DirectorRequestDto;
import com.example.demo.dto.DirectorResponseDto;
import com.example.demo.dto.SearchDirectorRequestDto;
import com.example.demo.entity.DirectorEntity;
import com.example.demo.model.DirectorModel;
import com.example.demo.model.SearchDirectorModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface SearchDirectorMapper {

    SearchDirectorRequestDto responseFromModel(SearchDirectorModel directorModel);

    @Mapping(source = "birthDateFrom",target = "fromBirth")
    @Mapping(source = "birthDateTo",target = "toBirth")
    @Mapping(conditionExpression = "java(directorRequestDto.getExactMatch())", target="name", source="name", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(conditionExpression = "java(!directorRequestDto.getExactMatch())", target="nameLike", source="name", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    SearchDirectorModel modelFromRequest(SearchDirectorRequestDto directorRequestDto);
}
