package com.example.demo.repository;

import com.example.demo.entity.AwardEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DatabaseAwardRepository
        extends JpaRepository<AwardEntity, String> {
    List<AwardEntity> findByDescriptionLike(String likePattern);

}
