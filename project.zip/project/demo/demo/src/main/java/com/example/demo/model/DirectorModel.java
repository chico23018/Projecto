package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
public class DirectorModel {

    private UUID uuid;
    private String name;
    private LocalDate birthDate;
    private List<MovieModel> movies;
}
