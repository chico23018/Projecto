package com.example.demo.service;

import com.example.demo.entity.MovieEntity;
import com.example.demo.enumeration.ErrorCode;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.mapper.MovieMapper;
import com.example.demo.model.MovieModel;
import com.example.demo.repository.MovieRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class MovieService {

    private final MovieRepository movieRepository;

    private final MovieMapper movieMapper;

    public MovieModel readMovie(String directorUuid, String movieUuid) {
        ValidationService.doValidateUuid(directorUuid);
        ValidationService.doValidateUuid(movieUuid);
        return Optional.ofNullable(movieRepository.findByMovieUuidAndDirectorUuid(movieUuid, directorUuid))
                .map(movieMapper::modelFromEntity)
                .orElseThrow(() -> generateDataNotFoundException(movieUuid));
    }

    public List<MovieModel> readMovies(String directorUuid) {
        ValidationService.doValidateUuid(directorUuid);

        return this.movieRepository.findByDirectorUuid(directorUuid).stream()
                .map(movieMapper::modelFromEntity)
                .collect(Collectors.toList());
    }

    public MovieModel createMovie(String directorUuid, MovieModel movieModel) {
        ValidationService.doValidateUuid(directorUuid);
        MovieEntity movieEntity = movieMapper.entityFromModel(movieModel);
    //    movieEntity.setDirectorUuid(directorUuid);
        movieRepository.save(movieEntity);
        return movieMapper.modelFromEntity(movieEntity);
    }
    @Transactional
    public MovieModel updateMovie(String directorUuid, String movieUuid, MovieModel movieModel) {
        ValidationService.doValidateUuid(directorUuid);
        ValidationService.doValidateUuid(movieUuid);
        String title = movieModel.getTitle();
        Integer durationInMinutes = movieModel.getDurationInMinutes();
        int howMany;
        if (title != null && durationInMinutes != null) {
            howMany = movieRepository.updateTitleAndDurationInMinutesByMovieUuidAndDirectorUuid(
                    movieUuid, directorUuid, title, durationInMinutes);
        } else if (title != null) {
            howMany = movieRepository.updateTitleByMovieUuidAndDirectorUuid(
                    movieUuid, directorUuid, title);
        } else if (durationInMinutes != null) {
            howMany = movieRepository.updateDurationInMinutesByMovieUuidAndDirectorUuid(
                    movieUuid, directorUuid, durationInMinutes);
        } else {
            throw new BadRequestException("Missing data to update", ErrorCode.DATA_NOT_VALID);
        }
        if (howMany == 0) {
            throw generateDataNotFoundException(movieUuid);
        }
        return readMovie(directorUuid, movieUuid);
    }
    @Transactional
    public void deleteMovie(String directorUuid, String movieUuid) {
        ValidationService.doValidateUuid(directorUuid);
        ValidationService.doValidateUuid(movieUuid);
        int howMany = movieRepository.deleteByMovieUuidAndDirectorUuid(movieUuid, directorUuid);
        if (howMany == 0) {
            throw generateDataNotFoundException(movieUuid);
        }
    }

    private DataNotFoundException generateDataNotFoundException(String uuid) {
        return new DataNotFoundException(String.format("No movie found for uuid '%s'", uuid));
    }
}
