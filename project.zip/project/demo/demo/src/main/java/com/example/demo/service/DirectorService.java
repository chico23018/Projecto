package com.example.demo.service;

import com.example.demo.dto.DirectorResponseDto;
import com.example.demo.dto.SearchDirectorRequestDto;
import com.example.demo.entity.DirectorEntity;
import com.example.demo.enumeration.ErrorCode;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.mapper.DirectorMapper;
import com.example.demo.mapper.SearchDirectorMapper;
import com.example.demo.model.DirectorModel;
import com.example.demo.model.SearchDirectorModel;
import com.example.demo.repository.DirectorRepository;
import lombok.AllArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DirectorService {
    final EntityManager entityManager;

    private final DirectorRepository directorRepository;

    private final DirectorMapper directorMapper;
    private final SearchDirectorMapper searchMapper;

    public DirectorModel readDirector(String uuid) {
        ValidationService.doValidateUuid(uuid);
        return Optional.ofNullable(directorRepository.findByUuid(uuid))
                .map(directorMapper::modelFromEntity)
                .orElseThrow(() -> generateDataNotFoundException(uuid));
    }

    public List<DirectorModel> mostAcclaimed(long movies, double vote) {
        return directorRepository.mostAcclaimed(movies, vote)
                .stream()
                .map(directorMapper::modelFromEntity)
                .collect(Collectors.toList());
    }

    public List<DirectorResponseDto> searchDirector_dto(SearchDirectorRequestDto directorModel) {
        return searchDirector(directorModel)
                .stream().map(directorMapper::responseFromModel).collect(Collectors.toList());
    }

    public List<DirectorModel> searchDirector(SearchDirectorRequestDto searchDirectorRequestDto) {
        //gestire piu' tipi di ricerca
        List<DirectorEntity> dati = null;
        SearchDirectorModel searchDirectorModel = searchMapper.modelFromRequest(searchDirectorRequestDto);

        if (searchDirectorModel.getName() != null ) {

            dati = directorRepository.findByName(searchDirectorModel.getName());

        } else if (searchDirectorModel.getNameLike() != null ) {
            dati = directorRepository.findByNameContaining( searchDirectorModel.getNameLike() );
        } else if (searchDirectorModel.getFromBirth() != null & searchDirectorModel.getToBirth() != null ) {
            dati = directorRepository.findByBirthDateBetween(LocalDate.parse(searchDirectorModel.getFromBirth())
                    , LocalDate.parse(searchDirectorModel.getToBirth()));
        } else {
            dati = directorRepository.mostAcclaimed(searchDirectorRequestDto.getNumberOfMovies(), searchDirectorRequestDto.getScore());
        }
        return dati.stream().map(directorMapper::modelFromEntity).collect(Collectors.toList());
    }
    List<DirectorEntity> complexSearch0(SearchDirectorModel searchDirectorModel) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DirectorEntity> q = cb.createQuery(DirectorEntity.class);
        Root<DirectorEntity> dir = q.from(DirectorEntity.class);

        List<Predicate> predicates = new ArrayList<>();

        if (searchDirectorModel.getName() != null) {
            if (searchDirectorModel.getExactMatch()) {
                predicates.add(cb.equal(dir.get("name"), searchDirectorModel.getName()));
            } else {
                predicates.add(cb.like(dir.get("name"), "%" + searchDirectorModel.getName() + "%"));
            }
        }

        if (searchDirectorModel.getBirthDateFrom() != null) {
            predicates.add(cb.greaterThan(dir.get("birthDate"), searchDirectorModel.getBirthDateFrom()));
        }

        if (searchDirectorModel.getBirthDateTo() != null) {
            predicates.add(cb.lessThan(dir.get("birthDate"), searchDirectorModel.getBirthDateTo()));
        }

        q.select(dir).where(predicates.toArray(new Predicate[predicates.size()]));
        return entityManager.createQuery(q).getResultList();
    }

    public List<DirectorModel> readDirectors(@Nullable String name) {
        return Optional.ofNullable(name) // Name may be null, so we are wrapping it into an optional
                // Optional<String>
                .map(directorRepository::findByName) // If I have a name filter, I'll look for directors with the given name
                // Optional<List<DirectorEntity>> / Optional EMPTY
                .orElseGet(directorRepository::findAll) // If I don't have a name filter, I'll get all the directors
                // List<DirectorEntity>
                .stream() // Stream the list of results
                .map(directorMapper::modelFromEntity) // Map each entity into a model
                .collect(Collectors.toList()); // Collect the list
    }

    public DirectorModel createDirector(DirectorModel directorModel) {
        boolean isNameAlreadyPresent = !readDirectors(directorModel.getName()).isEmpty();
        if (isNameAlreadyPresent) {
            throw new BadRequestException(String.format("Director with name '%s' already present", directorModel.getName()),
                    ErrorCode.DATA_NOT_VALID);
        }
        DirectorEntity directorEntity = directorMapper.entityFromModel(directorModel);
        directorRepository.save(directorEntity);
        DirectorModel created = directorMapper.modelFromEntity(directorEntity);
        //  created.setUuid(UUID.fromString(directorEntity.getUuid()));
        return created;
    }

    @Transactional
    public DirectorModel updateDirector(String uuid, DirectorModel directorModel) {
        ValidationService.doValidateUuid(uuid);
        int howMany = directorRepository.updateNameByUuid(directorModel.getName(), uuid);
        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
        DirectorModel updated = directorMapper.modelFromEntity(directorRepository.findByUuid(uuid));
        // TODO: this is just for mock purpose, remove when DB will be connected
        //  updated.setName(directorModel.getName());
        return updated;
    }

    @Transactional
    public void deleteDirector(String uuid) {
        ValidationService.doValidateUuid(uuid);
        int howMany = directorRepository.deleteByUuid(uuid);
        if (howMany == 0) {
            throw generateDataNotFoundException(uuid);
        }
    }


    private DataNotFoundException generateDataNotFoundException(String uuid) {
        return new DataNotFoundException(String.format("No director found for uuid '%s'", uuid));
    }
}
