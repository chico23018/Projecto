package com.example.demo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Schema(description = "The request model to create or update a single director")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DirectorRequestDto {

    @Schema(description = "The director name")
    @NotBlank(message = "Should not be blank")
    @Pattern(regexp = "[\\w\\s]+", message = "Should match the following pattern [\\w\\s]+")
    private String name;
}
