package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface DatabaseDirectorRepository
        extends JpaRepository<DirectorEntity, String>, DirectorRepository {

    // @Query(value = "SELECT * FROM USERS WHERE EMAIL_ADDRESS = ?1", nativeQuery = true)
    // @Query(value = "select * from director where DIRECTOR_UUID =?1 and DIRECTOR_NAME=?2",nativeQuery = true)
    // @Query(value = "select * from director where DIRECTOR_UUID =?1", nativeQuery = true)
    @Query(value = "select DIRECTOR_UUID,DIRECTOR_NAME, CAST(DIRECTOR_BIRTHDATE as VARCHAR) AS DIRECTOR_BIRTHDATE  from director", nativeQuery = true)
    List<Map<String, String>> searchByDirectorEntity();



    @Modifying
    @Query("update director u set u.name = :name where u.uuid =:uuid")
    int updateNameByUuid(String name, String uuid);
    /*select * from DIRECTOR  where DIRECTOR_UUID in (
select DIRECTOR_UUID
 from MOVIE
group by DIRECTOR_UUID
having count(1)>3 and avg(MOVIE_SCORE )>60
);*/
    @Query("select d from director d where d.uuid in (select m.director from movie m group by m.director having count(1)>= :movies and avg(m.score)>= :vote ) and d.name like :name")
    List<DirectorEntity> mostAcclaimed(long movies, double vote);

/*    @Query("select d from director d where d.uuid in (select m.director from movie m group by m.director having count(1)>= :movies and avg(m.score)>= :vote ) and d.name like :name")
    List<DirectorEntity> mostAcclaimed(long movies, double vote);*/
}
