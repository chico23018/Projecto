package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
public class MovieModel {

    private UUID uuid;
    private String title;
    private Integer durationInMinutes;
    private LocalDate releaseDate;
    private Integer score ;
}
