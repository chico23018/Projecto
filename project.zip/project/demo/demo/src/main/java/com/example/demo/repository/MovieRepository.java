package com.example.demo.repository;

import com.example.demo.entity.MovieEntity;

import java.util.List;
import java.util.Optional;

public interface MovieRepository {

    MovieEntity findByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);

    List<MovieEntity> findByDirectorUuid(String directorUuid);

    <S extends MovieEntity>  S save(MovieEntity movieEntity);

    int updateTitleAndDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title, int durationInMinutes);

    int updateTitleByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title);

    int updateDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, int durationInMinutes);

    int deleteByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);
    List<MovieEntity> findByTitleLike(String likePattern);
    List<MovieEntity> findByDurationInMinutesGreaterThan(Integer  duration);

    List<MovieEntity> findByDurationInMinutesBetween(Integer startAge, Integer endAge);

    Optional<MovieEntity> findById(String uuid);

    void deleteById(String uuid);
    List<MovieEntity>findAll();
}
