package com.example.demo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Schema(description = "The response model of a single director")
@Getter
@Setter
public class SearchDirectorRequestDto {

    @Schema(description = "the minimum movies to consider in our search")
    @Min(value = 0)
    private Integer numberOfMovies;

    @Schema(description = "the min average score to consider in our search")
    @Min(value = 0)
    private Integer score;

    private String name;
    private Boolean exactMatch;

    private LocalDate birthDateFrom;
    private LocalDate birthDateTo;
}
