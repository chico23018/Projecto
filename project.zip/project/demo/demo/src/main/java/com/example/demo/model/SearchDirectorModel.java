package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class SearchDirectorModel {
    String name;
    String nameLike;
    String fromBirth;
    String toBirth;
    Integer minMovies;
    Integer maxMovies;
    Double avgRanking;


    private Boolean exactMatch;

    private LocalDate birthDateFrom;
    private LocalDate birthDateTo;
}