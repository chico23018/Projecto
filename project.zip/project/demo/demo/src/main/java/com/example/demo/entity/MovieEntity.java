package com.example.demo.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString(exclude = "director")
@Entity(name = "movie")
public class MovieEntity {
    public static String uuid_prefix="MV#" ;
    @Id
    @Column(name = "MOVIE_UUID",nullable = false)
    @GeneratedValue(
            strategy=GenerationType.SEQUENCE,
            generator="movieG")
    @GenericGenerator(
            name="movieG",
            strategy="com.example.demo.generator.CustomUUID",
            parameters = {
                    @org.hibernate.annotations.Parameter(
                            name = com.example.demo.generator.CustomUUID.UUID_PREFIX,
                            value = "MV"
                    )
            }
    )
   /* @GeneratedValue(
            strategy=GenerationType.SEQUENCE,
            generator="movieG")
    @GenericGenerator(
            name="movieG",
            strategy="com.example.demo.generator.CustomUUID"
    )*/
    private String uuid;
// @Culumn fa referensa alla db
    @Column(name = "movie_title",nullable = false)
    private String title;

    @Column(name = "MOVIE_DURATION_IN_MINUTES",nullable = false)
    private int durationInMinutes;

    @Column(name="RELEASE_DATE",nullable = false)
    private LocalDate releaseDate;

    @Column(name="MOVIE_SCORE",nullable = false)
    private Integer score ;
    @ManyToOne
    //joinColumn il campo name fa referensa al db del movie e il campo referencedColumnName fa referensa al db del director
    @JoinColumn(name = "DIRECTOR_UUID", referencedColumnName = "DIRECTOR_UUID" ,nullable = false)
    private DirectorEntity director;

    @OneToMany(mappedBy = "movie",fetch = FetchType.EAGER)
    private List<AwardEntity> awards;

    //movie avra una onetomany verso award mentre la award avrad manytoone
    //data uscita per la movie


    public String getUuid() {
        return uuid==null? null: uuid.replace(uuid_prefix,"");
    }
}
