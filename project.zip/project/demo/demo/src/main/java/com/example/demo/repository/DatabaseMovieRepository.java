package com.example.demo.repository;

import com.example.demo.entity.MovieEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DatabaseMovieRepository
        extends JpaRepository<MovieEntity, String>, MovieRepository {
    @Query("select m from movie m  where  m.uuid = :movieUuid and m.director =:directorUuid")
    MovieEntity findByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);
    @Query("select m from movie m  where  m.director = :directorUuid")
    List<MovieEntity> findByDirectorUuid(String directorUuid);

    @Modifying
    @Query("update movie u set u.title = :title, u.durationInMinutes = :durationInMinutes  where u.uuid =:movieUuid and u.director =:directorUuid")
    int updateTitleAndDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title, int durationInMinutes);
    @Modifying
    @Query("update movie u set u.title = :title  where u.uuid =:movieUuid and u.director =:directorUuid")
    int updateTitleByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, String title);
    @Modifying
    @Query("update movie u set  u.durationInMinutes = :durationInMinutes  where u.uuid =:movieUuid and u.director =:directorUuid")
    int updateDurationInMinutesByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid, int durationInMinutes);
    @Modifying
    @Query("delete movie u  where u.uuid =:movieUuid and u.director =:directorUuid")
    int deleteByMovieUuidAndDirectorUuid(String movieUuid, String directorUuid);

}
