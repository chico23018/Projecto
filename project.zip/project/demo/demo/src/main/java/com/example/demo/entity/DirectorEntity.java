package com.example.demo.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Entity(name = "director")
@ToString
public class DirectorEntity {
public static String uuid_prefix="DRCT#" ;
    @Id
    @GeneratedValue(
            strategy=GenerationType.SEQUENCE,
            generator="myseq")
    @GenericGenerator(
            name="myseq",
            strategy="com.example.demo.generator.CustomUUID",
            parameters = {
                    @org.hibernate.annotations.Parameter(
                            name = com.example.demo.generator.CustomUUID.UUID_PREFIX,
                            value = "DRCT"
                    )
            }
    )
    @Column(name="DIRECTOR_UUID",nullable = false)
    private String uuid;

    @Column(name="DIRECTOR_NAME",nullable = false)
    private String name;

    @Column(name="DIRECTOR_BIRTHDATE",nullable = false)
    private LocalDate birthDate;

    @OneToMany(mappedBy = "director",fetch = FetchType.EAGER)
    private List<MovieEntity> movies;

    public String getUuid() {
        return uuid==null? null: uuid.replace(uuid_prefix,"");
    }
}
