package com.example.demo.service;


import com.example.demo.entity.AwardEntity;
import com.example.demo.entity.DirectorEntity;
import com.example.demo.entity.MovieEntity;
import com.example.demo.repository.*;
import com.opencsv.CSVParser;
import com.opencsv.CSVReader;
import com.opencsv.ICSVParser;
import com.opencsv.exceptions.CsvValidationException;
import com.opencsv.processor.RowProcessor;
import com.opencsv.validators.LineValidatorAggregator;
import com.opencsv.validators.RowValidatorAggregator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Service
@Slf4j
public class DummyService {
    private int i = 0;
    public static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private final DirectorRepository directorRepository;
    private final MovieRepository movieRepository;
    private final DatabaseAwardRepository databaseAwardRepository;
    private final static int title = 1;
    private final static int runtime = 7;
    private final static int year = 6;
    private final static int directorNu = 4;
    private final static int score = 11;

    public DummyService(DatabaseDirectorRepository directorRepository, DatabaseMovieRepository movieRepository, DatabaseAwardRepository databaseAwardRepository) {
        this.directorRepository = directorRepository;
        this.movieRepository = movieRepository;
        this.databaseAwardRepository = databaseAwardRepository;

        try (CSVReader csvReader = new CSVReader(new FileReader("IMDB-Movie-Data.csv"))) {

            csvReader.skip(1);
            String[] values = null;

            while ((values = csvReader.readNext()) != null) {

                List<DirectorEntity> list = this.directorRepository.findByName(values[directorNu]);

                DirectorEntity director = null;

                MovieEntity movie = new MovieEntity();

                if (list == null || list.isEmpty()) {
                    director = new DirectorEntity();
                    director.setName(values[directorNu]);
                    int date = 1901 + i;
                    director.setBirthDate(LocalDate.parse("01/01/" + date, dateFormatter));
                    this.directorRepository.save(director);
                    ++i;
                } else {
                    director = list.get(0);
                }

                movie.setDurationInMinutes(Integer.parseInt(values[runtime]));
                movie.setReleaseDate(LocalDate.parse("01/01/" + values[year], dateFormatter));
                movie.setTitle(values[title]);
                movie.setScore(Integer.parseInt(values[score]));
                movie.setDirector(director);
                this.movieRepository.save(movie);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException | CsvValidationException e) {
            throw new RuntimeException(e);
        }

      /*  this.directorRepository.mostAcclaimed(5, 75).forEach(n->
                System.out.println(" name: "+ n.getName()
                )
        );*/
    }


}
