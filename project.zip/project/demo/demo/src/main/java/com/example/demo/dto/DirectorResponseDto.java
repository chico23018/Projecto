package com.example.demo.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Schema(description = "The response model of a single director")
@Getter
@Setter
public class DirectorResponseDto {

    @Schema(description = "The unique identifier of the director")
    private UUID uuid;
    @Schema(description = "The director name")
    private String name;
    @Schema(description = "The list of movies directed by the director")
    private List<MovieResponseDto> movies;

    private LocalDate birthDate;
}
