package com.example.demo.controller;

import com.example.demo.dto.*;
import com.example.demo.mapper.DirectorMapper;
import com.example.demo.mapper.MovieMapper;
import com.example.demo.model.DirectorModel;
import com.example.demo.model.MovieModel;
import com.example.demo.service.DirectorService;
import com.example.demo.service.MovieService;
import com.example.demo.service.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

// Rest controller because we want to expose REST CRUD APIs, so the annotation @Controller is useless
@RestController
// Remember semantic versioning
// Remember also that here the annotation is not binding the controller to a specific path, instead
// this is generating a mapping for each internal method inside the controller itself
@RequestMapping("/v1.0/directors")
// Generate a constructor with all the fields of the class, in this case defining also the related
// dependencies
@AllArgsConstructor
public class MovieController {

    private final ValidationService validationService;

    private final DirectorService directorService;
    private final MovieService movieService;

    private final DirectorMapper directorMapper;
    private final MovieMapper movieMapper;


    // Decorate the OpenAPI documentation
    @Operation(description = "Read all the directors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    // Read all directors
    @GetMapping
    public ResponseEntity<List<DirectorResponseDto>> readDirectors(@RequestParam(value = "name", required = false)
                                                                       @Schema(description = "Set this filter if you want to search for directors with a given name")
                                                                       @Nullable String name) {
        List<DirectorResponseDto> directorResponseDtos = directorService.readDirectors(name).stream() // Lock at all the directors
                .map(directorMapper::responseFromModel) // Convert each director to a Dto
                .collect(Collectors.toList()); // Collect all the Dtos
        return ResponseEntity.ok(directorResponseDtos); // Return a 200 response
    }
    @Operation(description = "Search directors based on their performance")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "CREATED"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST"),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PostMapping("/search")
    public ResponseEntity<List<DirectorResponseDto>> searchDirector(@RequestBody(required = false) SearchDirectorRequestDto directorRequestDto) {
        validationService.doValidate(directorRequestDto);

     /*   List<DirectorResponseDto> directorResponseDtos = directorService
                .searchDirector(directorRequestDto)
                .stream().map(directorMapper::responseFromModel).collect(Collectors.toList());
*/
        List<DirectorResponseDto> directorResponseDtos = directorService
                .searchDirector_dto(directorRequestDto);

        return ResponseEntity.ok(directorResponseDtos);
    }


    @Operation(description = "Create a new director")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "CREATED"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST"),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PostMapping
    public ResponseEntity<DirectorResponseDto> createDirector(@RequestBody DirectorRequestDto directorRequestDto) {
        validationService.doValidate(directorRequestDto);
        DirectorModel directorModel = directorService.createDirector(directorMapper.modelFromRequest(directorRequestDto));
        return ResponseEntity.created(
                URI.create("/v1.0/directors/"+directorModel.getUuid().toString()))
                .body(directorMapper.responseFromModel(directorModel));
    }

    @Operation(description = "Update a given director")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PutMapping("/{directorUuid}")
    public ResponseEntity<DirectorResponseDto> updateDirector(@PathVariable("directorUuid")
                                                                  @Schema(description = "The unique identifier of a director")
                                                                  String directorUuid,
                                                              @RequestBody DirectorRequestDto directorRequestDto) {
        validationService.doValidate(directorRequestDto);
        DirectorModel directorModel = directorService.updateDirector(directorUuid, directorMapper.modelFromRequest(directorRequestDto));
        return ResponseEntity.ok(directorMapper.responseFromModel(directorModel));
    }

    @Operation(description = "Remove a given director")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @DeleteMapping("/{directorUuid}")
    public ResponseEntity<Void> deleteDirector(@PathVariable("directorUuid")
                                                   @Schema(description = "The unique identifier of a director")
                                                   String directorUuid) {
        directorService.deleteDirector(directorUuid);
        return ResponseEntity.noContent().build();
    }

    @Operation(description = "Read all director's movies")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @GetMapping("/{directorUuid}/movies")
    public ResponseEntity<List<MovieResponseDto>> readMovies(@PathVariable("directorUuid")
                                                                 @Schema(description = "The unique identifier of a director")
                                                                 String directorUuid) {
        List<MovieResponseDto> movies = movieService.readMovies(directorUuid).stream()
                .map(movieMapper::responseFromModel)
                .collect(Collectors.toList());
        return ResponseEntity.ok(movies);
    }

    @Operation(description = "Create a director's movies")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PostMapping("/{directorUuid}/movies")
    public ResponseEntity<MovieResponseDto> createMovie(@PathVariable("directorUuid")
                                                            @Schema(description = "The unique identifier of a director")
                                                            String directorUuid,
                                                        @RequestBody CreateMovieRequestDto createMovieRequestDto) {
        validationService.doValidate(createMovieRequestDto);
        MovieModel movie = movieService.createMovie(directorUuid, movieMapper.modelFromCreateRequest(createMovieRequestDto));
        return ResponseEntity.created(
                URI.create("/v1.0/directors/"+directorUuid+"/movies/"+movie.getUuid()))
                .body(movieMapper.responseFromModel(movie));
    }

    @Operation(description = "Update a director's movies")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @PutMapping("/{directorUuid}/movies/{movieUuid}")
    public ResponseEntity<MovieResponseDto> updateMovie(@PathVariable("directorUuid")
                                                            @Schema(description = "The unique identifier of a director")
                                                            String directorUuid,
                                                        @PathVariable("movieUuid")
                                                            @Schema(description = "The unique identifier of a movie")
                                                            String movieUuid,
                                                        @RequestBody UpdateMovieRequestDto updateMovieRequestDto) {
        validationService.doValidate(updateMovieRequestDto);
        MovieModel movie = movieService.updateMovie(directorUuid, movieUuid, movieMapper.modelFromUpdateRequest(updateMovieRequestDto));
        return ResponseEntity.ok(movieMapper.responseFromModel(movie));
    }

    @Operation(description = "Delete a director's movies")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "NO CONTENT"),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "404", description = "NOT FOUND",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))),
            @ApiResponse(responseCode = "500", description = "INTERNAL SERVER ERROR",
                    content = @Content(schema = @Schema(implementation = ErrorResponseDto.class)))
    })
    @DeleteMapping("/{directorUuid}/movies/{movieUuid}")
    public ResponseEntity<Void> deleteMovie(@PathVariable("directorUuid")
                                                @Schema(description = "The unique identifier of a director")
                                                String directorUuid,
                                            @PathVariable("movieUuid")
                                                @Schema(description = "The unique identifier of a movie")
                                                String movieUuid) {
        movieService.deleteMovie(directorUuid, movieUuid);
        return ResponseEntity.noContent().build();
    }
}
