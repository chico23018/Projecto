package com.example.demo.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString(exclude = "movie")
@Entity(name = "award")
public class AwardEntity {
    public static String uuid_prefix = "AWA#";
    @Id()
    @Column(name = "AWARD_UUID", nullable = false)
    /*    @GeneratedValue(generator = "uuid-hibernate-generator")
    @GenericGenerator(name = "uuid-hibernate-generator", strategy = "org.hibernate.id.UUIDGenerator")*/
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "myseq")
    @GenericGenerator(
            name = "myseq",
            strategy = "com.example.demo.generator.CustomUUID",
            parameters = {
                    @org.hibernate.annotations.Parameter(
                            name = com.example.demo.generator.CustomUUID.UUID_PREFIX,
                            value = "AWA"
                    )
            }
    )
    private String uuid;
    @Column(name = "AWARD_DESCRIPTION", nullable = false)
    String description;

    @ManyToOne
    @JoinColumn(name = "movie_uuid", referencedColumnName = "MOVIE_UUID", nullable = false)
    private MovieEntity movie;

    public String getUuid() {
        return uuid == null ? null : uuid.replace(uuid_prefix, "");
    }

    public void setUuid(String uuid) {
        if (!uuid.startsWith(uuid_prefix))
            this.uuid = uuid_prefix+uuid;
    }
}
