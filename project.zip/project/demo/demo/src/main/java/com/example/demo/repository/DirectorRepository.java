package com.example.demo.repository;

import com.example.demo.entity.DirectorEntity;

import java.time.LocalDate;
import java.util.List;

public interface DirectorRepository {

    List<DirectorEntity> findAll();

    List<DirectorEntity> findByName(String name);

    DirectorEntity findByUuid(String uuid);

    <S extends DirectorEntity> S save(S entity);

    int updateNameByUuid(String name, String uuid);

    int deleteByUuid(String uuid);

    List<DirectorEntity> findByNameLike(String likePattern);
    List<DirectorEntity> findByNameContaining(String infix);

    List<DirectorEntity> findByBirthDateBetween(LocalDate start, LocalDate end);

    List<DirectorEntity> mostAcclaimed(long movies, double vote);



    List<DirectorEntity> findByNameAndBirthDateBetween(String name, LocalDate from, LocalDate to);



    List<DirectorEntity> findByNameContainingAndBirthDateBetween(String name, LocalDate from, LocalDate to);
}
