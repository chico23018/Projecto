package com.example.demo.constant;

public final class Constant {

    public static final String READ_MESSAGE = "read";
    public static final String CREATE_MESSAGE = "create";
    public static final String UPDATE_MESSAGE = "update";
    public static final String DELETE_MESSAGE = "delete";

    private Constant() {

    }
}
