package com.example.demo.service;

import com.example.demo.constant.Constant;
import com.example.demo.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreateUserService extends BaseUserService {

    public CreateUserService(@Qualifier(Constant.CREATE_MESSAGE) List<IRepository> iRepositories) {
        super(iRepositories);
    }
}
