package com.example.demo.repository;

import com.example.demo.constant.Constant;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RepositoryConfiguration {

    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository1() {
        return new ReadUserRepository();
    }

    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository2() {
        return new ReadUserRepository();
    }

    @Bean
    @Qualifier(Constant.READ_MESSAGE)
    public IRepository readRepository3() {
        return new ReadUserRepository();
    }

    @Bean
    @Qualifier(Constant.CREATE_MESSAGE)
    public IRepository createRepository1() {
        return new CreateUserRepository();
    }

    @Bean
    @Qualifier(Constant.CREATE_MESSAGE)
    public IRepository createRepository2() {
        return new CreateUserRepository();
    }

    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository1() {
        return new UpdateUserRepository();
    }

    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository2() {
        return new UpdateUserRepository();
    }

    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository3() {
        return new UpdateUserRepository();
    }

    @Bean
    @Qualifier(Constant.UPDATE_MESSAGE)
    public IRepository updateRepository4() {
        return new UpdateUserRepository();
    }

    @Bean
    @Qualifier(Constant.DELETE_MESSAGE)
    public IRepository deleteRepository() {
        return new DeleteUserRepository();
    }
}
