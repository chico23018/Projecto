package com.example.demo.controller;

import com.example.demo.service.CreateUserService;
import com.example.demo.service.DeleteUserService;
import com.example.demo.service.ReadUsersService;
import com.example.demo.service.UpdateUserService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Controller {

    private final CreateUserService createUserService;
    private final DeleteUserService deleteUserService;
    private final ReadUsersService readUsersService;
    private final UpdateUserService updateUserService;

    public Controller(CreateUserService createUserService, DeleteUserService deleteUserService,
                      ReadUsersService readUsersService, UpdateUserService updateUserService) {
        this.createUserService = createUserService;
        this.deleteUserService = deleteUserService;
        this.readUsersService = readUsersService;
        this.updateUserService = updateUserService;
    }

    public List<String> readUsers() {
        return readUsersService.getMessages();
    }

    public List<String> createUser() {
        return createUserService.getMessages();
    }

    public List<String> updateUser() {
        return updateUserService.getMessages();
    }

    public List<String> deleteUser() {
        return deleteUserService.getMessages();
    }
}
