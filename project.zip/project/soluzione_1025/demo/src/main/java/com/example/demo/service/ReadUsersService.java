package com.example.demo.service;

import com.example.demo.constant.Constant;
import com.example.demo.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReadUsersService extends BaseUserService {

    public ReadUsersService(@Qualifier(Constant.READ_MESSAGE) List<IRepository> iRepositories) {
        super(iRepositories);
    }
}
