package com.example.demo.repository;

import com.example.demo.constant.Constant;

public class CreateUserRepository implements IRepository {

    @Override
    public String doStuff() {
        return Constant.CREATE_MESSAGE;
    }
}
