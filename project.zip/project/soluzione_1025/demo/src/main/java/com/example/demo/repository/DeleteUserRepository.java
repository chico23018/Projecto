package com.example.demo.repository;

import com.example.demo.constant.Constant;

public class DeleteUserRepository implements IRepository {

    @Override
    public String doStuff() {
        return Constant.DELETE_MESSAGE;
    }
}
