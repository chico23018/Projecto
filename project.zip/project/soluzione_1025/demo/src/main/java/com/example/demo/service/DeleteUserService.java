package com.example.demo.service;

import com.example.demo.constant.Constant;
import com.example.demo.repository.IRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeleteUserService extends BaseUserService {

    public DeleteUserService(@Qualifier(Constant.DELETE_MESSAGE) List<IRepository> iRepositories) {
        super(iRepositories);
    }
}
