package com.example.demo.service;

import com.example.demo.repository.IRepository;

import java.util.List;
import java.util.stream.Collectors;

public class BaseUserService {

    private final List<IRepository> iRepositories;

    protected BaseUserService(List<IRepository> iRepositories) {
        this.iRepositories = iRepositories;
    }

    public List<String> getMessages() {
        return this.iRepositories.stream()
                .map(IRepository::doStuff)
                .collect(Collectors.toList());
    }
}
