package com.example.demo;

import com.example.demo.constant.Constant;
import com.example.demo.controller.Controller;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	private Controller controller;

	@Test
	void contextLoads() {
	}

	@Test
	void shouldReadUsers() {
		List<String> list = controller.readUsers();
		Assertions.assertEquals(3, list.size());
		this.evaluateMessages(Constant.READ_MESSAGE, list);
	}

	@Test
	void shouldCreateUser() {
		List<String> list = controller.createUser();
		Assertions.assertEquals(2, list.size());
		this.evaluateMessages(Constant.CREATE_MESSAGE, list);
	}

	@Test
	void shouldUpdateUser() {
		List<String> list = controller.updateUser();
		Assertions.assertEquals(4, list.size());
		this.evaluateMessages(Constant.UPDATE_MESSAGE, list);
	}

	@Test
	void shouldDeleteUser() {
		List<String> list = controller.deleteUser();
		Assertions.assertEquals(1, list.size());
		this.evaluateMessages(Constant.DELETE_MESSAGE, list);
	}

	private void evaluateMessages(String expected, List<String> messages) {
		for (String message: messages) {
			Assertions.assertEquals(expected, message);
		}
	}

}
